import os
from datetime import datetime, timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether, HRFlowable
)
from app.config import settings

def generate_forensic_pdf_report(
    incident_data: dict,
    attack_data: list,
    evidence_data: list,
    custody_data: list,
    threat_findings: dict,
    investigator_notes: str = ""
) -> str:
    """
    Builds a professional, comprehensive forensic digital investigation report PDF
    using ReportLab and returns the generated absolute file path.
    """
    os.makedirs(settings.REPORT_DIR, exist_ok=True)
    case_id = incident_data.get("case_id", "CIR-UNKNOWN").replace("/", "-")
    timestamp_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    report_filename = f"FORENSIC_REPORT_{case_id}_{timestamp_str}.pdf"
    file_path = os.path.join(settings.REPORT_DIR, report_filename)

    doc = SimpleDocTemplate(
        file_path,
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()
    
    # Custom color palette (Cyber Forensic Theme)
    primary_color = colors.HexColor("#0F172A")    # Dark Slate
    secondary_color = colors.HexColor("#1E293B")  # Charcoal
    accent_blue = colors.HexColor("#2563EB")      # Electric Blue
    accent_red = colors.HexColor("#DC2626")       # Alert Red
    accent_green = colors.HexColor("#16A34A")     # Verified Green
    text_dark = colors.HexColor("#1E293B")
    border_color = colors.HexColor("#CBD5E1")

    # Typography styles
    title_style = ParagraphStyle(
        "ReportTitle",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=20,
        leading=24,
        textColor=primary_color,
        spaceAfter=4
    )
    subtitle_style = ParagraphStyle(
        "ReportSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=10,
        leading=13,
        textColor=accent_blue,
        spaceAfter=12
    )
    heading_style = ParagraphStyle(
        "SectionHeading",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=16,
        textColor=primary_color,
        spaceBefore=14,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        "BodyDark",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        leading=13,
        textColor=text_dark
    )
    code_style = ParagraphStyle(
        "HashMono",
        parent=styles["Normal"],
        fontName="Courier",
        fontSize=7,
        leading=9,
        textColor=colors.HexColor("#334155")
    )
    alert_style = ParagraphStyle(
        "AlertBox",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=8,
        leading=11,
        textColor=colors.HexColor("#991B1B")
    )

    story = []

    # 1. Header Banner
    header_data = [
        [
            Paragraph("<b>CYBER INCIDENT RESPONSE &amp; DIGITAL FORENSICS PLATFORM</b>", title_style),
            Paragraph("<b>CONFIDENTIAL // LAW ENFORCEMENT &amp; SOC FORENSICS ONLY</b>", ParagraphStyle("HeaderClass", fontName="Helvetica-Bold", fontSize=8, textColor=accent_red, alignment=2))
        ]
    ]
    header_table = Table(header_data, colWidths=[380, 160])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(header_table)
    story.append(Paragraph(f"Official Forensic Examination &amp; Incident Case Dossier &bull; Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=accent_blue, spaceBefore=2, spaceAfter=10))

    # 2. Executive Incident Summary
    story.append(Paragraph("1. INCIDENT CASE IDENTIFICATION &amp; METADATA", heading_style))
    
    meta_table_data = [
        [
            Paragraph("<b>Case Reference ID:</b>", body_style),
            Paragraph(f"<b>{incident_data.get('case_id')}</b>", body_style),
            Paragraph("<b>Current Status:</b>", body_style),
            Paragraph(f"<b>{incident_data.get('status')}</b>", body_style),
        ],
        [
            Paragraph("<b>Incident Title:</b>", body_style),
            Paragraph(incident_data.get('title', 'N/A'), body_style),
            Paragraph("<b>Severity Level:</b>", body_style),
            Paragraph(f"<b>{incident_data.get('severity', 'N/A').upper()}</b>", body_style),
        ],
        [
            Paragraph("<b>Category:</b>", body_style),
            Paragraph(incident_data.get('category', 'N/A'), body_style),
            Paragraph("<b>Incident Timestamp:</b>", body_style),
            Paragraph(str(incident_data.get('incident_datetime', 'N/A'))[:19], body_style),
        ],
        [
            Paragraph("<b>Target System:</b>", body_style),
            Paragraph(incident_data.get('affected_system', 'N/A'), body_style),
            Paragraph("<b>Assigned Lead:</b>", body_style),
            Paragraph(incident_data.get('investigator_name', 'Lead Forensic Analyst'), body_style),
        ],
        [
            Paragraph("<b>Source IP Address:</b>", body_style),
            Paragraph(incident_data.get('source_ip') or 'Undetermined', body_style),
            Paragraph("<b>Destination IP:</b>", body_style),
            Paragraph(incident_data.get('destination_ip') or 'Internal Network', body_style),
        ]
    ]

    meta_table = Table(meta_table_data, colWidths=[110, 160, 110, 160])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F8FAFC")),
        ('GRID', (0,0), (-1,-1), 0.5, border_color),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 6))

    # Case Narrative
    story.append(Paragraph("<b>Incident Description &amp; Initial Triage:</b>", body_style))
    story.append(Paragraph(incident_data.get('description', 'No narrative provided.'), body_style))
    story.append(Spacer(1, 10))

    # 3. Cyberattack Classification & Tactics
    story.append(Paragraph("2. CYBERATTACK DETAILS &amp; MITRE ATT&amp;CK MAPPING", heading_style))
    if attack_data:
        att = attack_data[0]
        atk_table_data = [
            [Paragraph("<b>Attack Type:</b>", body_style), Paragraph(str(att.get("attack_type", "N/A")), body_style), Paragraph("<b>Attack Source:</b>", body_style), Paragraph(str(att.get("attack_source", "N/A")), body_style)],
            [Paragraph("<b>Vector:</b>", body_style), Paragraph(str(att.get("attack_vector", "N/A")), body_style), Paragraph("<b>MITRE Tactics:</b>", body_style), Paragraph(str(att.get("mitre_tactics", "N/A")), body_style)],
            [Paragraph("<b>Target Host:</b>", body_style), Paragraph(str(att.get("target_system", "N/A")), body_style), Paragraph("<b>Attack Time:</b>", body_style), Paragraph(str(att.get("attack_timestamp", "N/A"))[:19], body_style)],
        ]
        atk_table = Table(atk_table_data, colWidths=[90, 180, 90, 180])
        atk_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F1F5F9")),
            ('GRID', (0,0), (-1,-1), 0.5, border_color),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        story.append(atk_table)
        story.append(Spacer(1, 4))
        story.append(Paragraph(f"<b>Suspicious Activity Description:</b> {att.get('suspicious_activity_description', 'N/A')}", body_style))
        story.append(Paragraph(f"<b>Forensic Observations:</b> {att.get('investigator_observations', 'N/A')}", body_style))
    else:
        story.append(Paragraph("<i>No specific attack vector profile attached to this incident record.</i>", body_style))
    story.append(Spacer(1, 10))

    # 4. Digital Evidence & Cryptographic Verification
    story.append(Paragraph("3. DIGITAL EVIDENCE INVENTORY &amp; SHA-256 INTEGRITY VERIFICATION", heading_style))
    if evidence_data:
        ev_header = [
            Paragraph("<b>EVD ID</b>", body_style),
            Paragraph("<b>Original Filename</b>", body_style),
            Paragraph("<b>File Size</b>", body_style),
            Paragraph("<b>Original SHA-256 Baseline</b>", body_style),
            Paragraph("<b>Integrity Status</b>", body_style)
        ]
        ev_rows = [ev_header]
        for ev in evidence_data:
            status_str = ev.get("integrity_status", "VERIFIED")
            status_color = accent_green if status_str == "VERIFIED" else accent_red
            ev_rows.append([
                Paragraph(f"<b>{ev.get('evidence_id')}</b>", body_style),
                Paragraph(str(ev.get("original_filename")), body_style),
                Paragraph(f"{round(ev.get('file_size', 0) / 1024, 1)} KB", body_style),
                Paragraph(str(ev.get("original_sha256", "N/A")), code_style),
                Paragraph(f"<b>{status_str}</b>", ParagraphStyle("EvStatus", fontName="Helvetica-Bold", fontSize=8, textColor=status_color))
            ])
        ev_table = Table(ev_rows, colWidths=[65, 115, 60, 230, 70])
        ev_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#E2E8F0")),
            ('GRID', (0,0), (-1,-1), 0.5, border_color),
            ('TOPPADDING', (0,0), (-1,-1), 3),
            ('BOTTOMPADDING', (0,0), (-1,-1), 3),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ]))
        story.append(ev_table)
    else:
        story.append(Paragraph("<i>No digital evidence files logged under this case.</i>", body_style))
    story.append(Spacer(1, 10))

    # 5. Chain of Custody Audit Trail
    story.append(Paragraph("4. CHAIN OF CUSTODY (APPEND-ONLY FORENSIC TRAIL)", heading_style))
    if custody_data:
        coc_header = [
            Paragraph("<b>Record ID</b>", body_style),
            Paragraph("<b>Evidence ID</b>", body_style),
            Paragraph("<b>Action Executed</b>", body_style),
            Paragraph("<b>Timestamp (UTC)</b>", body_style),
            Paragraph("<b>Remarks &amp; Custodian</b>", body_style),
        ]
        coc_rows = [coc_header]
        for c in custody_data[:10]: # Up to 10 latest entries
            coc_rows.append([
                Paragraph(str(c.get("record_id")), body_style),
                Paragraph(f"EVD #{c.get('evidence_id')}", body_style),
                Paragraph(str(c.get("action")), body_style),
                Paragraph(str(c.get("timestamp"))[:19], body_style),
                Paragraph(str(c.get("remarks") or c.get("new_custodian") or "Routine log"), body_style),
            ])
        coc_table = Table(coc_rows, colWidths=[70, 60, 130, 110, 170])
        coc_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#E2E8F0")),
            ('GRID', (0,0), (-1,-1), 0.5, border_color),
            ('TOPPADDING', (0,0), (-1,-1), 3),
            ('BOTTOMPADDING', (0,0), (-1,-1), 3),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ]))
        story.append(coc_table)
    else:
        story.append(Paragraph("<i>No chain of custody logs recorded for this case.</i>", body_style))
    story.append(Spacer(1, 10))

    # 6. AI-Assisted Threat Analysis Findings
    story.append(Paragraph("5. AI-ASSISTED THREAT INTELLIGENCE &amp; LOG ANALYSIS FINDINGS", heading_style))
    if threat_findings and threat_findings.get("observations"):
        story.append(Paragraph(f"<b>System Risk Score:</b> {threat_findings.get('risk_score', 0)} / 100 &bull; <b>Assessment:</b> {threat_findings.get('overall_assessment')}", body_style))
        story.append(Spacer(1, 4))
        for obs in threat_findings.get("observations", [])[:3]:
            obs_box = [
                [Paragraph(f"<b>[{obs.get('severity').upper()}] {obs.get('title')}</b> (Confidence: {int(obs.get('confidence', 0)*100)}%)", ParagraphStyle("ObsTitle", fontName="Helvetica-Bold", fontSize=9, textColor=accent_blue))],
                [Paragraph(f"<b>Technical Rationale:</b> {obs.get('why_suspicious')}", body_style)],
                [Paragraph(f"<b>Recommended Countermeasures:</b> {' | '.join(obs.get('investigation_steps', [])[:2])}", body_style)]
            ]
            obs_table = Table(obs_box, colWidths=[540])
            obs_table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F8FAFC")),
                ('BOX', (0,0), (-1,-1), 0.75, colors.HexColor("#94A3B8")),
                ('TOPPADDING', (0,0), (-1,-1), 3),
                ('BOTTOMPADDING', (0,0), (-1,-1), 3),
            ]))
            story.append(obs_table)
            story.append(Spacer(1, 4))
    else:
        story.append(Paragraph("<i>No automated threat signatures flagged for this case.</i>", body_style))
    
    # Forensic Disclaimer
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "<b>LEGAL &amp; FORENSIC ADVISORY:</b> Automated AI and heuristic detections represent investigative indicators "
        "derived from ingested system logs and must be correlated with verified physical evidence. "
        "Application-level custody tracking establishes procedural handling compliance.",
        alert_style
    ))
    story.append(Spacer(1, 10))

    # 7. Investigator Remarks & Sign-off
    story.append(Paragraph("6. INVESTIGATOR CERTIFICATION &amp; SIGN-OFF", heading_style))
    if investigator_notes:
        story.append(Paragraph(f"<b>Additional Remarks:</b> {investigator_notes}", body_style))
        story.append(Spacer(1, 6))

    sign_data = [
        [
            Paragraph("<b>Primary Lead Forensic Examiner:</b><br/><br/>_____________________________________<br/>Signature &amp; Badge ID", body_style),
            Paragraph("<b>SOC Incident Commander:</b><br/><br/>_____________________________________<br/>Authorization &amp; Seal", body_style),
            Paragraph(f"<b>Date Verified:</b><br/><br/>{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}<br/>Timestamp Signed", body_style)
        ]
    ]
    sign_table = Table(sign_data, colWidths=[180, 180, 180])
    sign_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('TOPPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(sign_table)

    doc.build(story)
    return file_path
