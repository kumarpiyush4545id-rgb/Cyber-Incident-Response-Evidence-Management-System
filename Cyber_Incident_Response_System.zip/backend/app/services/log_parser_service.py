import re
import io
import pandas as pd
from datetime import datetime
from typing import Dict, Any, List, Tuple

# Common forensic regex patterns
IP_REGEX = r'(?:\d{1,3}\.){3}\d{1,3}'
SSH_FAILED_REGEX = re.compile(
    r'(?P<timestamp>[A-Za-z]{3}\s+\d+\s+[\d:]+).*?sshd\[\d+\]:\s+Failed\s+(?:password|none)\s+for\s+(?:invalid\s+user\s+)?(?P<user>\S+)\s+from\s+(?P<ip>' + IP_REGEX + r')\s+port\s+(?P<port>\d+)',
    re.IGNORECASE
)
SSH_ACCEPTED_REGEX = re.compile(
    r'(?P<timestamp>[A-Za-z]{3}\s+\d+\s+[\d:]+).*?sshd\[\d+\]:\s+Accepted\s+\S+\s+for\s+(?P<user>\S+)\s+from\s+(?P<ip>' + IP_REGEX + r')',
    re.IGNORECASE
)
APACHE_COMBINED_REGEX = re.compile(
    r'(?P<ip>' + IP_REGEX + r')\s+\S+\s+(?P<user>\S+)\s+\[(?P<timestamp>[^\]]+)\]\s+"(?P<method>[A-Z]+)\s+(?P<path>[^\s"]+)\s+(?P<protocol>[^"]+)"\s+(?P<status>\d{3})\s+(?P<bytes>\S+)(?:\s+"(?P<referrer>[^"]*)"\s+"(?P<user_agent>[^"]*)")?'
)
FIREWALL_REGEX = re.compile(
    r'(?P<timestamp>[A-Za-z]{3}\s+\d+\s+[\d:]+).*?(?P<action>BLOCK|DROP|ALLOW|ACCEPT|DENY).*?SRC=(?P<ip>' + IP_REGEX + r').*?DST=(?P<dst_ip>' + IP_REGEX + r')(?:.*?DPT=(?P<port>\d+))?'
)

def parse_log_content(content_str: str, log_type: str = "Authentication") -> Dict[str, Any]:
    """
    Parses security and system log files using Regex and Pandas.
    Extracts authentication failures, IP addresses, targeted accounts,
    and produces forensic statistical summaries.
    """
    lines = [line.strip() for line in content_str.splitlines() if line.strip()]
    total_entries = len(lines)
    
    parsed_rows: List[Dict[str, Any]] = []
    failed_logins = 0

    for idx, line in enumerate(lines):
        entry_data = {
            "id": idx + 1,
            "raw": line,
            "timestamp": "N/A",
            "ip": "Unknown",
            "user": "-",
            "event_type": "Info",
            "status": "Normal",
            "severity": "Low"
        }

        # 1. SSH Auth Log matching
        ssh_fail_match = SSH_FAILED_REGEX.search(line)
        if ssh_fail_match:
            failed_logins += 1
            entry_data.update({
                "timestamp": ssh_fail_match.group("timestamp"),
                "ip": ssh_fail_match.group("ip"),
                "user": ssh_fail_match.group("user"),
                "event_type": "Failed Authentication",
                "status": "Failed",
                "severity": "High"
            })
            parsed_rows.append(entry_data)
            continue

        ssh_ok_match = SSH_ACCEPTED_REGEX.search(line)
        if ssh_ok_match:
            entry_data.update({
                "timestamp": ssh_ok_match.group("timestamp"),
                "ip": ssh_ok_match.group("ip"),
                "user": ssh_ok_match.group("user"),
                "event_type": "Successful Authentication",
                "status": "Success",
                "severity": "Low"
            })
            parsed_rows.append(entry_data)
            continue

        # 2. Web Server Combined Log matching
        web_match = APACHE_COMBINED_REGEX.search(line)
        if web_match:
            status_code = int(web_match.group("status"))
            path = web_match.group("path")
            user_agent = web_match.group("user_agent") or ""
            method = web_match.group("method")
            ip = web_match.group("ip")
            
            is_suspicious = False
            sev = "Low"
            evt = "HTTP Request"

            if status_code in [401, 403]:
                evt = "HTTP Unauthorized / Forbidden"
                sev = "Medium"
                if "/admin" in path or "/login" in path:
                    failed_logins += 1
                    sev = "High"
            elif status_code == 404 and any(s in path.lower() for s in [".env", "wp-login", "phpmyadmin", "shell", ".git"]):
                evt = "Web Scanner / Reconnaissance"
                sev = "High"
                is_suspicious = True
            elif any(ua in user_agent.lower() for ua in ["nikto", "sqlmap", "nmap", "masscan", "gobuster"]):
                evt = "Automated Vulnerability Scan"
                sev = "Critical"
                is_suspicious = True
            elif "'" in path or "union" in path.lower() or "select" in path.lower():
                evt = "SQL Injection Attempt"
                sev = "Critical"
                is_suspicious = True

            entry_data.update({
                "timestamp": web_match.group("timestamp"),
                "ip": ip,
                "user": web_match.group("user") if web_match.group("user") != "-" else "-",
                "event_type": evt,
                "status": f"HTTP {status_code}",
                "severity": sev,
                "path": path,
                "method": method,
                "user_agent": user_agent
            })
            parsed_rows.append(entry_data)
            continue

        # 3. Firewall log matching
        fw_match = FIREWALL_REGEX.search(line)
        if fw_match:
            action = fw_match.group("action").upper()
            sev = "Medium" if action in ["BLOCK", "DROP", "DENY"] else "Low"
            entry_data.update({
                "timestamp": fw_match.group("timestamp"),
                "ip": fw_match.group("ip"),
                "event_type": f"Firewall {action}",
                "status": action,
                "severity": sev,
                "port": fw_match.group("port") or "N/A"
            })
            parsed_rows.append(entry_data)
            continue

        # 4. Fallback IP extraction
        ip_found = re.findall(IP_REGEX, line)
        if ip_found:
            entry_data["ip"] = ip_found[0]
            if "fail" in line.lower() or "invalid" in line.lower() or "error" in line.lower():
                entry_data["status"] = "Error"
                entry_data["severity"] = "Medium"
                if "login" in line.lower() or "auth" in line.lower() or "password" in line.lower():
                    failed_logins += 1
                    entry_data["event_type"] = "Auth Failure"
                    entry_data["severity"] = "High"
        parsed_rows.append(entry_data)

    # Use Pandas for statistical analysis
    df = pd.DataFrame(parsed_rows)
    
    suspicious_ips_list: List[Dict[str, Any]] = []
    summary_stats: Dict[str, Any] = {
        "total_parsed": len(df),
        "failed_logins": failed_logins,
        "unique_ips": 0,
        "severity_counts": {"Low": 0, "Medium": 0, "High": 0, "Critical": 0},
        "top_attackers": [],
        "status_distribution": {}
    }

    if not df.empty:
        summary_stats["unique_ips"] = int(df["ip"].nunique())
        
        # Severity distribution
        if "severity" in df.columns:
            sev_counts = df["severity"].value_counts().to_dict()
            summary_stats["severity_counts"].update(sev_counts)
        
        # Status distribution
        if "status" in df.columns:
            summary_stats["status_distribution"] = df["status"].value_counts().head(6).to_dict()

        # Identify Suspicious IPs
        # Filter for rows with failed status or High/Critical severity
        suspicious_df = df[(df["severity"].isin(["High", "Critical"])) & (df["ip"] != "Unknown")]
        
        if not suspicious_df.empty:
            ip_group = suspicious_df.groupby("ip")
            for ip, group in ip_group:
                fail_count = len(group)
                users = list(group[group["user"] != "-"]["user"].unique()) if "user" in group.columns else []
                risk_score = min(100, fail_count * 12 + (20 if len(users) > 2 else 0))
                
                cat = "Brute-Force Attacker" if fail_count >= 3 else "Suspicious Activity"
                if any(group["severity"] == "Critical"):
                    cat = "Exploit / Scan Origin"
                    risk_score = max(risk_score, 85)

                suspicious_ips_list.append({
                    "ip": ip,
                    "failure_count": fail_count,
                    "first_seen": str(group["timestamp"].iloc[0]),
                    "last_seen": str(group["timestamp"].iloc[-1]),
                    "targeted_users": users[:5],
                    "risk_score": risk_score,
                    "threat_category": cat
                })
            
            # Sort by risk score
            suspicious_ips_list.sort(key=lambda x: x["risk_score"], reverse=True)
            summary_stats["top_attackers"] = suspicious_ips_list[:5]

    # Sample preview rows (up to 50 for frontend table view)
    preview_items = parsed_rows[:50]

    return {
        "total_entries": total_entries,
        "failed_logins": failed_logins,
        "suspicious_ips": suspicious_ips_list,
        "summary_stats": summary_stats,
        "raw_preview": preview_items,
        "findings_summary": (
            f"Parsed {total_entries} log events. Detected {failed_logins} authentication failures "
            f"across {summary_stats['unique_ips']} unique IP addresses. "
            f"Flagged {len(suspicious_ips_list)} suspicious source IP(s)."
        )
    }
