import re
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

class BaseThreatEngine(ABC):
    """Abstract base class ensuring extensibility for future ML/DL models."""
    @abstractmethod
    def analyze(self, logs_or_text: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        pass

class RuleBasedThreatEngine(BaseThreatEngine):
    """
    Heuristic, signature-based and statistical threat detection engine
    aligned with the MITRE ATT&CK Enterprise Matrix.
    """

    PATTERNS = [
        {
            "id": "THR-001",
            "category": "Credential Access",
            "mitre_id": "T1110.001 - Brute Force: Password Guessing",
            "severity": "High",
            "regex": re.compile(r'(Failed password|authentication failure|logon failure|status=failed)', re.I),
            "threshold": 3,
            "title": "Repeated Authentication Failure Spike (Brute Force Anomaly)",
            "why_suspicious": (
                "Multiple failed logon attempts were recorded within a narrow timeframe. "
                "This behavior is characteristic of automated dictionary attacks or password-spraying tools "
                "attempting to compromise valid user accounts."
            ),
            "investigation_steps": [
                "Identify the originating IP address and verify if it belongs to an authorized corporate VPN or subnet.",
                "Enforce temporary account lockouts or trigger immediate Multi-Factor Authentication (MFA) step-up.",
                "Cross-reference the targeted usernames against enterprise directory services (Active Directory / LDAP).",
                "Review firewall egress logs for post-auth connections originating from this host."
            ]
        },
        {
            "id": "THR-002",
            "category": "Initial Access / Web Exploitation",
            "mitre_id": "T1190 - Exploit Public-Facing Application",
            "severity": "Critical",
            "regex": re.compile(r'(UNION\s+SELECT|SELECT\s+.*?\s+FROM|OR\s+[\'"]?1[\'"]?\s*=\s*[\'"]?1|EXEC\s+xp_cmdshell|WAITFOR\s+DELAY)', re.I),
            "threshold": 1,
            "title": "SQL Injection (SQLi) Payload Signature Detected",
            "why_suspicious": (
                "The web server received queries containing structured database syntax fragments ('UNION SELECT' / 'OR 1=1'). "
                "Attackers use SQL injection to bypass authentication, extract confidential database records, or execute arbitrary SQL procedures."
            ),
            "investigation_steps": [
                "Inspect the target web application endpoint for parameterized query vulnerabilities.",
                "Check backend database query logs to determine if the query successfully executed or returned syntax errors.",
                "Deploy or update Web Application Firewall (WAF) virtual patching rules blocking SQL meta-characters.",
                "Review database access permissions to restrict database user privileges (Principle of Least Privilege)."
            ]
        },
        {
            "id": "THR-003",
            "category": "Discovery / Reconnaissance",
            "mitre_id": "T1595.002 - Active Scanning: Vulnerability Scanning",
            "severity": "High",
            "regex": re.compile(r'(sqlmap|nikto|nmap|masscan|gobuster|dirbuster|acunetix|wpscan|hydra)', re.I),
            "threshold": 1,
            "title": "Automated Security Scanner User-Agent Fingerprint",
            "why_suspicious": (
                "Incoming requests explicitly identified as known automated penetration testing tools or vulnerability scanners. "
                "Attackers leverage these tools to rapidly map web attack surfaces, enumerate directories, and find unpatched flaws."
            ),
            "investigation_steps": [
                "Block the source IP address immediately on external boundary firewalls or CDN edge rules.",
                "Verify if any 200 OK responses were served back to the scanner, indicating exposed administrative portals or files.",
                "Check whether this IP correlates with scheduled authorized internal vulnerability scans."
            ]
        },
        {
            "id": "THR-004",
            "category": "Defense Evasion / Execution",
            "mitre_id": "T1059.001 - Command and Scripting Interpreter: PowerShell",
            "severity": "Critical",
            "regex": re.compile(r'(powershell.*?-enc|-encodedcommand|cmd\.exe\s+/c|certutil\s+-urlcache|curl\s+.*?\|\s*bash|wget\s+.*?\|\s*sh|whoami\s*&&|chmod\s+\+x)', re.I),
            "threshold": 1,
            "title": "Obfuscated / Suspicious Command Interpreter Execution",
            "why_suspicious": (
                "Detection of encoded PowerShell commands or piped remote shell script downloads (curl | bash). "
                "Adversaries employ base64-encoded command lines to evade signature detection, download secondary payloads, and initiate remote C2 callbacks."
            ),
            "investigation_steps": [
                "Isolate the endpoint from the local network immediately to prevent lateral movement.",
                "Decode the base64 command string from PowerShell Script Block Logging (Event ID 4104).",
                "Capture volatile RAM memory dump for memory analysis (Volatility) before rebooting.",
                "Examine parent-child process relationships (Sysmon Event ID 1) to identify initial exploit vectors."
            ]
        },
        {
            "id": "THR-005",
            "category": "Impact / Ransomware Activity",
            "mitre_id": "T1486 - Data Encrypted for Impact",
            "severity": "Critical",
            "regex": re.compile(r'(\.locked|\.crypto|\.crypted|\.enc|\.wncry|\.lockbit|\.blackcat|vssadmin\s+delete\s+shadows|wbadmin\s+delete\s+catalog)', re.I),
            "threshold": 1,
            "title": "Potential Ransomware / Volume Shadow Copy Deletion Indicator",
            "why_suspicious": (
                "Keywords indicating encrypted file extensions or commands executing 'vssadmin delete shadows'. "
                "Ransomware threat actors destroy local backup snapshots prior to file encryption to prevent victim recovery."
            ),
            "investigation_steps": [
                "Trigger immediate emergency network segment containment and sever shared SMB network drives.",
                "Verify offline and immutable backup integrity for critical storage systems.",
                "Preserve ransom note text and sample encrypted files for cryptographic identifier classification."
            ]
        },
        {
            "id": "THR-006",
            "category": "Credential Access",
            "mitre_id": "T1110.004 - Credential Stuffing",
            "severity": "High",
            "regex": re.compile(r'(invalid user (root|admin|test|guest|user|oracle|postgres|ubuntu|support))', re.I),
            "threshold": 2,
            "title": "Account Enumeration / Credential Stuffing Pattern",
            "why_suspicious": (
                "Multiple attempts targeting default or service account identities (root, admin, postgres, oracle). "
                "Signals systematic enumeration designed to identify default credentials on exposed endpoints."
            ),
            "investigation_steps": [
                "Ensure root/administrator remote direct login via SSH or RDP is disabled (`PermitRootLogin no`).",
                "Validate that non-existent user accounts cannot be differentiated by response timings.",
                "Implement IP rate-limiting on authentication interfaces."
            ]
        }
    ]

    def analyze(self, logs_or_text: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        lines = logs_or_text.splitlines()
        total_events = len(lines)
        detected_observations = []
        overall_score = 0
        
        # Extract potential IOCs (IPs, MD5/SHA256 hashes, domains)
        ip_iocs = set(re.findall(r'(?:\d{1,3}\.){3}\d{1,3}', logs_or_text))
        hash_iocs = set(re.findall(r'\b[A-Fa-f0-9]{32,64}\b', logs_or_text))
        all_iocs = list(ip_iocs.union(hash_iocs))[:10]

        for p in self.PATTERNS:
            matches = p["regex"].findall(logs_or_text)
            match_count = len(matches)
            
            if match_count >= p["threshold"]:
                weight = 30 if p["severity"] == "Critical" else (20 if p["severity"] == "High" else 10)
                overall_score += weight
                
                # Confidence calculation based on match volume
                confidence = min(0.98, 0.65 + (match_count * 0.05))
                
                detected_observations.append({
                    "category": p["category"],
                    "severity": p["severity"],
                    "confidence": round(confidence, 2),
                    "title": p["title"],
                    "why_suspicious": p["why_suspicious"],
                    "detected_iocs": all_iocs,
                    "mitre_attack_id": p["mitre_id"],
                    "investigation_steps": p["investigation_steps"]
                })

        final_risk_score = min(100, max(15 if detected_observations else 5, overall_score))
        
        if final_risk_score >= 80:
            assessment = "CRITICAL THREAT: High-confidence hostile activity patterns and active exploit signatures detected."
        elif final_risk_score >= 50:
            assessment = "ELEVATED RISK: Multiple anomalous indicators requiring forensic investigator prioritization."
        elif final_risk_score >= 25:
            assessment = "MODERATE RISK: Isolated suspicious events detected. Recommend routine log auditing."
        else:
            assessment = "LOW RISK: Baseline normal operational log activity with minimal anomaly presence."

        return {
            "total_events_analyzed": max(1, total_events),
            "risk_score": final_risk_score,
            "overall_assessment": assessment,
            "observations": detected_observations,
            "disclaimer": (
                "AI / Rule-Based Threat Advisory: The identified patterns and heuristics "
                "represent investigative indicators requiring digital forensic validation. "
                "They do not constitute verified legal proof of attack."
            )
        }

# Factory/Singleton pattern for threat analysis
def get_threat_analyzer() -> BaseThreatEngine:
    # Future ML implementations (e.g. IsolationForestThreatEngine) can be selected via configuration
    return RuleBasedThreatEngine()
