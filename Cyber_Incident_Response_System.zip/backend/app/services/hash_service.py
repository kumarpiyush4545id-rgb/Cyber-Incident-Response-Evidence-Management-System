import os
import hashlib
import logging
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.evidence import Evidence
from app.models.chain_of_custody import ChainOfCustody
from app.models.security_alert import SecurityAlert
from app.services.audit_service import log_audit_event

logger = logging.getLogger("cirems.hash_service")

CHUNK_SIZE = 65536 # 64KB chunks for memory-efficient streaming hash calculation

def calculate_sha256_stream(file_obj) -> str:
    """Calculates SHA-256 hash of an open file-like object in chunks."""
    sha256_hash = hashlib.sha256()
    file_obj.seek(0)
    while chunk := file_obj.read(CHUNK_SIZE):
        sha256_hash.update(chunk)
    file_obj.seek(0)
    return sha256_hash.hexdigest()

def calculate_file_sha256(file_path: str) -> str:
    """Calculates SHA-256 hash of a file on disk."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found at path: {file_path}")
    
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(CHUNK_SIZE):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()

def verify_evidence_integrity(
    db: Session,
    evidence_id: int,
    user_id: int,
    username: str,
    ip_address: str = "127.0.0.1"
) -> dict:
    """
    Recalculates SHA-256 hash from physical storage, compares with original SHA-256,
    updates current hash and integrity status, and triggers alert if modified.
    NEVER overwrites original_sha256.
    """
    evidence = db.query(Evidence).filter(Evidence.id == evidence_id).first()
    if not evidence:
        raise ValueError("Evidence item not found")

    if not os.path.exists(evidence.storage_path):
        raise FileNotFoundError(f"Evidence file missing from disk: {evidence.storage_path}")

    # Recalculate current hash from physical storage
    recalculated_hash = calculate_file_sha256(evidence.storage_path)
    now_utc = datetime.now(timezone.utc)
    
    is_tampered = (recalculated_hash.lower() != evidence.original_sha256.lower())
    
    # Update current hash and verification status (original_sha256 is kept intact!)
    evidence.current_sha256 = recalculated_hash
    evidence.last_verified_at = now_utc
    evidence.integrity_status = "MODIFIED" if is_tampered else "VERIFIED"
    
    # Record Chain of Custody entry
    action_text = "Integrity Verification (TAMPER DETECTED)" if is_tampered else "Integrity Verification (VERIFIED)"
    remarks_text = (
        f"Forensic integrity check executed. Calculated: {recalculated_hash}. "
        f"{'CRITICAL WARNING: Hash mismatch with original evidentiary baseline!' if is_tampered else 'Cryptographic hash strictly matches baseline.'}"
    )
    
    # Generate unique COC record ID
    coc_count = db.query(ChainOfCustody).count() + 1
    coc_entry = ChainOfCustody(
        record_id=f"COC-{now_utc.year}-{coc_count:04d}",
        evidence_id=evidence.id,
        incident_id=evidence.incident_id,
        action=action_text,
        previous_custodian="Evidence Vault",
        new_custodian="Evidence Vault",
        performed_by_id=user_id,
        remarks=remarks_text,
        timestamp=now_utc
    )
    db.add(coc_entry)

    # If tampered, raise a high-severity security alert
    if is_tampered:
        alert = SecurityAlert(
            incident_id=evidence.incident_id,
            evidence_id=evidence.id,
            alert_type="Evidence Tampering",
            severity="Critical",
            title=f"CRYPTOGRAPHIC INTEGRITY FAILURE: Evidence {evidence.evidence_id} Modified",
            description=(
                f"Digital evidence file '{evidence.original_filename}' failed SHA-256 verification. "
                f"Baseline Hash: {evidence.original_sha256}. "
                f"Discovered Hash: {recalculated_hash}. "
                f"Potential unauthorized alteration or disk corruption detected."
            ),
            is_resolved=False
        )
        db.add(alert)
        logger.warning(f"CRITICAL: Evidence {evidence.evidence_id} hash mismatch detected!")

    db.commit()
    db.refresh(evidence)

    # Log audit event
    log_audit_event(
        db=db,
        action="VERIFY_EVIDENCE_HASH",
        resource_type="EVIDENCE",
        resource_id=evidence.evidence_id,
        user_id=user_id,
        username=username,
        ip_address=ip_address,
        details={
            "evidence_id": evidence.evidence_id,
            "original_sha256": evidence.original_sha256,
            "recalculated_sha256": recalculated_hash,
            "integrity_status": evidence.integrity_status,
            "is_tampered": is_tampered
        }
    )

    return {
        "evidence_id": evidence.evidence_id,
        "original_sha256": evidence.original_sha256,
        "current_sha256": recalculated_hash,
        "integrity_status": evidence.integrity_status,
        "verification_time": now_utc,
        "is_tampered": is_tampered,
        "message": (
            "ALERT: Evidence integrity check FAILED! SHA-256 hash mismatch indicates file modification."
            if is_tampered
            else "SUCCESS: Digital evidence integrity verified. SHA-256 matches baseline hash."
        )
    }

def simulate_tampering(
    db: Session,
    evidence_id: int,
    user_id: int,
    username: str,
    ip_address: str = "127.0.0.1"
) -> dict:
    """
    Simulation feature for technical jury / evaluation demonstration:
    Appends a discrete byte to the file to demonstrate real-world detection of unauthorized tampering.
    """
    evidence = db.query(Evidence).filter(Evidence.id == evidence_id).first()
    if not evidence or not os.path.exists(evidence.storage_path):
        raise ValueError("Evidence file not found")

    with open(evidence.storage_path, "ab") as f:
        f.write(b"\n[SIMULATED_UNAUTHORIZED_MODIFICATION_PAYLOAD]")

    # Immediately run verification to show the live detection
    return verify_evidence_integrity(
        db=db,
        evidence_id=evidence_id,
        user_id=user_id,
        username=username,
        ip_address=ip_address
    )
