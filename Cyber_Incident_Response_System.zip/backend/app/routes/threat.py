from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.incident import Incident
from app.models.log_analysis import LogAnalysis
from app.models.user import User
from app.schemas.threat import ThreatAnalysisRequest, ThreatAnalysisResultResponse
from app.security.dependencies import get_current_user
from app.services.ai_threat_service import get_threat_analyzer

router = APIRouter(prefix="/threat-intelligence", tags=["AI-Assisted Threat Analysis"])

@router.post("/analyze", response_model=ThreatAnalysisResultResponse)
def analyze_threats(
    request_in: ThreatAnalysisRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    text_to_analyze = ""

    # If an incident_id is passed, aggregate text from incident, attack details, and associated logs
    if request_in.incident_id:
        incident = db.query(Incident).filter(Incident.id == request_in.incident_id).first()
        if not incident:
            raise HTTPException(status_code=404, detail="Incident case not found.")
        
        parts = [
            f"Incident Category: {incident.category}",
            f"Description: {incident.description}",
            f"Source IP: {incident.source_ip}",
            f"Target System: {incident.affected_system}"
        ]
        for atk in incident.attack_details:
            parts.append(f"Attack Type: {atk.attack_type}")
            parts.append(f"Suspicious Activity: {atk.suspicious_activity_description}")
            parts.append(f"IOCs: {atk.indicators_of_compromise}")
        
        # Check if there are log analyses attached
        for log_an in incident.log_analyses:
            if log_an.raw_preview:
                sample_lines = [row.get("raw", "") for row in log_an.raw_preview[:30]]
                parts.extend(sample_lines)

        text_to_analyze = "\n".join(parts)

    elif request_in.log_text:
        text_to_analyze = request_in.log_text
    else:
        raise HTTPException(status_code=400, detail="Provide either an incident_id or log_text to evaluate.")

    engine = get_threat_analyzer()
    result = engine.analyze(text_to_analyze)
    result["incident_id"] = request_in.incident_id
    return result

@router.get("/incidents/{incident_id}", response_model=ThreatAnalysisResultResponse)
def get_incident_threat_evaluation(
    incident_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    req = ThreatAnalysisRequest(incident_id=incident_id)
    return analyze_threats(request_in=req, current_user=current_user, db=db)
