from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.security_alert import SecurityAlert
from app.models.user import User
from app.schemas.alert import SecurityAlertResponse, AlertResolveRequest
from app.security.dependencies import get_current_user, require_investigator
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/alerts", tags=["Security Alerts"])

@router.get("", response_model=List[SecurityAlertResponse])
def list_alerts(
    resolved: Optional[bool] = Query(None),
    severity: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(SecurityAlert)
    if resolved is not None:
        query = query.filter(SecurityAlert.is_resolved == resolved)
    if severity and severity != "All":
        query = query.filter(SecurityAlert.severity == severity)
    return query.order_by(SecurityAlert.created_at.desc()).all()

@router.put("/{id}/resolve", response_model=SecurityAlertResponse)
def resolve_alert(
    id: int,
    resolve_data: AlertResolveRequest,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    alert = db.query(SecurityAlert).filter(SecurityAlert.id == id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Security alert not found.")

    alert.is_resolved = resolve_data.is_resolved
    alert.resolved_by_id = current_user.id
    db.commit()
    db.refresh(alert)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="RESOLVE_ALERT",
        resource_type="SECURITY_ALERT",
        resource_id=str(alert.id),
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={"alert_title": alert.title, "resolved": alert.is_resolved}
    )

    return alert
