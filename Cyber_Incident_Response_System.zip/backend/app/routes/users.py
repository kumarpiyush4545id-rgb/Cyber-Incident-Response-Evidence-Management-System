from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import User
from app.schemas.user import UserResponse
from app.security.dependencies import require_investigator

router = APIRouter(prefix="/users", tags=["User Directory"])

@router.get("", response_model=List[UserResponse])
def list_investigators_and_users(
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    users = db.query(User).order_by(User.full_name.asc()).all()
    return users
