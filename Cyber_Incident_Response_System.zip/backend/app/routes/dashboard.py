from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models.incident import Incident
from app.models.evidence import Evidence
from app.models.chain_of_custody import ChainOfCustody
from app.models.log_analysis import LogAnalysis
from app.models.security_alert import SecurityAlert
from app.models.audit_log import AuditLog
from app.security.dependencies import get_current_user
from app.models.user import User

router = APIRouter(prefix="/dashboard", tags=["Security Dashboard"])

@router.get("/stats")
def get_dashboard_statistics(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    total_incidents = db.query(Incident).count()
    open_incidents = db.query(Incident).filter(Incident.status == "Open").count()
    under_investigation = db.query(Incident).filter(Incident.status == "Under Investigation").count()
    resolved_incidents = db.query(Incident).filter(Incident.status.in_(["Resolved", "Closed"])).count()
    
    critical_incidents = db.query(Incident).filter(Incident.severity == "Critical").count()
    high_incidents = db.query(Incident).filter(Incident.severity == "High").count()

    total_evidence = db.query(Evidence).count()
    verified_evidence = db.query(Evidence).filter(Evidence.integrity_status == "VERIFIED").count()
    modified_evidence = db.query(Evidence).filter(Evidence.integrity_status == "MODIFIED").count()

    total_alerts = db.query(SecurityAlert).count()
    unresolved_alerts = db.query(SecurityAlert).filter(SecurityAlert.is_resolved == False).count()

    total_logs_analyzed = db.query(func.sum(LogAnalysis.total_entries)).scalar() or 0

    # Severity distribution
    severities = ["Critical", "High", "Medium", "Low"]
    severity_distribution = []
    for s in severities:
        count = db.query(Incident).filter(Incident.severity == s).count()
        severity_distribution.append({"severity": s, "count": count})

    # Category distribution
    cat_counts = (
        db.query(Incident.category, func.count(Incident.id))
        .group_by(Incident.category)
        .all()
    )
    category_distribution = [{"category": c[0], "count": c[1]} for c in cat_counts]

    # Status distribution
    status_counts = (
        db.query(Incident.status, func.count(Incident.id))
        .group_by(Incident.status)
        .all()
    )
    status_distribution = [{"status": s[0], "count": s[1]} for s in status_counts]

    # Recent cases
    recent_incidents = (
        db.query(Incident)
        .order_by(Incident.created_at.desc())
        .limit(6)
        .all()
    )
    recent_incidents_data = [
        {
            "id": inc.id,
            "case_id": inc.case_id,
            "title": inc.title,
            "category": inc.category,
            "severity": inc.severity,
            "status": inc.status,
            "affected_system": inc.affected_system,
            "created_at": inc.created_at,
            "investigator": inc.assigned_investigator.full_name if inc.assigned_investigator else "Unassigned"
        }
        for inc in recent_incidents
    ]

    # Recent activity stream (Chain of Custody and Audit events)
    recent_activities = []
    recent_cocs = (
        db.query(ChainOfCustody)
        .order_by(ChainOfCustody.timestamp.desc())
        .limit(8)
        .all()
    )
    for c in recent_cocs:
        recent_activities.append({
            "id": f"coc-{c.id}",
            "type": "CUSTODY",
            "title": c.action,
            "description": c.remarks or f"Evidence #{c.evidence_id} transferred to {c.new_custodian}",
            "timestamp": c.timestamp,
            "performer": c.performed_by.full_name if c.performed_by else "Forensic System"
        })

    # 7-day timeline trends
    now = datetime.now(timezone.utc)
    timeline_trends = []
    for i in range(6, -1, -1):
        day_date = now - timedelta(days=i)
        day_str = day_date.strftime("%b %d")
        day_start = day_date.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_date.replace(hour=23, minute=59, second=59, microsecond=999999)
        
        inc_count = db.query(Incident).filter(
            Incident.created_at >= day_start,
            Incident.created_at <= day_end
        ).count()
        ev_count = db.query(Evidence).filter(
            Evidence.created_at >= day_start,
            Evidence.created_at <= day_end
        ).count()
        timeline_trends.append({
            "date": day_str,
            "incidents": inc_count,
            "evidence": ev_count
        })

    return {
        "total_incidents": total_incidents,
        "open_incidents": open_incidents,
        "under_investigation_incidents": under_investigation,
        "resolved_incidents": resolved_incidents,
        "critical_incidents": critical_incidents,
        "high_severity_incidents": high_incidents,
        "total_evidence_files": total_evidence,
        "verified_evidence_files": verified_evidence,
        "modified_evidence_files": modified_evidence,
        "total_log_events_analyzed": int(total_logs_analyzed),
        "total_alerts": total_alerts,
        "unresolved_alerts": unresolved_alerts,
        "severity_distribution": severity_distribution,
        "category_distribution": category_distribution,
        "status_distribution": status_distribution,
        "timeline_trends": timeline_trends,
        "recent_activities": recent_activities,
        "recent_incidents": recent_incidents_data
    }
