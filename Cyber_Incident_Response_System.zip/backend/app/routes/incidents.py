from datetime import datetime, timezone
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.database import get_db
from app.models.incident import Incident
from app.models.user import User
from app.schemas.incident import IncidentCreate, IncidentUpdate, IncidentResponse
from app.security.dependencies import get_current_user, require_investigator, require_admin
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/incidents", tags=["Incident Case Management"])

def generate_case_id(db: Session) -> str:
    year = datetime.now(timezone.utc).year
    # Find count of cases for this year
    count = db.query(Incident).count() + 1
    return f"CIR-{year}-{count:04d}"

@router.get("", response_model=List[IncidentResponse])
def list_incidents(
    severity: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Incident)

    if severity and severity != "All":
        query = query.filter(Incident.severity == severity)
    if status and status != "All":
        query = query.filter(Incident.status == status)
    if category and category != "All":
        query = query.filter(Incident.category == category)
    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                Incident.case_id.ilike(search_pattern),
                Incident.title.ilike(search_pattern),
                Incident.affected_system.ilike(search_pattern),
                Incident.source_ip.ilike(search_pattern)
            )
        )

    incidents = query.order_by(Incident.created_at.desc()).all()
    
    # Format response with extra computed fields
    res = []
    for inc in incidents:
        inc_dict = {
            "id": inc.id,
            "case_id": inc.case_id,
            "title": inc.title,
            "description": inc.description,
            "category": inc.category,
            "severity": inc.severity,
            "status": inc.status,
            "incident_datetime": inc.incident_datetime,
            "affected_system": inc.affected_system,
            "source_ip": inc.source_ip,
            "destination_ip": inc.destination_ip,
            "assigned_investigator_id": inc.assigned_investigator_id,
            "created_by_id": inc.created_by_id,
            "created_at": inc.created_at,
            "updated_at": inc.updated_at,
            "investigator_name": inc.assigned_investigator.full_name if inc.assigned_investigator else "Unassigned",
            "evidence_count": len(inc.evidence_items)
        }
        res.append(inc_dict)
    return res

@router.post("", response_model=IncidentResponse, status_code=status.HTTP_201_CREATED)
def create_incident(
    incident_in: IncidentCreate,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    case_id = generate_case_id(db)
    
    new_incident = Incident(
        case_id=case_id,
        title=incident_in.title,
        description=incident_in.description,
        category=incident_in.category,
        severity=incident_in.severity,
        status=incident_in.status or "Open",
        incident_datetime=incident_in.incident_datetime,
        affected_system=incident_in.affected_system,
        source_ip=incident_in.source_ip,
        destination_ip=incident_in.destination_ip,
        assigned_investigator_id=incident_in.assigned_investigator_id or current_user.id,
        created_by_id=current_user.id
    )
    db.add(new_incident)
    db.commit()
    db.refresh(new_incident)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="CREATE_INCIDENT",
        resource_type="INCIDENT",
        resource_id=new_incident.case_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={
            "case_id": new_incident.case_id,
            "severity": new_incident.severity,
            "category": new_incident.category
        }
    )

    return {
        "id": new_incident.id,
        "case_id": new_incident.case_id,
        "title": new_incident.title,
        "description": new_incident.description,
        "category": new_incident.category,
        "severity": new_incident.severity,
        "status": new_incident.status,
        "incident_datetime": new_incident.incident_datetime,
        "affected_system": new_incident.affected_system,
        "source_ip": new_incident.source_ip,
        "destination_ip": new_incident.destination_ip,
        "assigned_investigator_id": new_incident.assigned_investigator_id,
        "created_by_id": new_incident.created_by_id,
        "created_at": new_incident.created_at,
        "updated_at": new_incident.updated_at,
        "investigator_name": new_incident.assigned_investigator.full_name if new_incident.assigned_investigator else "Unassigned",
        "evidence_count": 0
    }

@router.get("/{id}")
def get_incident(
    id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    incident = db.query(Incident).filter(Incident.id == id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident case not found.")

    return {
        "id": incident.id,
        "case_id": incident.case_id,
        "title": incident.title,
        "description": incident.description,
        "category": incident.category,
        "severity": incident.severity,
        "status": incident.status,
        "incident_datetime": incident.incident_datetime,
        "affected_system": incident.affected_system,
        "source_ip": incident.source_ip,
        "destination_ip": incident.destination_ip,
        "assigned_investigator_id": incident.assigned_investigator_id,
        "investigator_name": incident.assigned_investigator.full_name if incident.assigned_investigator else "Unassigned",
        "created_by_id": incident.created_by_id,
        "created_at": incident.created_at,
        "updated_at": incident.updated_at,
        "attack_details": incident.attack_details,
        "evidence_items": incident.evidence_items,
        "reports": incident.reports,
        "alerts": incident.alerts
    }

@router.put("/{id}", response_model=IncidentResponse)
def update_incident(
    id: int,
    incident_update: IncidentUpdate,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    incident = db.query(Incident).filter(Incident.id == id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident case not found.")

    update_data = incident_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(incident, field, value)

    incident.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(incident)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="UPDATE_INCIDENT",
        resource_type="INCIDENT",
        resource_id=incident.case_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details=update_data
    )

    return {
        "id": incident.id,
        "case_id": incident.case_id,
        "title": incident.title,
        "description": incident.description,
        "category": incident.category,
        "severity": incident.severity,
        "status": incident.status,
        "incident_datetime": incident.incident_datetime,
        "affected_system": incident.affected_system,
        "source_ip": incident.source_ip,
        "destination_ip": incident.destination_ip,
        "assigned_investigator_id": incident.assigned_investigator_id,
        "created_by_id": incident.created_by_id,
        "created_at": incident.created_at,
        "updated_at": incident.updated_at,
        "investigator_name": incident.assigned_investigator.full_name if incident.assigned_investigator else "Unassigned",
        "evidence_count": len(incident.evidence_items)
    }

@router.delete("/{id}")
def delete_incident(
    id: int,
    request: Request,
    current_user: User = Depends(require_admin), # Admin permission enforced
    db: Session = Depends(get_db)
):
    incident = db.query(Incident).filter(Incident.id == id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident case not found.")

    case_id = incident.case_id
    client_ip = request.client.host if request.client else "127.0.0.1"

    db.delete(incident)
    db.commit()

    log_audit_event(
        db=db,
        action="DELETE_INCIDENT",
        resource_type="INCIDENT",
        resource_id=case_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={"case_id": case_id, "deleted_by": current_user.username}
    )

    return {"message": f"Incident case {case_id} has been permanently deleted and audit logged."}
