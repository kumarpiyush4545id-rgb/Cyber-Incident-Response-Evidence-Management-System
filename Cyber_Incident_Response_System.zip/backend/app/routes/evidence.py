import os
import shutil
import uuid
from datetime import datetime, timezone
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Request, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.config import settings
from app.database import get_db
from app.models.evidence import Evidence
from app.models.incident import Incident
from app.models.chain_of_custody import ChainOfCustody
from app.models.user import User
from app.schemas.evidence import EvidenceResponse, EvidenceVerifyResponse
from app.security.dependencies import get_current_user, require_investigator
from app.services.hash_service import calculate_file_sha256, verify_evidence_integrity, simulate_tampering
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/evidence", tags=["Digital Evidence Management"])

def generate_evidence_id(db: Session) -> str:
    year = datetime.now(timezone.utc).year
    count = db.query(Evidence).count() + 1
    return f"EVD-{year}-{count:04d}"

@router.get("", response_model=List[EvidenceResponse])
def list_evidence(
    incident_id: Optional[int] = Query(None),
    integrity_status: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Evidence)
    if incident_id is not None:
        query = query.filter(Evidence.incident_id == incident_id)
    if integrity_status and integrity_status != "All":
        query = query.filter(Evidence.integrity_status == integrity_status)
    if search:
        query = query.filter(
            (Evidence.evidence_id.ilike(f"%{search}%")) |
            (Evidence.original_filename.ilike(f"%{search}%")) |
            (Evidence.description.ilike(f"%{search}%"))
        )

    items = query.order_by(Evidence.created_at.desc()).all()
    results = []
    for item in items:
        results.append({
            **item.__dict__,
            "uploader_name": item.uploaded_by.full_name if item.uploaded_by else "System"
        })
    return results

@router.post("/upload", response_model=EvidenceResponse)
async def upload_evidence(
    request: Request,
    incident_id: int = Form(...),
    description: Optional[str] = Form(""),
    file: UploadFile = File(...),
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    # Verify incident case exists
    incident = db.query(Incident).filter(Incident.id == incident_id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Referenced incident case not found.")

    # Validate file extension
    filename = file.filename or "unknown_evidence.bin"
    ext = filename.split(".")[-1].lower() if "." in filename else ""
    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type .{ext}. Permitted formats: {', '.join(settings.ALLOWED_EXTENSIONS)}"
        )

    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    
    # Generate unique stored filename to prevent collisions & traversal
    unique_prefix = uuid.uuid4().hex[:12]
    safe_stored_name = f"{unique_prefix}_{filename.replace(' ', '_')}"
    file_path = os.path.join(settings.UPLOAD_DIR, safe_stored_name)

    # Save to disk
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    file_size = os.path.getsize(file_path)
    if file_size > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        os.remove(file_path)
        raise HTTPException(
            status_code=400,
            detail=f"File exceeds maximum allowed size ({settings.MAX_UPLOAD_SIZE_MB}MB)."
        )

    # Calculate cryptographic SHA-256 immediately after upload
    sha256_hash = calculate_file_sha256(file_path)
    now_utc = datetime.now(timezone.utc)
    evd_id = generate_evidence_id(db)

    new_evidence = Evidence(
        evidence_id=evd_id,
        incident_id=incident_id,
        original_filename=filename,
        stored_filename=safe_stored_name,
        file_type=ext.upper(),
        file_size=file_size,
        storage_path=file_path,
        original_sha256=sha256_hash,
        current_sha256=sha256_hash,
        integrity_status="VERIFIED",
        last_verified_at=now_utc,
        uploaded_by_id=current_user.id,
        description=description,
        created_at=now_utc
    )
    db.add(new_evidence)
    db.commit()
    db.refresh(new_evidence)

    # Automatically create initial Chain of Custody entry
    coc_count = db.query(ChainOfCustody).count() + 1
    coc_entry = ChainOfCustody(
        record_id=f"COC-{now_utc.year}-{coc_count:04d}",
        evidence_id=new_evidence.id,
        incident_id=incident_id,
        action="Evidence Uploaded",
        previous_custodian="Investigator Local Workspace",
        new_custodian="CIREMS Evidence Vault",
        performed_by_id=current_user.id,
        remarks=f"Initial ingestion. SHA-256 baseline computed: {sha256_hash}",
        timestamp=now_utc
    )
    db.add(coc_entry)
    db.commit()

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="UPLOAD_EVIDENCE",
        resource_type="EVIDENCE",
        resource_id=new_evidence.evidence_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={
            "case_id": incident.case_id,
            "filename": filename,
            "sha256": sha256_hash,
            "size": file_size
        }
    )

    return {
        "id": new_evidence.id,
        "evidence_id": new_evidence.evidence_id,
        "incident_id": new_evidence.incident_id,
        "original_filename": new_evidence.original_filename,
        "file_type": new_evidence.file_type,
        "file_size": new_evidence.file_size,
        "original_sha256": new_evidence.original_sha256,
        "current_sha256": new_evidence.current_sha256,
        "integrity_status": new_evidence.integrity_status,
        "last_verified_at": new_evidence.last_verified_at,
        "uploaded_by_id": new_evidence.uploaded_by_id,
        "uploader_name": current_user.full_name,
        "description": new_evidence.description,
        "created_at": new_evidence.created_at,
    }

@router.get("/{id}")
def get_evidence(
    id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ev = db.query(Evidence).filter(Evidence.id == id).first()
    if not ev:
        raise HTTPException(status_code=404, detail="Evidence item not found.")
    return {
        **ev.__dict__,
        "uploader_name": ev.uploaded_by.full_name if ev.uploaded_by else "System",
        "custody_records": ev.custody_records
    }

@router.post("/{id}/verify-hash", response_model=EvidenceVerifyResponse)
def recalculate_hash(
    id: int,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    """
    Recalculates SHA-256 cryptographic hash of evidence on disk, compares against original_sha256,
    updates integrity_status, records custody entry and fires security alert if tampered.
    """
    client_ip = request.client.host if request.client else "127.0.0.1"
    try:
        result = verify_evidence_integrity(
            db=db,
            evidence_id=id,
            user_id=current_user.id,
            username=current_user.username,
            ip_address=client_ip
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{id}/simulate-tamper", response_model=EvidenceVerifyResponse)
def simulate_evidence_tamper(
    id: int,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    """
    Simulates malicious file modification on disk for demonstration and jury testing,
    then automatically executes verification to demonstrate real-time tamper alert generation.
    """
    client_ip = request.client.host if request.client else "127.0.0.1"
    try:
        result = simulate_tampering(
            db=db,
            evidence_id=id,
            user_id=current_user.id,
            username=current_user.username,
            ip_address=client_ip
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{id}/download")
def download_evidence(
    id: int,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    ev = db.query(Evidence).filter(Evidence.id == id).first()
    if not ev or not os.path.exists(ev.storage_path):
        raise HTTPException(status_code=404, detail="Evidence file missing or not found.")

    now_utc = datetime.now(timezone.utc)
    client_ip = request.client.host if request.client else "127.0.0.1"

    # Log chain of custody download
    coc_count = db.query(ChainOfCustody).count() + 1
    coc_entry = ChainOfCustody(
        record_id=f"COC-{now_utc.year}-{coc_count:04d}",
        evidence_id=ev.id,
        incident_id=ev.incident_id,
        action="Evidence Downloaded",
        previous_custodian="CIREMS Evidence Vault",
        new_custodian=f"Forensic Examiner ({current_user.full_name})",
        performed_by_id=current_user.id,
        remarks=f"Forensic export for offline lab examination. Client IP: {client_ip}",
        timestamp=now_utc
    )
    db.add(coc_entry)
    db.commit()

    log_audit_event(
        db=db,
        action="DOWNLOAD_EVIDENCE",
        resource_type="EVIDENCE",
        resource_id=ev.evidence_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={"filename": ev.original_filename}
    )

    return FileResponse(
        path=ev.storage_path,
        filename=ev.original_filename,
        media_type="application/octet-stream"
    )
