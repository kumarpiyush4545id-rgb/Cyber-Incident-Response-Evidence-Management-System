from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.chain_of_custody import ChainOfCustody
from app.models.evidence import Evidence
from app.models.user import User
from app.schemas.chain_of_custody import CustodyResponse, CustodyTransferRequest
from app.security.dependencies import get_current_user, require_investigator
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/chain-of-custody", tags=["Chain of Custody Management"])

@router.get("", response_model=List[CustodyResponse])
def get_chain_of_custody(
    incident_id: Optional[int] = Query(None),
    evidence_id: Optional[int] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(ChainOfCustody)
    if incident_id is not None:
        query = query.filter(ChainOfCustody.incident_id == incident_id)
    if evidence_id is not None:
        query = query.filter(ChainOfCustody.evidence_id == evidence_id)

    # Strictly chronological order (oldest to newest for timeline presentation)
    records = query.order_by(ChainOfCustody.timestamp.asc()).all()

    results = []
    for r in records:
        results.append({
            **r.__dict__,
            "performer_name": r.performed_by.full_name if r.performed_by else "System"
        })
    return results

@router.post("/transfer", response_model=CustodyResponse)
def transfer_custody(
    transfer_in: CustodyTransferRequest,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    evidence = db.query(Evidence).filter(Evidence.id == transfer_in.evidence_id).first()
    if not evidence:
        raise HTTPException(status_code=404, detail="Referenced digital evidence not found.")

    # Find the latest custody record to establish previous custodian
    latest_record = (
        db.query(ChainOfCustody)
        .filter(ChainOfCustody.evidence_id == evidence.id)
        .order_by(ChainOfCustody.timestamp.desc())
        .first()
    )
    previous_custodian = latest_record.new_custodian if latest_record else "CIREMS Evidence Vault"

    now_utc = datetime.now(timezone.utc)
    coc_count = db.query(ChainOfCustody).count() + 1
    record_id = f"COC-{now_utc.year}-{coc_count:04d}"

    new_record = ChainOfCustody(
        record_id=record_id,
        evidence_id=evidence.id,
        incident_id=evidence.incident_id,
        action="Custody Handover / Transfer",
        previous_custodian=previous_custodian,
        new_custodian=transfer_in.new_custodian,
        performed_by_id=current_user.id,
        remarks=transfer_in.remarks,
        timestamp=now_utc
    )
    db.add(new_record)
    db.commit()
    db.refresh(new_record)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="TRANSFER_CUSTODY",
        resource_type="CHAIN_OF_CUSTODY",
        resource_id=new_record.record_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={
            "evidence_id": evidence.evidence_id,
            "from": previous_custodian,
            "to": transfer_in.new_custodian
        }
    )

    return {
        "id": new_record.id,
        "record_id": new_record.record_id,
        "evidence_id": new_record.evidence_id,
        "incident_id": new_record.incident_id,
        "action": new_record.action,
        "previous_custodian": new_record.previous_custodian,
        "new_custodian": new_record.new_custodian,
        "performed_by_id": new_record.performed_by_id,
        "performer_name": current_user.full_name,
        "remarks": new_record.remarks,
        "timestamp": new_record.timestamp,
    }
