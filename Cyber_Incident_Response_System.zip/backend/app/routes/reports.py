import os
from datetime import datetime, timezone
from typing import List
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.investigation_report import InvestigationReport
from app.models.incident import Incident
from app.models.user import User
from app.schemas.report import ReportResponse, ReportGenerateRequest
from app.security.dependencies import get_current_user, require_investigator
from app.services.pdf_report_service import generate_forensic_pdf_report
from app.services.ai_threat_service import get_threat_analyzer
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/reports", tags=["Investigation Report Generation"])

def generate_report_id(db: Session) -> str:
    year = datetime.now(timezone.utc).year
    count = db.query(InvestigationReport).count() + 1
    return f"RPT-{year}-{count:04d}"

@router.get("", response_model=List[ReportResponse])
def list_reports(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    reports = db.query(InvestigationReport).order_by(InvestigationReport.created_at.desc()).all()
    results = []
    for r in reports:
        results.append({
            **r.__dict__,
            "generator_name": r.generated_by.full_name if r.generated_by else "System"
        })
    return results

@router.post("/generate/{incident_id}", response_model=ReportResponse)
def generate_report(
    incident_id: int,
    report_in: ReportGenerateRequest,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    incident = db.query(Incident).filter(Incident.id == incident_id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident case not found.")

    # 1. Package incident dictionary
    incident_dict = {
        "case_id": incident.case_id,
        "title": incident.title,
        "description": incident.description,
        "category": incident.category,
        "severity": incident.severity,
        "status": incident.status,
        "incident_datetime": incident.incident_datetime,
        "affected_system": incident.affected_system,
        "source_ip": incident.source_ip,
        "destination_ip": incident.destination_ip,
        "investigator_name": incident.assigned_investigator.full_name if incident.assigned_investigator else current_user.full_name
    }

    # 2. Package attack details
    attack_data = [atk.__dict__ for atk in incident.attack_details]

    # 3. Package digital evidence
    evidence_data = [ev.__dict__ for ev in incident.evidence_items]

    # 4. Package chain of custody
    custody_data = [coc.__dict__ for coc in incident.custody_records]

    # 5. Compute AI threat evaluation for report
    threat_engine = get_threat_analyzer()
    corpus = f"{incident.title}\n{incident.description}\n{incident.category}"
    for atk in incident.attack_details:
        corpus += f"\n{atk.suspicious_activity_description or ''}\n{atk.investigator_observations or ''}"
    threat_findings = threat_engine.analyze(corpus)

    # 6. Generate Forensic PDF via ReportLab
    pdf_path = generate_forensic_pdf_report(
        incident_data=incident_dict,
        attack_data=attack_data,
        evidence_data=evidence_data,
        custody_data=custody_data,
        threat_findings=threat_findings,
        investigator_notes=report_in.investigator_notes or ""
    )

    file_size = os.path.getsize(pdf_path) if os.path.exists(pdf_path) else 0
    report_id = generate_report_id(db)
    now_utc = datetime.now(timezone.utc)

    report_title = report_in.title or f"Forensic Dossier: {incident.case_id} - {incident.title}"
    new_report = InvestigationReport(
        report_id=report_id,
        incident_id=incident.id,
        title=report_title,
        summary=f"Official forensic report for incident {incident.case_id}. Contains {len(evidence_data)} evidence records and {len(custody_data)} custody audits.",
        file_path=pdf_path,
        file_size=file_size,
        generated_by_id=current_user.id,
        created_at=now_utc
    )
    db.add(new_report)
    db.commit()
    db.refresh(new_report)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="GENERATE_INVESTIGATION_REPORT",
        resource_type="REPORT",
        resource_id=new_report.report_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={"case_id": incident.case_id, "pdf_path": pdf_path}
    )

    return {
        "id": new_report.id,
        "report_id": new_report.report_id,
        "incident_id": new_report.incident_id,
        "title": new_report.title,
        "summary": new_report.summary,
        "file_path": new_report.file_path,
        "file_size": new_report.file_size,
        "generated_by_id": new_report.generated_by_id,
        "generator_name": current_user.full_name,
        "created_at": new_report.created_at,
    }

@router.get("/{id}/download")
def download_report(
    id: int,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    report = db.query(InvestigationReport).filter(InvestigationReport.id == id).first()
    if not report or not os.path.exists(report.file_path):
        raise HTTPException(status_code=404, detail="Investigation report PDF file not found.")

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="DOWNLOAD_INVESTIGATION_REPORT",
        resource_type="REPORT",
        resource_id=report.report_id,
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={"report_id": report.report_id}
    )

    filename = os.path.basename(report.file_path)
    return FileResponse(
        path=report.file_path,
        filename=filename,
        media_type="application/pdf"
    )
