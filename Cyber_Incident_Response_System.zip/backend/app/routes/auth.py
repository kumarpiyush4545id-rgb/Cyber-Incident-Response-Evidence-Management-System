from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import User
from app.schemas.user import UserRegister, UserLogin, UserResponse, Token
from app.security.auth import get_password_hash, verify_password, create_access_token
from app.security.dependencies import get_current_user
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/auth", tags=["Authentication & User Management"])

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(user_in: UserRegister, request: Request, db: Session = Depends(get_db)):
    # Check if username or email exists
    existing = db.query(User).filter(
        (User.username == user_in.username) | (User.email == user_in.email)
    ).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or email is already registered."
        )

    # Validate role
    role = user_in.role if user_in.role in ["admin", "investigator"] else "investigator"

    new_user = User(
        username=user_in.username,
        email=user_in.email,
        hashed_password=get_password_hash(user_in.password),
        full_name=user_in.full_name,
        role=role,
        department=user_in.department or "SOC Operations",
        badge_number=user_in.badge_number
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="USER_REGISTER",
        resource_type="USER",
        resource_id=str(new_user.id),
        user_id=new_user.id,
        username=new_user.username,
        ip_address=client_ip,
        details={"role": new_user.role, "email": new_user.email}
    )

    token = create_access_token({"sub": new_user.username, "role": new_user.role})
    return {"access_token": token, "token_type": "bearer", "user": new_user}

@router.post("/login", response_model=Token)
def login(login_data: UserLogin, request: Request, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == login_data.username).first()
    client_ip = request.client.host if request.client else "127.0.0.1"

    if not user or not verify_password(login_data.password, user.hashed_password):
        log_audit_event(
            db=db,
            action="LOGIN_FAILED",
            resource_type="USER",
            resource_id=login_data.username,
            user_id=None,
            username=login_data.username,
            ip_address=client_ip,
            details={"reason": "Invalid credentials"}
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password."
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is deactivated. Contact administrator."
        )

    log_audit_event(
        db=db,
        action="LOGIN_SUCCESS",
        resource_type="USER",
        resource_id=str(user.id),
        user_id=user.id,
        username=user.username,
        ip_address=client_ip,
        details={"role": user.role}
    )

    token = create_access_token({"sub": user.username, "role": user.role})
    return {"access_token": token, "token_type": "bearer", "user": user}

@router.get("/me", response_model=UserResponse)
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    return current_user

@router.post("/logout")
def logout(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    log_audit_event(
        db=db,
        action="USER_LOGOUT",
        resource_type="USER",
        resource_id=str(current_user.id),
        user_id=current_user.id,
        username=current_user.username
    )
    return {"message": "Logged out successfully."}
