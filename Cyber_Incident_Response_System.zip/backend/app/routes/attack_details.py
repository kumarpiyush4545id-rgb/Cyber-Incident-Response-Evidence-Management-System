from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.attack_detail import AttackDetail
from app.models.incident import Incident
from app.models.user import User
from app.schemas.attack_detail import AttackDetailCreate, AttackDetailUpdate, AttackDetailResponse
from app.security.dependencies import get_current_user, require_investigator
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/attack-details", tags=["Attack Detail Recording"])

@router.get("", response_model=List[AttackDetailResponse])
def get_attack_details(
    incident_id: Optional[int] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(AttackDetail)
    if incident_id is not None:
        query = query.filter(AttackDetail.incident_id == incident_id)
    return query.order_by(AttackDetail.created_at.desc()).all()

@router.post("", response_model=AttackDetailResponse)
def create_attack_detail(
    attack_in: AttackDetailCreate,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    # Verify incident exists
    incident = db.query(Incident).filter(Incident.id == attack_in.incident_id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Referenced incident case not found.")

    new_attack = AttackDetail(
        incident_id=attack_in.incident_id,
        attack_type=attack_in.attack_type,
        attack_source=attack_in.attack_source,
        attack_vector=attack_in.attack_vector,
        target_system=attack_in.target_system,
        source_ip=attack_in.source_ip,
        destination_ip=attack_in.destination_ip,
        attack_timestamp=attack_in.attack_timestamp or datetime.now(timezone.utc),
        indicators_of_compromise=attack_in.indicators_of_compromise or [],
        mitre_tactics=attack_in.mitre_tactics,
        suspicious_activity_description=attack_in.suspicious_activity_description,
        investigator_observations=attack_in.investigator_observations
    )
    db.add(new_attack)
    db.commit()
    db.refresh(new_attack)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="RECORD_ATTACK_DETAIL",
        resource_type="ATTACK_DETAIL",
        resource_id=str(new_attack.id),
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={
            "case_id": incident.case_id,
            "attack_type": new_attack.attack_type,
            "attack_vector": new_attack.attack_vector
        }
    )

    return new_attack

@router.put("/{id}", response_model=AttackDetailResponse)
def update_attack_detail(
    id: int,
    attack_update: AttackDetailUpdate,
    request: Request,
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    attack = db.query(AttackDetail).filter(AttackDetail.id == id).first()
    if not attack:
        raise HTTPException(status_code=404, detail="Attack detail record not found.")

    update_data = attack_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(attack, field, value)

    attack.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(attack)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="UPDATE_ATTACK_DETAIL",
        resource_type="ATTACK_DETAIL",
        resource_id=str(attack.id),
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details=update_data
    )

    return attack
