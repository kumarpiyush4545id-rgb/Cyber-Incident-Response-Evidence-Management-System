from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Request, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.log_analysis import LogAnalysis
from app.models.incident import Incident
from app.models.user import User
from app.schemas.log_analysis import LogAnalysisResponse
from app.security.dependencies import get_current_user, require_investigator
from app.services.log_parser_service import parse_log_content
from app.services.ai_threat_service import get_threat_analyzer
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/logs", tags=["Security Log Analysis"])

@router.get("/analyses", response_model=List[LogAnalysisResponse])
def list_log_analyses(
    incident_id: Optional[int] = Query(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(LogAnalysis)
    if incident_id is not None:
        query = query.filter(LogAnalysis.incident_id == incident_id)
    return query.order_by(LogAnalysis.created_at.desc()).all()

@router.get("/analyses/{id}", response_model=LogAnalysisResponse)
def get_log_analysis(
    id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = db.query(LogAnalysis).filter(LogAnalysis.id == id).first()
    if not analysis:
        raise HTTPException(status_code=404, detail="Log analysis record not found.")
    return analysis

@router.post("/upload-and-analyze", response_model=LogAnalysisResponse)
async def upload_and_analyze_logs(
    request: Request,
    log_name: str = Form("Security_Log_Upload.log"),
    log_type: str = Form("Authentication"),
    incident_id: Optional[int] = Form(None),
    raw_text: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    current_user: User = Depends(require_investigator),
    db: Session = Depends(get_db)
):
    content_str = ""
    if file:
        content_bytes = await file.read()
        try:
            content_str = content_bytes.decode("utf-8", errors="replace")
        except Exception:
            content_str = str(content_bytes)
        log_name = file.filename or log_name
    elif raw_text:
        content_str = raw_text
    else:
        raise HTTPException(status_code=400, detail="Please upload a log file or paste log text to analyze.")

    if not content_str.strip():
        raise HTTPException(status_code=400, detail="The provided log content is empty.")

    # 1. Parse logs using Pandas & Regex engine
    parsed_results = parse_log_content(content_str, log_type=log_type)

    # 2. Correlate with AI Threat heuristics for detected patterns
    threat_engine = get_threat_analyzer()
    threat_eval = threat_engine.analyze(content_str)
    
    # Format detected threat patterns for storage
    detected_patterns = [
        {
            "category": obs["category"],
            "severity": obs["severity"],
            "title": obs["title"],
            "confidence": obs["confidence"],
            "mitre_id": obs.get("mitre_attack_id"),
            "why_suspicious": obs["why_suspicious"],
            "recommended_action": " | ".join(obs.get("investigation_steps", [])[:2])
        }
        for obs in threat_eval.get("observations", [])
    ]

    now_utc = datetime.now(timezone.utc)
    new_analysis = LogAnalysis(
        incident_id=incident_id,
        log_name=log_name,
        log_type=log_type,
        total_entries=parsed_results["total_entries"],
        failed_logins=parsed_results["failed_logins"],
        suspicious_ips=parsed_results["suspicious_ips"],
        detected_patterns=detected_patterns,
        summary_stats=parsed_results["summary_stats"],
        raw_preview=parsed_results["raw_preview"],
        analysis_findings=parsed_results["findings_summary"],
        analyzed_by_id=current_user.id,
        created_at=now_utc
    )
    db.add(new_analysis)
    db.commit()
    db.refresh(new_analysis)

    client_ip = request.client.host if request.client else "127.0.0.1"
    log_audit_event(
        db=db,
        action="ANALYZE_LOGS",
        resource_type="LOG_ANALYSIS",
        resource_id=str(new_analysis.id),
        user_id=current_user.id,
        username=current_user.username,
        ip_address=client_ip,
        details={
            "log_name": log_name,
            "total_entries": parsed_results["total_entries"],
            "failed_logins": parsed_results["failed_logins"]
        }
    )

    return new_analysis
