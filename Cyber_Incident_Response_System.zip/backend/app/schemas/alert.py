from typing import Optional
from datetime import datetime
from pydantic import BaseModel

class SecurityAlertResponse(BaseModel):
    id: int
    incident_id: Optional[int] = None
    evidence_id: Optional[int] = None
    alert_type: str
    severity: str
    title: str
    description: str
    is_resolved: bool
    resolved_by_id: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True

class AlertResolveRequest(BaseModel):
    is_resolved: bool = True
