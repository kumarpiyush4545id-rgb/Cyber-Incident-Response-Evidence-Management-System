from typing import Optional
from datetime import datetime
from pydantic import BaseModel

class EvidenceResponse(BaseModel):
    id: int
    evidence_id: str
    incident_id: int
    original_filename: str
    file_type: str
    file_size: int
    original_sha256: str
    current_sha256: str
    integrity_status: str
    last_verified_at: datetime
    uploaded_by_id: Optional[int] = None
    uploader_name: Optional[str] = None
    description: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class EvidenceVerifyResponse(BaseModel):
    evidence_id: str
    original_sha256: str
    current_sha256: str
    integrity_status: str # "VERIFIED" or "MODIFIED"
    verification_time: datetime
    is_tampered: bool
    message: str
