from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel

class SuspiciousIPItem(BaseModel):
    ip: str
    failure_count: int
    first_seen: Optional[str] = None
    last_seen: Optional[str] = None
    targeted_users: List[str] = []
    risk_score: int
    threat_category: str

class DetectedThreatPattern(BaseModel):
    pattern_id: str
    name: str
    severity: str
    count: int
    description: str
    sample_entry: Optional[str] = None
    recommended_action: str

class LogAnalysisResponse(BaseModel):
    id: int
    incident_id: Optional[int] = None
    log_name: str
    log_type: str
    total_entries: int
    failed_logins: int
    suspicious_ips: List[Dict[str, Any]]
    detected_patterns: List[Dict[str, Any]]
    summary_stats: Dict[str, Any]
    raw_preview: List[Dict[str, Any]]
    analysis_findings: Optional[str] = None
    analyzed_by_id: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True
