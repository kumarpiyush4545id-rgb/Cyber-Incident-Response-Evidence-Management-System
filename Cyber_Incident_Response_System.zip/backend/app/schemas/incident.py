from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel

class IncidentBase(BaseModel):
    title: str
    description: str
    category: str
    severity: str
    status: Optional[str] = "Open"
    incident_datetime: datetime
    affected_system: str
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None
    assigned_investigator_id: Optional[int] = None

class IncidentCreate(IncidentBase):
    pass

class IncidentUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    severity: Optional[str] = None
    status: Optional[str] = None
    incident_datetime: Optional[datetime] = None
    affected_system: Optional[str] = None
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None
    assigned_investigator_id: Optional[int] = None

class IncidentResponse(IncidentBase):
    id: int
    case_id: str
    created_by_id: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    investigator_name: Optional[str] = None
    evidence_count: Optional[int] = 0

    class Config:
        from_attributes = True
