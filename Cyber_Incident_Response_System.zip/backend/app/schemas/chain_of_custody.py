from typing import Optional
from datetime import datetime
from pydantic import BaseModel

class CustodyCreate(BaseModel):
    evidence_id: int
    incident_id: int
    action: str
    previous_custodian: Optional[str] = None
    new_custodian: Optional[str] = None
    remarks: Optional[str] = None

class CustodyTransferRequest(BaseModel):
    evidence_id: int
    new_custodian: str
    remarks: str

class CustodyResponse(BaseModel):
    id: int
    record_id: str
    evidence_id: int
    incident_id: int
    action: str
    previous_custodian: Optional[str] = None
    new_custodian: Optional[str] = None
    performed_by_id: Optional[int] = None
    performer_name: Optional[str] = None
    remarks: Optional[str] = None
    timestamp: datetime

    class Config:
        from_attributes = True
