from typing import Optional, List, Any
from datetime import datetime
from pydantic import BaseModel

class AttackDetailBase(BaseModel):
    attack_type: str
    attack_source: Optional[str] = None
    attack_vector: Optional[str] = None
    target_system: Optional[str] = None
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None
    attack_timestamp: Optional[datetime] = None
    indicators_of_compromise: Optional[List[Any]] = []
    mitre_tactics: Optional[str] = None
    suspicious_activity_description: Optional[str] = None
    investigator_observations: Optional[str] = None

class AttackDetailCreate(AttackDetailBase):
    incident_id: int

class AttackDetailUpdate(BaseModel):
    attack_type: Optional[str] = None
    attack_source: Optional[str] = None
    attack_vector: Optional[str] = None
    target_system: Optional[str] = None
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None
    attack_timestamp: Optional[datetime] = None
    indicators_of_compromise: Optional[List[Any]] = None
    mitre_tactics: Optional[str] = None
    suspicious_activity_description: Optional[str] = None
    investigator_observations: Optional[str] = None

class AttackDetailResponse(AttackDetailBase):
    id: int
    incident_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
