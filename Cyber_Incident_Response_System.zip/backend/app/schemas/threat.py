from typing import List, Dict, Any, Optional
from pydantic import BaseModel

class ThreatAnalysisRequest(BaseModel):
    incident_id: Optional[int] = None
    log_text: Optional[str] = None
    log_type: Optional[str] = "Authentication"

class ThreatObservation(BaseModel):
    category: str
    severity: str
    confidence: float
    title: str
    why_suspicious: str
    detected_iocs: List[str]
    mitre_attack_id: Optional[str] = None
    investigation_steps: List[str]

class ThreatAnalysisResultResponse(BaseModel):
    incident_id: Optional[int] = None
    total_events_analyzed: int
    risk_score: int # 0 - 100
    overall_assessment: str
    observations: List[ThreatObservation]
    disclaimer: str = (
        "AI / Rule-Based Threat Advisory: The identified patterns and heuristics "
        "represent investigative indicators requiring digital forensic validation. "
        "They do not constitute verified legal proof of attack."
    )
