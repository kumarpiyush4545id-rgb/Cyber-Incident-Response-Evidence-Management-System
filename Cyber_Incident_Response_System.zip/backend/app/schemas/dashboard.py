from typing import List, Dict, Any
from pydantic import BaseModel

class DashboardStatsResponse(BaseModel):
    total_incidents: int
    open_incidents: int
    under_investigation_incidents: int
    resolved_incidents: int
    critical_incidents: int
    high_severity_incidents: int
    total_evidence_files: int
    verified_evidence_files: int
    modified_evidence_files: int
    total_log_events_analyzed: int
    total_alerts: int
    unresolved_alerts: int
    severity_distribution: List[Dict[str, Any]]
    category_distribution: List[Dict[str, Any]]
    status_distribution: List[Dict[str, Any]]
    timeline_trends: List[Dict[str, Any]]
    recent_activities: List[Dict[str, Any]]
    recent_incidents: List[Dict[str, Any]]
