from typing import Optional
from datetime import datetime
from pydantic import BaseModel

class ReportGenerateRequest(BaseModel):
    incident_id: int
    title: Optional[str] = None
    investigator_notes: Optional[str] = None

class ReportResponse(BaseModel):
    id: int
    report_id: str
    incident_id: int
    title: str
    summary: Optional[str] = None
    file_path: str
    file_size: Optional[int] = None
    generated_by_id: Optional[int] = None
    generator_name: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
