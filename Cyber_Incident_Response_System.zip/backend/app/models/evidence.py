from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, BigInteger, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(Integer, primary_key=True, index=True)
    evidence_id = Column(String(50), unique=True, index=True, nullable=False) # e.g. EVD-2026-001
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False, index=True)
    original_filename = Column(String(255), nullable=False)
    stored_filename = Column(String(255), nullable=False)
    file_type = Column(String(20), nullable=False) # TXT, PDF, CSV, LOG, PNG, JPG, JSON
    file_size = Column(BigInteger, nullable=False)
    storage_path = Column(String(500), nullable=False)
    
    # Cryptographic integrity verification fields
    original_sha256 = Column(String(64), nullable=False) # NEVER overwritten during recalculation
    current_sha256 = Column(String(64), nullable=False)
    integrity_status = Column(String(20), default="VERIFIED", nullable=False) # VERIFIED, MODIFIED, UNVERIFIED
    last_verified_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    
    uploaded_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    incident = relationship("Incident", back_populates="evidence_items")
    uploaded_by = relationship("User", back_populates="evidence_uploads")
    custody_records = relationship("ChainOfCustody", back_populates="evidence", cascade="all, delete-orphan")
