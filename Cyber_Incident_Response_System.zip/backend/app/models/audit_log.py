from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON
from app.database import Base

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    username = Column(String(100), nullable=True)
    action = Column(String(100), nullable=False) # e.g. USER_LOGIN, CREATE_INCIDENT, VERIFY_EVIDENCE, DOWNLOAD_REPORT
    resource_type = Column(String(50), nullable=False) # INCIDENT, EVIDENCE, COC, LOG_ANALYSIS, USER
    resource_id = Column(String(50), nullable=True)
    ip_address = Column(String(64), nullable=True)
    details = Column(JSON, default=dict)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
