from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database import Base

class AttackDetail(Base):
    __tablename__ = "attack_details"

    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False, index=True)
    attack_type = Column(String(100), nullable=False) # e.g. Phishing, Ransomware, SQL Injection
    attack_source = Column(String(150), nullable=True) # e.g. External Threat Actor, Malicious Insider
    attack_vector = Column(String(150), nullable=True) # e.g. Spearphishing Email, RDP Exploit
    target_system = Column(String(255), nullable=True)
    source_ip = Column(String(64), nullable=True)
    destination_ip = Column(String(64), nullable=True)
    attack_timestamp = Column(DateTime, nullable=True)
    indicators_of_compromise = Column(JSON, default=list) # List of IOCs (hashes, C2 domains, malicious IPs)
    mitre_tactics = Column(String(255), nullable=True) # e.g. Initial Access, Persistence
    suspicious_activity_description = Column(Text, nullable=True)
    investigator_observations = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    incident = relationship("Incident", back_populates="attack_details")
