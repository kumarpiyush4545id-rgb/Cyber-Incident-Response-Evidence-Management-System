from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database import Base

class LogAnalysis(Base):
    __tablename__ = "log_analysis"

    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="SET NULL"), nullable=True, index=True)
    log_name = Column(String(255), nullable=False)
    log_type = Column(String(50), nullable=False) # Server, Authentication, Firewall, Network, Application
    total_entries = Column(Integer, default=0, nullable=False)
    failed_logins = Column(Integer, default=0, nullable=False)
    suspicious_ips = Column(JSON, default=list) # List of suspicious IP objects
    detected_patterns = Column(JSON, default=list) # Threat patterns & anomaly detections
    summary_stats = Column(JSON, default=dict) # Aggregated stats (status code distribution, hourly volume)
    raw_preview = Column(JSON, default=list) # Sample parsed entries for table view
    analysis_findings = Column(Text, nullable=True)
    analyzed_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    incident = relationship("Incident", back_populates="log_analyses")
    analyzed_by = relationship("User")
