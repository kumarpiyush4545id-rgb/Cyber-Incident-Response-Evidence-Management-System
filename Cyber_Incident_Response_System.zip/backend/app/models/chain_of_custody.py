from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class ChainOfCustody(Base):
    __tablename__ = "chain_of_custody"

    id = Column(Integer, primary_key=True, index=True)
    record_id = Column(String(50), unique=True, index=True, nullable=False) # e.g. COC-2026-001
    evidence_id = Column(Integer, ForeignKey("evidence.id", ondelete="CASCADE"), nullable=False, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String(100), nullable=False) # Evidence Collected, Evidence Uploaded, Evidence Accessed, Evidence Transferred, Evidence Verified, Evidence Downloaded
    previous_custodian = Column(String(150), nullable=True)
    new_custodian = Column(String(150), nullable=True)
    performed_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    remarks = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    # Relationships
    evidence = relationship("Evidence", back_populates="custody_records")
    incident = relationship("Incident", back_populates="custody_records")
    performed_by = relationship("User")
