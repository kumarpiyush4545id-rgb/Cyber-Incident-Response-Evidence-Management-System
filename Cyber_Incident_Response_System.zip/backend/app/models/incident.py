from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class Incident(Base):
    __tablename__ = "incidents"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(String(50), unique=True, index=True, nullable=False) # e.g. CIR-2026-001
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(100), nullable=False) # Phishing, Malware, Ransomware, Unauthorized Access, Brute Force, Denial of Service, Data Breach
    severity = Column(String(20), nullable=False) # Low, Medium, High, Critical
    status = Column(String(30), default="Open", nullable=False) # Open, Under Investigation, Resolved, Closed
    incident_datetime = Column(DateTime, nullable=False)
    affected_system = Column(String(255), nullable=False)
    source_ip = Column(String(64), nullable=True)
    destination_ip = Column(String(64), nullable=True)
    
    assigned_investigator_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    assigned_investigator = relationship("User", foreign_keys=[assigned_investigator_id], back_populates="assigned_incidents")
    created_by = relationship("User", foreign_keys=[created_by_id], back_populates="created_incidents")
    attack_details = relationship("AttackDetail", back_populates="incident", cascade="all, delete-orphan")
    evidence_items = relationship("Evidence", back_populates="incident", cascade="all, delete-orphan")
    custody_records = relationship("ChainOfCustody", back_populates="incident", cascade="all, delete-orphan")
    log_analyses = relationship("LogAnalysis", back_populates="incident")
    reports = relationship("InvestigationReport", back_populates="incident", cascade="all, delete-orphan")
    alerts = relationship("SecurityAlert", back_populates="incident", cascade="all, delete-orphan")
