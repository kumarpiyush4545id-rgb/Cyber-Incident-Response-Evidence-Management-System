from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.orm import relationship
from app.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, index=True, nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(150), nullable=False)
    role = Column(String(50), default="investigator", nullable=False)  # "admin", "investigator"
    department = Column(String(100), default="SOC Operations")
    badge_number = Column(String(50), unique=True, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    assigned_incidents = relationship("Incident", foreign_keys="Incident.assigned_investigator_id", back_populates="assigned_investigator")
    created_incidents = relationship("Incident", foreign_keys="Incident.created_by_id", back_populates="created_by")
    evidence_uploads = relationship("Evidence", back_populates="uploaded_by")
