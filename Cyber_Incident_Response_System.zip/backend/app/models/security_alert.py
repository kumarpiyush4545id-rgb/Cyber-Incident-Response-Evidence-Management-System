from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class SecurityAlert(Base):
    __tablename__ = "security_alerts"

    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="CASCADE"), nullable=True, index=True)
    evidence_id = Column(Integer, ForeignKey("evidence.id", ondelete="SET NULL"), nullable=True)
    alert_type = Column(String(100), nullable=False) # Evidence Tampering, Brute Force Detection, Malicious IOC
    severity = Column(String(20), default="High", nullable=False) # Low, Medium, High, Critical
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    is_resolved = Column(Boolean, default=False, index=True)
    resolved_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    incident = relationship("Incident", back_populates="alerts")
    evidence = relationship("Evidence")
    resolved_by = relationship("User")
