import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import IncidentsPage from './pages/IncidentsPage';
import AttackDetailsPage from './pages/AttackDetailsPage';
import EvidenceVaultPage from './pages/EvidenceVaultPage';
import ChainOfCustodyPage from './pages/ChainOfCustodyPage';
import LogAnalysisPage from './pages/LogAnalysisPage';
import ThreatIntelPage from './pages/ThreatIntelPage';
import ReportsPage from './pages/ReportsPage';
import UserManagementPage from './pages/UserManagementPage';
import SettingsPage from './pages/SettingsPage';
import { api, getStoredUser, getStoredToken } from './services/api';

export default function App() {
  const [user, setUser] = useState(getStoredUser());
  const [token, setToken] = useState(getStoredToken());
  const [authView, setAuthView] = useState('login'); // 'login' or 'register'
  const [activeTab, setActiveTab] = useState('dashboard');
  const [alerts, setAlerts] = useState([]);

  // Cross-page navigation context helpers
  const [selectedIncidentContext, setSelectedIncidentContext] = useState(null);
  const [selectedEvidenceContext, setSelectedEvidenceContext] = useState(null);

  const loadAlerts = async () => {
    if (!token) return;
    try {
      const data = await api.alerts.list();
      setAlerts(data);
    } catch (err) {
      console.error('Error fetching alerts', err);
    }
  };

  useEffect(() => {
    if (token) {
      loadAlerts();
      const interval = setInterval(loadAlerts, 15000);
      return () => clearInterval(interval);
    }
  }, [token]);

  useEffect(() => {
    const handleAuthExpired = () => {
      setUser(null);
      setToken(null);
    };
    window.addEventListener('auth-expired', handleAuthExpired);
    return () => window.removeEventListener('auth-expired', handleAuthExpired);
  }, []);

  const handleLoginSuccess = (loggedInUser) => {
    setUser(loggedInUser);
    setToken(getStoredToken());
  };

  const handleLogout = () => {
    api.auth.logout();
    setUser(null);
    setToken(null);
  };

  const handleResolveAlert = async (alertId) => {
    try {
      await api.alerts.resolve(alertId);
      loadAlerts();
    } catch (err) {
      alert(err.message);
    }
  };

  // If not authenticated, render Login or Register
  if (!token || !user) {
    if (authView === 'register') {
      return (
        <RegisterPage
          onRegisterSuccess={handleLoginSuccess}
          onSwitchToLogin={() => setAuthView('login')}
        />
      );
    }
    return (
      <LoginPage
        onLoginSuccess={handleLoginSuccess}
        onSwitchToRegister={() => setAuthView('register')}
      />
    );
  }

  const unresolvedAlertsCount = alerts.filter(a => !a.is_resolved).length;

  return (
    <div className="flex h-screen bg-cyber-950 text-slate-100 overflow-hidden font-sans">
      {/* SOC Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unresolvedAlertsCount={unresolvedAlertsCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Navbar */}
        <Navbar
          user={user}
          onLogout={handleLogout}
          alerts={alerts}
          onResolveAlert={handleResolveAlert}
          onNewIncidentClick={() => setActiveTab('incidents')}
        />

        {/* Scrollable Page Body */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && (
              <DashboardPage
                setActiveTab={setActiveTab}
                onSelectIncident={(incId) => setSelectedIncidentContext(incId)}
              />
            )}
            {activeTab === 'incidents' && (
              <IncidentsPage
                setActiveTab={setActiveTab}
                onSelectIncidentForEvidence={(incId) => setSelectedIncidentContext(incId)}
              />
            )}
            {activeTab === 'attack-details' && (
              <AttackDetailsPage />
            )}
            {activeTab === 'evidence' && (
              <EvidenceVaultPage
                setActiveTab={setActiveTab}
                onSelectEvidenceForCustody={(evId) => setSelectedEvidenceContext(evId)}
              />
            )}
            {activeTab === 'custody' && (
              <ChainOfCustodyPage />
            )}
            {activeTab === 'logs' && (
              <LogAnalysisPage />
            )}
            {activeTab === 'threat' && (
              <ThreatIntelPage />
            )}
            {activeTab === 'reports' && (
              <ReportsPage />
            )}
            {activeTab === 'users' && (
              <UserManagementPage />
            )}
            {activeTab === 'settings' && (
              <SettingsPage />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
