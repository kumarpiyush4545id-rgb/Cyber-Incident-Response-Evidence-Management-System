import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Plus,
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  X,
  FileLock2,
  Crosshair,
  FileText,
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import SeverityBadge from '../components/SeverityBadge';
import StatusBadge from '../components/StatusBadge';
import { api } from '../services/api';

const CATEGORIES = [
  'All',
  'Phishing',
  'Malware',
  'Ransomware',
  'Unauthorized Access',
  'Brute Force',
  'Denial of Service',
  'Data Breach',
  'Insider Threat'
];

const SEVERITIES = ['All', 'Critical', 'High', 'Medium', 'Low'];
const STATUSES = ['All', 'Open', 'Under Investigation', 'Resolved', 'Closed'];

export default function IncidentsPage({ setActiveTab, onSelectIncidentForEvidence }) {
  const [incidents, setIncidents] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [severityFilter, setSeverityFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  // Modal states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState(null);

  // Form data
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Ransomware',
    severity: 'High',
    status: 'Open',
    incident_datetime: new Date().toISOString().slice(0, 16),
    affected_system: '',
    source_ip: '',
    destination_ip: '',
    assigned_investigator_id: ''
  });

  const loadIncidents = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.incidents.list({
        severity: severityFilter,
        status: statusFilter,
        category: categoryFilter,
        search
      });
      setIncidents(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const data = await api.users.list();
      setUsers(data);
    } catch (err) {
      console.error('Failed to load investigators', err);
    }
  };

  useEffect(() => {
    loadIncidents();
  }, [categoryFilter, severityFilter, statusFilter]);

  useEffect(() => {
    loadUsers();
  }, []);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    loadIncidents();
  };

  const handleOpenCreate = () => {
    setFormData({
      title: '',
      description: '',
      category: 'Ransomware',
      severity: 'High',
      status: 'Open',
      incident_datetime: new Date().toISOString().slice(0, 16),
      affected_system: '',
      source_ip: '',
      destination_ip: '',
      assigned_investigator_id: users[0]?.id || ''
    });
    setIsCreateModalOpen(true);
  };

  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.incidents.create({
        ...formData,
        assigned_investigator_id: formData.assigned_investigator_id ? parseInt(formData.assigned_investigator_id) : null
      });
      setIsCreateModalOpen(false);
      loadIncidents();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleOpenEdit = (inc) => {
    setSelectedIncident(inc);
    setFormData({
      title: inc.title,
      description: inc.description,
      category: inc.category,
      severity: inc.severity,
      status: inc.status,
      incident_datetime: new Date(inc.incident_datetime).toISOString().slice(0, 16),
      affected_system: inc.affected_system,
      source_ip: inc.source_ip || '',
      destination_ip: inc.destination_ip || '',
      assigned_investigator_id: inc.assigned_investigator_id || ''
    });
    setIsEditModalOpen(true);
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.incidents.update(selectedIncident.id, {
        ...formData,
        assigned_investigator_id: formData.assigned_investigator_id ? parseInt(formData.assigned_investigator_id) : null
      });
      setIsEditModalOpen(false);
      loadIncidents();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleOpenDetail = async (id) => {
    try {
      const full = await api.incidents.getById(id);
      setSelectedIncident(full);
      setIsDetailModalOpen(true);
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDelete = async (inc) => {
    if (!confirm(`Are you sure you want to permanently delete case ${inc.case_id}? This action is restricted to administrators and will be logged in the permanent audit trail.`)) {
      return;
    }
    try {
      await api.incidents.delete(inc.id);
      loadIncidents();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            <ShieldAlert size={22} className="text-cyber-cyan" />
            Incident Case Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Register, triage, investigate and coordinate organizational cyber incident response
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadIncidents}
            className="p-2 rounded-xl bg-cyber-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
            title="Refresh List"
          >
            <RefreshCw size={16} />
          </button>
          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold text-xs transition shadow-md shadow-cyan-500/20 flex items-center gap-1.5"
          >
            <Plus size={16} />
            <span>Create New Case</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="cyber-card p-4 flex flex-col md:flex-row items-center gap-3 justify-between">
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
          <Search size={16} className="absolute left-3.5 top-3 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search Case ID, title, IP or host..."
            className="w-full pl-10 pr-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
          />
        </form>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-300 text-xs outline-none focus:border-cyber-cyan"
          >
            {CATEGORIES.map(c => <option key={c} value={c}>Category: {c}</option>)}
          </select>

          {/* Severity Filter */}
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-300 text-xs outline-none focus:border-cyber-cyan"
          >
            {SEVERITIES.map(s => <option key={s} value={s}>Severity: {s}</option>)}
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-300 text-xs outline-none focus:border-cyber-cyan"
          >
            {STATUSES.map(st => <option key={st} value={st}>Status: {st}</option>)}
          </select>
        </div>
      </div>

      {/* Incidents Table View */}
      <div className="cyber-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 font-mono">Case ID</th>
                <th className="py-3 px-4">Title &amp; Affected System</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">IP Scope</th>
                <th className="py-3 px-4">Lead Examiner</th>
                <th className="py-3 px-4 text-center">Evidence</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan="9" className="py-12 text-center text-slate-500">
                    <RefreshCw size={24} className="mx-auto mb-2 animate-spin text-cyber-cyan" />
                    <span>Loading incidents repository...</span>
                  </td>
                </tr>
              ) : incidents.length === 0 ? (
                <tr>
                  <td colSpan="9" className="py-12 text-center text-slate-500">
                    No incident cases found matching current filters.
                  </td>
                </tr>
              ) : (
                incidents.map((inc) => (
                  <tr key={inc.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4 font-mono font-bold text-cyber-cyan whitespace-nowrap">
                      {inc.case_id}
                    </td>
                    <td className="py-3 px-4 max-w-[240px]">
                      <div className="font-semibold text-slate-100 truncate">{inc.title}</div>
                      <div className="text-[11px] text-slate-500 font-mono truncate">{inc.affected_system}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-300 whitespace-nowrap">{inc.category}</td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <SeverityBadge severity={inc.severity} />
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <StatusBadge status={inc.status} />
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                      <div>Src: {inc.source_ip || 'N/A'}</div>
                      <div>Dst: {inc.destination_ip || 'N/A'}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-300 truncate max-w-[120px]">
                      {inc.investigator_name}
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-cyber-cyan">
                        {inc.evidence_count} file(s)
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-1">
                      <button
                        onClick={() => handleOpenDetail(inc.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-cyber-cyan hover:bg-slate-800 transition"
                        title="View Detailed Dossier"
                      >
                        <Eye size={15} />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(inc)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition"
                        title="Edit Incident Details"
                      >
                        <Edit2 size={15} />
                      </button>
                      <button
                        onClick={() => handleDelete(inc)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                        title="Delete Case (Admin Only)"
                      >
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE INCIDENT MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="cyber-card w-full max-w-2xl bg-cyber-900 border-slate-700 p-6 rounded-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <ShieldAlert size={20} className="text-cyber-cyan" />
                Initialize New Incident Investigation Case
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Incident Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Infiltration on Main DB via RDP"
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Category *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                  >
                    {CATEGORIES.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Severity *
                  </label>
                  <select
                    value={formData.severity}
                    onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                  >
                    {SEVERITIES.filter(s => s !== 'All').map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                  >
                    {STATUSES.filter(st => st !== 'All').map(st => <option key={st} value={st}>{st}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Affected System / Hostname *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.affected_system}
                    onChange={(e) => setFormData({ ...formData, affected_system: e.target.value })}
                    placeholder="e.g. DC-Cluster-01 (10.0.4.10)"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Incident Date &amp; Time (UTC) *
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={formData.incident_datetime}
                    onChange={(e) => setFormData({ ...formData, incident_datetime: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Source IP Address
                  </label>
                  <input
                    type="text"
                    value={formData.source_ip}
                    onChange={(e) => setFormData({ ...formData, source_ip: e.target.value })}
                    placeholder="185.220.101.5"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Destination IP Address
                  </label>
                  <input
                    type="text"
                    value={formData.destination_ip}
                    onChange={(e) => setFormData({ ...formData, destination_ip: e.target.value })}
                    placeholder="10.0.0.15"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Lead Assigned Investigator
                  </label>
                  <select
                    value={formData.assigned_investigator_id}
                    onChange={(e) => setFormData({ ...formData, assigned_investigator_id: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                  >
                    <option value="">Unassigned</option>
                    {users.map(u => (
                      <option key={u.id} value={u.id}>{u.full_name} ({u.username})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Incident Narrative &amp; Initial Findings *
                </label>
                <textarea
                  required
                  rows="3"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Detail the discovery circumstances, scope of compromise, and immediate containment measures taken..."
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold shadow-md shadow-cyan-500/20"
                >
                  Register Case
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT INCIDENT MODAL */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="cyber-card w-full max-w-2xl bg-cyber-900 border-slate-700 p-6 rounded-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Edit2 size={18} className="text-amber-400" />
                Modify Incident Case ({selectedIncident?.case_id})
              </h3>
              <button onClick={() => setIsEditModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Incident Title
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Category
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 outline-none"
                  >
                    {CATEGORIES.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Severity
                  </label>
                  <select
                    value={formData.severity}
                    onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 outline-none"
                  >
                    {SEVERITIES.filter(s => s !== 'All').map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 outline-none"
                  >
                    {STATUSES.filter(st => st !== 'All').map(st => <option key={st} value={st}>{st}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Affected System
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.affected_system}
                    onChange={(e) => setFormData({ ...formData, affected_system: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-100 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Assigned Investigator
                  </label>
                  <select
                    value={formData.assigned_investigator_id}
                    onChange={(e) => setFormData({ ...formData, assigned_investigator_id: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 outline-none"
                  >
                    <option value="">Unassigned</option>
                    {users.map(u => (
                      <option key={u.id} value={u.id}>{u.full_name} ({u.username})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Narrative Details
                </label>
                <textarea
                  required
                  rows="3"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-100 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CASE DETAILS FULL DOSSIER MODAL */}
      {isDetailModalOpen && selectedIncident && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="cyber-card w-full max-w-3xl bg-cyber-900 border-slate-700 p-6 rounded-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyber-cyan font-bold">
                  {selectedIncident.case_id}
                </span>
                <h3 className="text-base font-bold text-slate-100">{selectedIncident.title}</h3>
              </div>
              <button onClick={() => setIsDetailModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Badges bar */}
              <div className="flex flex-wrap items-center gap-3 p-3 rounded-xl bg-cyber-950 border border-slate-800">
                <div><span className="text-slate-500">Severity: </span><SeverityBadge severity={selectedIncident.severity} /></div>
                <div><span className="text-slate-500">Status: </span><StatusBadge status={selectedIncident.status} /></div>
                <div><span className="text-slate-500">Category: </span><strong className="text-slate-200">{selectedIncident.category}</strong></div>
                <div><span className="text-slate-500">Examiner: </span><strong className="text-cyber-cyan">{selectedIncident.investigator_name}</strong></div>
              </div>

              {/* Narrative */}
              <div>
                <h4 className="font-mono text-slate-400 uppercase text-[11px] mb-1 font-semibold">Incident Narrative</h4>
                <p className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-slate-300 leading-relaxed">
                  {selectedIncident.description}
                </p>
              </div>

              {/* Network Context */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase font-mono">Affected Host</span>
                  <div className="font-semibold text-slate-200 mt-0.5">{selectedIncident.affected_system}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono">
                  <span className="text-slate-500 text-[10px] uppercase font-mono">Source IP</span>
                  <div className="font-semibold text-rose-400 mt-0.5">{selectedIncident.source_ip || 'Undetermined'}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono">
                  <span className="text-slate-500 text-[10px] uppercase font-mono">Destination IP</span>
                  <div className="font-semibold text-cyan-400 mt-0.5">{selectedIncident.destination_ip || 'Internal'}</div>
                </div>
              </div>

              {/* Evidence and quick actions */}
              <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="text-slate-400 font-mono text-[11px]">
                  Logged Evidence: <strong className="text-cyber-cyan">{selectedIncident.evidence_items?.length || 0} file(s)</strong>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setIsDetailModalOpen(false);
                      setActiveTab('evidence');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 border border-purple-800 text-purple-200 flex items-center gap-1.5 transition font-medium"
                  >
                    <FileLock2 size={14} />
                    <span>View Evidence Vault</span>
                  </button>
                  <button
                    onClick={() => {
                      setIsDetailModalOpen(false);
                      setActiveTab('reports');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-800 text-cyan-200 flex items-center gap-1.5 transition font-medium"
                  >
                    <FileText size={14} />
                    <span>Generate PDF Report</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
