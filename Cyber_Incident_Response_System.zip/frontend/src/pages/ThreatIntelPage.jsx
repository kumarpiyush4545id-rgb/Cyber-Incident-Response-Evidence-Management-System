import React, { useState, useEffect } from 'react';
import {
  Cpu,
  ShieldAlert,
  AlertTriangle,
  Lightbulb,
  CheckCircle2,
  RefreshCw,
  Search,
  Crosshair,
  ExternalLink,
  Shield
} from 'lucide-react';
import SeverityBadge from '../components/SeverityBadge';
import { api } from '../services/api';

export default function ThreatIntelPage() {
  const [incidents, setIncidents] = useState([]);
  const [selectedIncidentId, setSelectedIncidentId] = useState('');
  const [loading, setLoading] = useState(false);
  const [threatResult, setThreatResult] = useState(null);
  const [customText, setCustomText] = useState('');
  const [error, setError] = useState('');

  const loadIncidents = async () => {
    try {
      const data = await api.incidents.list();
      setIncidents(data);
      if (data.length && !selectedIncidentId) {
        setSelectedIncidentId(data[0].id);
        runThreatAnalysis(data[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const runThreatAnalysis = async (incidentId, text = null) => {
    setLoading(true);
    setError('');
    try {
      const data = await api.threat.analyze({
        incident_id: incidentId ? parseInt(incidentId) : null,
        log_text: text || null
      });
      setThreatResult(data);
    } catch (err) {
      setError(err.message || 'Threat analysis failed.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadIncidents();
  }, []);

  const handleIncidentSelect = (id) => {
    setSelectedIncidentId(id);
    if (id) {
      runThreatAnalysis(id);
    }
  };

  const handleCustomAnalyze = (e) => {
    e.preventDefault();
    if (!customText.trim()) return;
    runThreatAnalysis(null, customText);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            <Cpu size={22} className="text-purple-400" />
            AI-Assisted Threat Intelligence &amp; Heuristics Engine
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Automated correlation of MITRE ATT&amp;CK tactics, anomaly heuristics, threat confidence scoring &amp; investigation advice
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedIncidentId}
            onChange={(e) => handleIncidentSelect(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 text-xs outline-none focus:border-purple-400 font-mono"
          >
            <option value="">Evaluate Custom String</option>
            {incidents.map(inc => (
              <option key={inc.id} value={inc.id}>{inc.case_id} - {inc.title}</option>
            ))}
          </select>

          <button
            onClick={() => runThreatAnalysis(selectedIncidentId, customText)}
            disabled={loading}
            className="p-2 rounded-xl bg-cyber-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
          >
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {/* Forensic Advisory Banner */}
      <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-500/40 text-xs text-purple-200 flex items-start gap-3">
        <Shield size={20} className="text-purple-400 flex-shrink-0 mt-0.5" />
        <div>
          <strong className="font-mono text-purple-300 uppercase block mb-0.5">
            AI / Rule-Based Threat Advisory Notice:
          </strong>
          Detected patterns and heuristic ratings represent investigative leads derived from ingested logs. They are provided to accelerate human forensic triage and do not constitute legally confirmed proof of compromise.
        </div>
      </div>

      {/* Custom String Input if No Incident Selected */}
      {!selectedIncidentId && (
        <div className="cyber-card p-5">
          <form onSubmit={handleCustomAnalyze} className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300 font-mono uppercase">
              Paste Suspicious Log String, Query or Script
            </label>
            <textarea
              rows="3"
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder="e.g. powershell.exe -enc SQB... OR 1=1 UNION SELECT ... Failed password for root"
              className="w-full p-3 rounded-xl bg-cyber-950 border border-slate-800 focus:border-purple-400 text-xs font-mono text-slate-200 outline-none"
            />
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition shadow-md shadow-purple-500/20"
              >
                Analyze Threat Payload
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Threat Results */}
      {loading ? (
        <div className="py-16 text-center text-slate-500">
          <RefreshCw size={28} className="mx-auto mb-3 animate-spin text-purple-400" />
          <p className="text-xs font-mono">Running heuristic threat matrix correlation...</p>
        </div>
      ) : threatResult && (
        <div className="space-y-6 animate-fadeIn">
          {/* Assessment & Score Banner */}
          <div className="cyber-card p-6 flex flex-col md:flex-row items-center justify-between gap-6 border-l-4 border-l-purple-500">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-xs font-mono uppercase font-bold text-slate-400">Heuristic Threat Evaluation:</span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-purple-950 border border-purple-800 text-purple-300 font-bold">
                  {threatResult.observations?.length || 0} Indicator(s) Flagged
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-100">{threatResult.overall_assessment}</h3>
              <p className="text-xs text-slate-400 mt-1">
                Evaluated across {threatResult.total_events_analyzed} event token(s) against MITRE ATT&amp;CK enterprise criteria.
              </p>
            </div>

            {/* Risk Dial Score */}
            <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-cyber-950 border border-slate-800 min-w-[140px] text-center">
              <span className="text-[10px] font-mono uppercase text-slate-500 font-bold mb-1">Risk Rating</span>
              <div className={`text-4xl font-mono font-black ${
                threatResult.risk_score >= 80 ? 'text-rose-400 glow-red' : (threatResult.risk_score >= 50 ? 'text-amber-400' : 'text-emerald-400')
              }`}>
                {threatResult.risk_score}
                <span className="text-sm font-normal text-slate-500">/100</span>
              </div>
            </div>
          </div>

          {/* Observations List */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold font-mono text-slate-200">
              Detailed Threat Observations &amp; Forensic Guidance
            </h3>

            {threatResult.observations?.length === 0 ? (
              <div className="cyber-card p-8 text-center text-slate-500 text-xs">
                No hostile threat signatures or behavioral anomalies identified.
              </div>
            ) : (
              threatResult.observations.map((obs, idx) => (
                <div key={idx} className="cyber-card p-5 border border-slate-800 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
                    <div className="flex items-center gap-3">
                      <SeverityBadge severity={obs.severity} />
                      <h4 className="text-sm font-bold text-slate-100">{obs.title}</h4>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-cyan-400 font-bold">
                        Confidence: {(obs.confidence * 100).toFixed(0)}%
                      </span>
                      {obs.mitre_attack_id && (
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-purple-950 border border-purple-800 text-purple-300">
                          {obs.mitre_attack_id}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Why Suspicious */}
                  <div className="p-3.5 rounded-xl bg-cyber-950 border border-slate-800 text-xs">
                    <span className="text-slate-400 font-semibold uppercase text-[10px] font-mono flex items-center gap-1.5 mb-1 text-cyber-cyan">
                      <Lightbulb size={14} />
                      Why is this behavior considered suspicious?
                    </span>
                    <p className="text-slate-300 leading-relaxed">
                      {obs.why_suspicious}
                    </p>
                  </div>

                  {/* Observed IOCs */}
                  {obs.detected_iocs?.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono">
                      <span className="text-slate-500 text-[11px]">Correlated IOCs:</span>
                      {obs.detected_iocs.map((ioc, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-rose-300 text-[11px]">
                          {ioc}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Recommended Investigation Steps */}
                  <div>
                    <span className="text-slate-400 font-semibold uppercase text-[10px] font-mono flex items-center gap-1.5 mb-2 text-emerald-400">
                      <CheckCircle2 size={14} />
                      Recommended Forensic Investigation &amp; Containment Steps
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-300 pl-2">
                      {obs.investigation_steps?.map((step, sIdx) => (
                        <li key={sIdx} className="flex items-start gap-2">
                          <span className="text-cyber-cyan font-bold font-mono">&bull;</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
