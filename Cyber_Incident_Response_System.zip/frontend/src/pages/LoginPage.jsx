import React, { useState } from 'react';
import { Shield, Lock, User, AlertCircle, ArrowRight } from 'lucide-react';
import { api } from '../services/api';

export default function LoginPage({ onLoginSuccess, onSwitchToRegister }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Please enter both username and password.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const data = await api.auth.login({ username, password });
      onLoginSuccess(data.user);
    } catch (err) {
      setError(err.message || 'Login failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = (u, p) => {
    setUsername(u);
    setPassword(p);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-cyber-950 relative overflow-hidden">
      {/* Background Cyber Grid Accent */}
      <div className="absolute inset-0 bg-[radial-gradient(#1E293B_1px,transparent_1px)] [background-size:24px_24px] opacity-30 pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="cyber-card w-full max-w-md bg-cyber-900/90 border-slate-800 p-8 rounded-2xl shadow-2xl relative z-10">
        {/* Logo & Platform Name */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-xl shadow-cyan-500/25 glow-cyan mb-4">
            <Shield size={32} className="stroke-[2.5]" />
          </div>
          <h2 className="text-2xl font-bold font-mono tracking-wider text-slate-100">
            CIREMS <span className="text-cyber-cyan text-sm align-super">SOC</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Cyber Incident Response &amp; Digital Forensics Platform
          </p>
        </div>

        {error && (
          <div className="mb-5 p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle size={16} className="flex-shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 font-mono">
              Username
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <User size={16} />
              </div>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. admin or investigator"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan focus:ring-1 focus:ring-cyber-cyan text-slate-100 text-sm placeholder:text-slate-600 transition outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 font-mono">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Lock size={16} />
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan focus:ring-1 focus:ring-cyber-cyan text-slate-100 text-sm placeholder:text-slate-600 transition outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold text-sm transition shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In to Security Operations'}</span>
            {!loading && <ArrowRight size={16} />}
          </button>
        </form>

        {/* Demo Fast Login Pills */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <p className="text-[11px] font-mono text-slate-500 text-center uppercase mb-2.5">
            Quick Demonstration Credentials
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleQuickLogin('admin', 'Admin@1234')}
              className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 text-[11px] text-slate-300 font-mono flex flex-col items-center gap-0.5 transition"
            >
              <strong className="text-purple-400">SOC Director (Admin)</strong>
              <span className="text-slate-500 text-[10px]">admin / Admin@1234</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('investigator', 'Investigator@1234')}
              className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 text-[11px] text-slate-300 font-mono flex flex-col items-center gap-0.5 transition"
            >
              <strong className="text-cyber-cyan">Lead Forensics</strong>
              <span className="text-slate-500 text-[10px]">investigator / Investigator@1234</span>
            </button>
          </div>
        </div>

        {/* Switch to Register */}
        <div className="mt-5 text-center">
          <button
            onClick={onSwitchToRegister}
            className="text-xs text-slate-400 hover:text-cyber-cyan transition font-mono"
          >
            New investigator? <span className="underline">Register credentials &rarr;</span>
          </button>
        </div>
      </div>
    </div>
  );
}
