import React, { useState, useEffect } from 'react';
import {
  FileSearch,
  Upload,
  AlertTriangle,
  ShieldAlert,
  Server,
  Lock,
  Flame,
  Globe,
  RefreshCw,
  Search,
  CheckCircle,
  TrendingDown
} from 'lucide-react';
import SeverityBadge from '../components/SeverityBadge';
import { api } from '../services/api';

const SAMPLE_SSH_LOG = `Nov 16 02:14:22 bastion-01 sshd[14221]: Failed password for invalid user admin from 185.220.101.5 port 42112 ssh2
Nov 16 02:14:25 bastion-01 sshd[14224]: Failed password for invalid user root from 185.220.101.5 port 42118 ssh2
Nov 16 02:14:28 bastion-01 sshd[14229]: Failed password for invalid user test from 185.220.101.5 port 42124 ssh2
Nov 16 02:14:31 bastion-01 sshd[14233]: Failed password for invalid user postgres from 185.220.101.5 port 42130 ssh2
Nov 16 02:14:34 bastion-01 sshd[14238]: Failed password for invalid user oracle from 185.220.101.5 port 42136 ssh2
Nov 16 02:14:37 bastion-01 sshd[14242]: Failed password for user anant from 185.220.101.5 port 42142 ssh2
Nov 16 02:14:40 bastion-01 sshd[14245]: Failed password for user anant from 185.220.101.5 port 42148 ssh2
Nov 16 02:15:02 bastion-01 sshd[14250]: Accepted publickey for backup_agent from 10.0.1.25 port 39212 ssh2`;

const SAMPLE_WEB_LOG = `185.220.101.5 - - [16/Nov/2026:03:12:01 +0000] "GET /login.php HTTP/1.1" 200 4520 "-" "Mozilla/5.0"
185.220.101.5 - - [16/Nov/2026:03:12:05 +0000] "POST /api/v1/auth HTTP/1.1" 401 210 "-" "python-requests/2.28.1"
185.220.101.5 - - [16/Nov/2026:03:12:08 +0000] "POST /api/v1/auth HTTP/1.1" 401 210 "-" "python-requests/2.28.1"
203.0.113.89 - - [16/Nov/2026:03:15:30 +0000] "GET /products.php?id=1%20UNION%20SELECT%20username,password_hash%20FROM%20users HTTP/1.1" 500 890 "-" "sqlmap/1.7.2#stable"
203.0.113.89 - - [16/Nov/2026:03:16:02 +0000] "GET /admin/shell.php HTTP/1.1" 404 182 "-" "Nikto/2.1.6"
203.0.113.89 - - [16/Nov/2026:03:16:05 +0000] "GET /.env HTTP/1.1" 404 182 "-" "Nikto/2.1.6"
10.0.0.15 - - [16/Nov/2026:03:20:00 +0000] "GET /dashboard HTTP/1.1" 200 12040 "-" "Mozilla/5.0 Chrome/120.0"`;

export default function LogAnalysisPage() {
  const [logType, setLogType] = useState('Authentication');
  const [logName, setLogName] = useState('Security_Auth_Audit.log');
  const [rawText, setRawText] = useState(SAMPLE_SSH_LOG);
  const [selectedFile, setSelectedFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [pastAnalyses, setPastAnalyses] = useState([]);
  const [error, setError] = useState('');

  const loadPastAnalyses = async () => {
    try {
      const data = await api.logs.listAnalyses();
      setPastAnalyses(data);
      if (data.length && !analysisResult) {
        setAnalysisResult(data[0]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadPastAnalyses();
  }, []);

  const handleRunAnalysis = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const formData = new FormData();
    formData.append('log_name', logName);
    formData.append('log_type', logType);
    if (selectedFile) {
      formData.append('file', selectedFile);
    } else {
      formData.append('raw_text', rawText);
    }

    try {
      const data = await api.logs.uploadAndAnalyze(formData);
      setAnalysisResult(data);
      loadPastAnalyses();
    } catch (err) {
      setError(err.message || 'Log analysis failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleLoadSample = (sampleType) => {
    if (sampleType === 'auth') {
      setLogType('Authentication');
      setLogName('bastion_sshd_audit.log');
      setRawText(SAMPLE_SSH_LOG);
      setSelectedFile(null);
    } else {
      setLogType('Server');
      setLogName('apache_web_exploit.log');
      setRawText(SAMPLE_WEB_LOG);
      setSelectedFile(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            <FileSearch size={22} className="text-cyber-cyan" />
            Security &amp; System Log Analysis Engine
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Pandas-powered multi-format log ingestion, authentication failure correlation, and hostile IP identification
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => handleLoadSample('auth')}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-cyber-cyan font-mono"
          >
            Load Sample Auth Log
          </button>
          <button
            type="button"
            onClick={() => handleLoadSample('web')}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-purple-400 font-mono"
          >
            Load Sample SQLi Log
          </button>
        </div>
      </div>

      {/* Upload and Configuration Form */}
      <div className="cyber-card p-5">
        <form onSubmit={handleRunAnalysis} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Log Type
              </label>
              <select
                value={logType}
                onChange={(e) => setLogType(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
              >
                <option value="Authentication">Authentication (Auth.log / SSH)</option>
                <option value="Server">Web Server (Apache / Nginx Combined)</option>
                <option value="Firewall">Firewall / Network Packet Drop</option>
                <option value="Application">Application / Custom Audit Log</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Log Identifier / Filename
              </label>
              <input
                type="text"
                value={logName}
                onChange={(e) => setLogName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Upload File (Optional)
              </label>
              <input
                type="file"
                onChange={(e) => setSelectedFile(e.target.files[0] || null)}
                className="w-full text-xs text-slate-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-xs file:font-mono file:bg-slate-800 file:text-slate-200 cursor-pointer"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
              Raw Log Text Feed
            </label>
            <textarea
              rows="4"
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Paste log stream here..."
              className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none font-mono text-[11px] leading-relaxed"
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs">
              {error}
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-[11px] text-slate-500 font-mono">
              Engine: Python Pandas &bull; Regex Timestamp &bull; IP Extraction
            </span>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold text-xs transition shadow-md shadow-cyan-500/20 flex items-center gap-2 disabled:opacity-50"
            >
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
              <span>{loading ? 'Executing Pandas Analysis...' : 'Parse &amp; Analyze Logs'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Analysis Results View */}
      {analysisResult && (
        <div className="space-y-6 animate-fadeIn">
          {/* Summary Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="cyber-card p-4 border-l-4 border-l-cyan-500">
              <span className="text-slate-400 font-mono text-[10px] uppercase">Total Log Entries</span>
              <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
                {analysisResult.total_entries}
              </div>
            </div>
            <div className="cyber-card p-4 border-l-4 border-l-rose-500">
              <span className="text-slate-400 font-mono text-[10px] uppercase">Failed Authentications</span>
              <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
                {analysisResult.failed_logins}
              </div>
            </div>
            <div className="cyber-card p-4 border-l-4 border-l-purple-500">
              <span className="text-slate-400 font-mono text-[10px] uppercase">Unique IP Sources</span>
              <div className="text-2xl font-bold font-mono text-purple-300 mt-1">
                {analysisResult.summary_stats?.unique_ips || 0}
              </div>
            </div>
            <div className="cyber-card p-4 border-l-4 border-l-amber-500">
              <span className="text-slate-400 font-mono text-[10px] uppercase">Suspicious IP Entities</span>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
                {analysisResult.suspicious_ips?.length || 0}
              </div>
            </div>
          </div>

          {/* Suspicious IPs Table */}
          {analysisResult.suspicious_ips && analysisResult.suspicious_ips.length > 0 && (
            <div className="cyber-card p-5">
              <h3 className="text-sm font-bold text-slate-200 mb-3 flex items-center gap-2 font-mono">
                <ShieldAlert size={18} className="text-rose-400" />
                Identified Hostile &amp; Suspicious Source IPs
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">Adversary IP</th>
                      <th className="py-2.5 px-3">Failure Volume</th>
                      <th className="py-2.5 px-3">Threat Category</th>
                      <th className="py-2.5 px-3">Calculated Risk</th>
                      <th className="py-2.5 px-3">Targeted Accounts</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {analysisResult.suspicious_ips.map((ipObj, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40">
                        <td className="py-2.5 px-3 font-bold text-rose-400">{ipObj.ip}</td>
                        <td className="py-2.5 px-3 text-slate-200">{ipObj.failure_count} failure(s)</td>
                        <td className="py-2.5 px-3 text-amber-300">{ipObj.threat_category}</td>
                        <td className="py-2.5 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            ipObj.risk_score >= 80 ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}>
                            Risk Score: {ipObj.risk_score}/100
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-400 truncate max-w-[200px]">
                          {ipObj.targeted_users?.length ? ipObj.targeted_users.join(', ') : 'Direct Endpoint'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Parsed Log Inspector Table */}
          <div className="cyber-card p-5">
            <h3 className="text-sm font-bold text-slate-200 mb-3 flex items-center gap-2">
              <Server size={18} className="text-cyber-cyan" />
              Forensic Log Entries (Parsed Inspector)
            </h3>
            <div className="overflow-x-auto max-h-96 overflow-y-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-900 sticky top-0 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">#</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                    <th className="py-2.5 px-3">IP Address</th>
                    <th className="py-2.5 px-3">User</th>
                    <th className="py-2.5 px-3">Event Type</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Severity</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-[11px]">
                  {(analysisResult.raw_preview || []).map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      <td className="py-2 px-3 text-slate-500">{row.id || idx + 1}</td>
                      <td className="py-2 px-3 text-slate-400 whitespace-nowrap">{row.timestamp}</td>
                      <td className="py-2 px-3 text-cyan-400 whitespace-nowrap">{row.ip}</td>
                      <td className="py-2 px-3 text-slate-300">{row.user}</td>
                      <td className="py-2 px-3 text-slate-300">{row.event_type}</td>
                      <td className="py-2 px-3">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          row.status === 'Failed' || row.status?.includes('40') || row.status?.includes('50')
                            ? 'bg-rose-950 text-rose-300'
                            : 'bg-slate-900 text-slate-400'
                        }`}>
                          {row.status}
                        </span>
                      </td>
                      <td className="py-2 px-3">
                        <SeverityBadge severity={row.severity} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
