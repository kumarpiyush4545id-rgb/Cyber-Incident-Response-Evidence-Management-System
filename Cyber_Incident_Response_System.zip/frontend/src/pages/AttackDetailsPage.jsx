import React, { useState, useEffect } from 'react';
import { Crosshair, Plus, Shield, Search, X, AlertCircle, RefreshCw, Terminal, Globe, Server } from 'lucide-react';
import { api } from '../services/api';

const ATTACK_TYPES = [
  'Ransomware',
  'Phishing',
  'Malware',
  'Unauthorized Access',
  'Brute Force',
  'SQL Injection (SQLi)',
  'Denial of Service (DoS)',
  'Data Breach',
  'Credential Stuffing',
  'Command & Control (C2)'
];

export default function AttackDetailsPage() {
  const [attacks, setAttacks] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedIncidentId, setSelectedIncidentId] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    incident_id: '',
    attack_type: 'Ransomware',
    attack_source: 'External Threat Actor (APT)',
    attack_vector: 'Compromised RDP Credentials',
    target_system: '',
    source_ip: '',
    destination_ip: '',
    mitre_tactics: 'Initial Access (T1078), Impact (T1486)',
    iocs_text: '',
    suspicious_activity_description: '',
    investigator_observations: ''
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [atkData, incData] = await Promise.all([
        api.attackDetails.list(selectedIncidentId ? parseInt(selectedIncidentId) : null),
        api.incidents.list()
      ]);
      setAttacks(atkData);
      setIncidents(incData);
      if (incData.length && !formData.incident_id) {
        setFormData(prev => ({ ...prev, incident_id: incData[0].id }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedIncidentId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const iocs = formData.iocs_text
        .split('\n')
        .map(s => s.trim())
        .filter(Boolean);

      await api.attackDetails.create({
        ...formData,
        incident_id: parseInt(formData.incident_id),
        indicators_of_compromise: iocs
      });
      setIsModalOpen(false);
      loadData();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            <Crosshair size={22} className="text-rose-400" />
            Cyberattack Detail &amp; MITRE Profiling
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Technical profiling of threat vectors, observed indicators of compromise (IOCs), and forensic observations
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadData}
            className="p-2 rounded-xl bg-cyber-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
          >
            <RefreshCw size={16} />
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold text-xs transition shadow-md shadow-cyan-500/20 flex items-center gap-1.5"
          >
            <Plus size={16} />
            <span>Record Attack Vector</span>
          </button>
        </div>
      </div>

      {/* Filter by incident */}
      <div className="cyber-card p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-400 uppercase font-semibold">Correlate Incident:</span>
          <select
            value={selectedIncidentId}
            onChange={(e) => setSelectedIncidentId(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 text-xs outline-none focus:border-cyber-cyan font-mono"
          >
            <option value="">All Incident Dossiers</option>
            {incidents.map(inc => (
              <option key={inc.id} value={inc.id}>{inc.case_id} - {inc.title}</option>
            ))}
          </select>
        </div>
        <span className="text-xs font-mono text-slate-500">
          Showing {attacks.length} attack profile(s)
        </span>
      </div>

      {/* Attack Profiles Cards */}
      <div className="grid grid-cols-1 gap-4">
        {loading ? (
          <div className="py-12 text-center text-slate-500">
            <RefreshCw size={24} className="mx-auto mb-2 animate-spin text-cyber-cyan" />
            <span>Loading attack profiles...</span>
          </div>
        ) : attacks.length === 0 ? (
          <div className="py-12 text-center text-slate-500 cyber-card">
            No attack detail profiles logged yet. Click "Record Attack Vector" to document an attack.
          </div>
        ) : (
          attacks.map((atk) => (
            <div key={atk.id} className="cyber-card p-5 border-l-4 border-l-rose-500">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-3">
                  <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-rose-950/80 text-rose-300 border border-rose-800">
                    {atk.attack_type}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    Associated Case: <strong className="text-cyber-cyan">Case #{atk.incident_id}</strong>
                  </span>
                </div>
                <time className="text-xs font-mono text-slate-400">
                  Detected: {new Date(atk.attack_timestamp).toLocaleString()}
                </time>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4 text-xs font-mono">
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase font-sans">Attack Vector &amp; Source</span>
                  <div className="text-slate-200 mt-1 font-semibold">{atk.attack_vector || 'N/A'}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{atk.attack_source}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase font-sans">Target System</span>
                  <div className="text-cyan-300 mt-1 font-semibold">{atk.target_system || 'Internal Asset'}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Dst: {atk.destination_ip || '10.0.0.0/8'}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-500 text-[10px] uppercase font-sans">Adversary Source IP</span>
                  <div className="text-rose-400 mt-1 font-bold">{atk.source_ip || 'Undetermined'}</div>
                  <div className="text-[11px] text-purple-400 mt-0.5 truncate">{atk.mitre_tactics}</div>
                </div>
              </div>

              {/* Observed IOCs */}
              {atk.indicators_of_compromise && atk.indicators_of_compromise.length > 0 && (
                <div className="mb-4">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono block mb-1.5">
                    Observed Indicators of Compromise (IOCs)
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {atk.indicators_of_compromise.map((ioc, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded text-[11px] font-mono bg-cyber-950 border border-slate-800 text-rose-300 break-all"
                      >
                        {ioc}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Narrative & Observations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800/80">
                  <span className="text-slate-400 font-semibold uppercase text-[10px] block mb-1">
                    Suspicious Activity Description
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {atk.suspicious_activity_description || 'No detailed behavior notes logged.'}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800/80">
                  <span className="text-slate-400 font-semibold uppercase text-[10px] block mb-1">
                    Investigator Forensic Observations
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {atk.investigator_observations || 'No additional examiner remarks.'}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* RECORD ATTACK MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="cyber-card w-full max-w-2xl bg-cyber-900 border-slate-700 p-6 rounded-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Crosshair size={20} className="text-rose-400" />
                Record Technical Cyberattack Vector &amp; IOC Profile
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Incident Case *
                  </label>
                  <select
                    required
                    value={formData.incident_id}
                    onChange={(e) => setFormData({ ...formData, incident_id: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                  >
                    {incidents.map(inc => (
                      <option key={inc.id} value={inc.id}>{inc.case_id} - {inc.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Attack Classification *
                  </label>
                  <select
                    value={formData.attack_type}
                    onChange={(e) => setFormData({ ...formData, attack_type: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                  >
                    {ATTACK_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Attack Vector
                  </label>
                  <input
                    type="text"
                    value={formData.attack_vector}
                    onChange={(e) => setFormData({ ...formData, attack_vector: e.target.value })}
                    placeholder="e.g. Spearphishing Link / SQLi on /api"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Attack Source Actor / Origin
                  </label>
                  <input
                    type="text"
                    value={formData.attack_source}
                    onChange={(e) => setFormData({ ...formData, attack_source: e.target.value })}
                    placeholder="e.g. External Tor Exit Node / ALPHV Affiliate"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Target Host
                  </label>
                  <input
                    type="text"
                    value={formData.target_system}
                    onChange={(e) => setFormData({ ...formData, target_system: e.target.value })}
                    placeholder="Finance-DB-01"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Source IP
                  </label>
                  <input
                    type="text"
                    value={formData.source_ip}
                    onChange={(e) => setFormData({ ...formData, source_ip: e.target.value })}
                    placeholder="185.220.101.44"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                    Destination IP
                  </label>
                  <input
                    type="text"
                    value={formData.destination_ip}
                    onChange={(e) => setFormData({ ...formData, destination_ip: e.target.value })}
                    placeholder="10.0.4.12"
                    className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  MITRE ATT&amp;CK Tactics &amp; Techniques
                </label>
                <input
                  type="text"
                  value={formData.mitre_tactics}
                  onChange={(e) => setFormData({ ...formData, mitre_tactics: e.target.value })}
                  placeholder="e.g. Initial Access (T1190), Execution (T1059)"
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Indicators of Compromise (IOCs) - 1 per line
                </label>
                <textarea
                  rows="3"
                  value={formData.iocs_text}
                  onChange={(e) => setFormData({ ...formData, iocs_text: e.target.value })}
                  placeholder="185.220.101.44&#10;c2.alphv-decryptor-onion.top&#10;9f83c12ab64e9a38f4d927c3e108f921a81bc7e2d93e1b7f9a8c2d1e0a82b4c5"
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Suspicious Activity Description
                </label>
                <textarea
                  rows="2"
                  value={formData.suspicious_activity_description}
                  onChange={(e) => setFormData({ ...formData, suspicious_activity_description: e.target.value })}
                  placeholder="Observed unauthorized commands, deleted backups, lateral scan bursts..."
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold"
                >
                  Save Attack Vector
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
