import React, { useState } from 'react';
import { Shield, Lock, User, Mail, Building, Award, AlertCircle, ArrowRight } from 'lucide-react';
import { api } from '../services/api';

export default function RegisterPage({ onRegisterSuccess, onSwitchToLogin }) {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    full_name: '',
    role: 'investigator',
    department: 'Digital Forensics Unit',
    badge_number: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.username || !formData.email || !formData.password || !formData.full_name) {
      setError('Please fill in all mandatory fields.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const data = await api.auth.register(formData);
      onRegisterSuccess(data.user);
    } catch (err) {
      setError(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-cyber-950 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(#1E293B_1px,transparent_1px)] [background-size:24px_24px] opacity-30 pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="cyber-card w-full max-w-lg bg-cyber-900/90 border-slate-800 p-8 rounded-2xl shadow-2xl relative z-10">
        <div className="text-center mb-6">
          <div className="w-12 h-12 mx-auto rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20 glow-cyan mb-3">
            <Shield size={26} className="stroke-[2.5]" />
          </div>
          <h2 className="text-xl font-bold font-mono tracking-wider text-slate-100">
            Investigator Enlistment
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Register authorized credentials for SOC &amp; Forensic access
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle size={16} className="flex-shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Full Name *
              </label>
              <div className="relative">
                <User size={15} className="absolute left-3 top-3 text-slate-500" />
                <input
                  type="text"
                  name="full_name"
                  value={formData.full_name}
                  onChange={handleChange}
                  placeholder="Agent Jane Doe"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Username *
              </label>
              <div className="relative">
                <Shield size={15} className="absolute left-3 top-3 text-slate-500" />
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder="jdoe_forensics"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Official Email *
              </label>
              <div className="relative">
                <Mail size={15} className="absolute left-3 top-3 text-slate-500" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="jdoe@agency.gov"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Password *
              </label>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-3 text-slate-500" />
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Role
              </label>
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 text-xs outline-none"
              >
                <option value="investigator">Investigator</option>
                <option value="admin">Administrator</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Department
              </label>
              <input
                type="text"
                name="department"
                value={formData.department}
                onChange={handleChange}
                className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                Badge Number
              </label>
              <input
                type="text"
                name="badge_number"
                value={formData.badge_number}
                onChange={handleChange}
                placeholder="DFIR-089"
                className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-4 py-2.5 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold text-xs transition shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <span>{loading ? 'Registering Credential...' : 'Register Investigator Account'}</span>
            {!loading && <ArrowRight size={15} />}
          </button>
        </form>

        <div className="mt-5 text-center">
          <button
            onClick={onSwitchToLogin}
            className="text-xs text-slate-400 hover:text-cyber-cyan transition font-mono"
          >
            Already registered? <span className="underline">Sign in to console &rarr;</span>
          </button>
        </div>
      </div>
    </div>
  );
}
