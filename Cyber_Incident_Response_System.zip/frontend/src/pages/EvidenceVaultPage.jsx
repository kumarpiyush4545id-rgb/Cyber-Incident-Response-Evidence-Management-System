import React, { useState, useEffect } from 'react';
import {
  FileLock2,
  Upload,
  Search,
  ShieldCheck,
  ShieldAlert,
  Download,
  RefreshCw,
  X,
  FileText,
  FileCode,
  Image,
  File,
  History,
  AlertTriangle
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import HashVerificationModal from '../components/HashVerificationModal';
import { api } from '../services/api';

const ALLOWED_EXTS = ['TXT', 'PDF', 'CSV', 'LOG', 'PNG', 'JPG', 'JPEG', 'JSON'];

export default function EvidenceVaultPage({ setActiveTab, onSelectEvidenceForCustody }) {
  const [evidenceList, setEvidenceList] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedIncidentId, setSelectedIncidentId] = useState('');

  // Modals
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [verifyingEvidence, setVerifyingEvidence] = useState(null);

  // Upload Form
  const [uploadIncidentId, setUploadIncidentId] = useState('');
  const [uploadDescription, setUploadDescription] = useState('');
  const [uploadFile, setUploadFile] = useState(null);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const loadEvidence = async () => {
    setLoading(true);
    try {
      const data = await api.evidence.list({
        incidentId: selectedIncidentId ? parseInt(selectedIncidentId) : null,
        integrity_status: statusFilter,
        search
      });
      setEvidenceList(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadIncidents = async () => {
    try {
      const data = await api.incidents.list();
      setIncidents(data);
      if (data.length && !uploadIncidentId) {
        setUploadIncidentId(data[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadEvidence();
  }, [statusFilter, selectedIncidentId]);

  useEffect(() => {
    loadIncidents();
  }, []);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    loadEvidence();
  };

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (!uploadFile) {
      setUploadError('Please select a file to ingest.');
      return;
    }
    if (!uploadIncidentId) {
      setUploadError('Please associate with an incident case.');
      return;
    }

    setUploadLoading(true);
    setUploadError('');

    const formData = new FormData();
    formData.append('incident_id', uploadIncidentId);
    formData.append('description', uploadDescription);
    formData.append('file', uploadFile);

    try {
      await api.evidence.upload(formData);
      setIsUploadModalOpen(false);
      setUploadFile(null);
      setUploadDescription('');
      loadEvidence();
    } catch (err) {
      setUploadError(err.message || 'Evidence upload failed.');
    } finally {
      setUploadLoading(false);
    }
  };

  const getFileIcon = (ext = '') => {
    const e = ext.toUpperCase();
    if (e === 'PDF') return <FileText size={18} className="text-rose-400" />;
    if (['LOG', 'TXT'].includes(e)) return <FileCode size={18} className="text-cyber-cyan" />;
    if (['PNG', 'JPG', 'JPEG'].includes(e)) return <Image size={18} className="text-purple-400" />;
    return <File size={18} className="text-blue-400" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            <FileLock2 size={22} className="text-cyber-cyan" />
            Digital Evidence Vault &amp; Cryptographic Integrity
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Forensic artifact storage, automated SHA-256 baseline hashing, and tamper detection monitoring
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadEvidence}
            className="p-2 rounded-xl bg-cyber-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
          >
            <RefreshCw size={16} />
          </button>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold text-xs transition shadow-md shadow-cyan-500/20 flex items-center gap-1.5"
          >
            <Upload size={16} />
            <span>Ingest Digital Evidence</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="cyber-card p-4 flex flex-col md:flex-row items-center gap-3 justify-between">
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
          <Search size={16} className="absolute left-3.5 top-3 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search Evidence ID, filename, hash..."
            className="w-full pl-10 pr-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 text-xs outline-none"
          />
        </form>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <select
            value={selectedIncidentId}
            onChange={(e) => setSelectedIncidentId(e.target.value)}
            className="px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-300 text-xs outline-none focus:border-cyber-cyan font-mono"
          >
            <option value="">All Incident Cases</option>
            {incidents.map(inc => (
              <option key={inc.id} value={inc.id}>{inc.case_id} - {inc.title}</option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 text-slate-300 text-xs outline-none focus:border-cyber-cyan font-mono"
          >
            <option value="All">Integrity: All</option>
            <option value="VERIFIED">VERIFIED</option>
            <option value="MODIFIED">MODIFIED (Tampered)</option>
          </select>
        </div>
      </div>

      {/* Evidence Table View */}
      <div className="cyber-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800 font-mono">
              <tr>
                <th className="py-3 px-4">Evidence ID</th>
                <th className="py-3 px-4">Artifact Details</th>
                <th className="py-3 px-4">Associated Case</th>
                <th className="py-3 px-4">Cryptographic SHA-256 Baseline</th>
                <th className="py-3 px-4">Integrity Status</th>
                <th className="py-3 px-4">Ingestion Time</th>
                <th className="py-3 px-4 text-right">Forensic Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-500">
                    <RefreshCw size={24} className="mx-auto mb-2 animate-spin text-cyber-cyan" />
                    <span>Loading digital evidence repository...</span>
                  </td>
                </tr>
              ) : evidenceList.length === 0 ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-500">
                    No digital evidence files stored matching the criteria.
                  </td>
                </tr>
              ) : (
                evidenceList.map((ev) => (
                  <tr key={ev.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4 font-mono font-bold text-cyber-cyan whitespace-nowrap">
                      {ev.evidence_id}
                    </td>

                    <td className="py-3 px-4 max-w-[200px]">
                      <div className="flex items-center gap-2">
                        {getFileIcon(ev.file_type)}
                        <div className="truncate">
                          <span className="font-semibold text-slate-200 block truncate" title={ev.original_filename}>
                            {ev.original_filename}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {ev.file_type} &bull; {(ev.file_size / 1024).toFixed(1)} KB &bull; By {ev.uploader_name}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap font-mono text-slate-300">
                      Case #{ev.incident_id}
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400 max-w-[220px]">
                      <div className="truncate text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800" title={ev.original_sha256}>
                        {ev.original_sha256}
                      </div>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      <StatusBadge status={ev.integrity_status} />
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                      {new Date(ev.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                    </td>

                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-1">
                      {/* Verify SHA-256 Button */}
                      <button
                        onClick={() => setVerifyingEvidence(ev)}
                        className="px-2.5 py-1 rounded-lg bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 font-mono text-[11px] font-semibold transition"
                        title="Recalculate & Compare SHA-256 Hash"
                      >
                        Verify Hash
                      </button>

                      {/* View Custody */}
                      <button
                        onClick={() => {
                          if (onSelectEvidenceForCustody) onSelectEvidenceForCustody(ev.id);
                          setActiveTab('custody');
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-purple-300 hover:bg-slate-800 transition"
                        title="View Chain of Custody History"
                      >
                        <History size={15} />
                      </button>

                      {/* Download */}
                      <a
                        href={api.evidence.downloadUrl(ev.id)}
                        className="inline-flex p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition"
                        title="Download Authenticated Evidence"
                      >
                        <Download size={15} />
                      </a>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* UPLOAD EVIDENCE MODAL */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="cyber-card w-full max-w-lg bg-cyber-900 border-slate-700 p-6 rounded-2xl shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Upload size={18} className="text-cyber-cyan" />
                Ingest Digital Forensics Evidence
              </h3>
              <button onClick={() => setIsUploadModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            {uploadError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle size={16} className="text-rose-400 flex-shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}

            <form onSubmit={handleUploadSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Associate Incident Case *
                </label>
                <select
                  required
                  value={uploadIncidentId}
                  onChange={(e) => setUploadIncidentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none"
                >
                  {incidents.map(inc => (
                    <option key={inc.id} value={inc.id}>{inc.case_id} - {inc.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Select Digital Evidence File *
                </label>
                <div className="border-2 border-dashed border-slate-800 hover:border-cyber-cyan/60 rounded-xl p-4 text-center cursor-pointer transition bg-slate-950/50">
                  <input
                    type="file"
                    required
                    onChange={(e) => setUploadFile(e.target.files[0] || null)}
                    className="block w-full text-xs text-slate-400 file:mr-4 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-cyber-cyan hover:file:bg-slate-700 cursor-pointer"
                  />
                  <p className="text-[10px] text-slate-500 mt-2 font-mono">
                    Supported: {ALLOWED_EXTS.join(', ')} (Max 50MB)
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Collection Context / Remarks
                </label>
                <textarea
                  rows="2"
                  value={uploadDescription}
                  onChange={(e) => setUploadDescription(e.target.value)}
                  placeholder="Where and how this evidence artifact was seized or extracted..."
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-800/40 text-[11px] text-slate-400">
                <strong className="text-cyber-cyan">Automated Forensic Guarantee:</strong> Upon upload, the backend computes the SHA-256 hash immediately and writes an immutable entry into the Chain of Custody log.
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploadLoading}
                  className="px-4 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold shadow-md shadow-cyan-500/20 disabled:opacity-50"
                >
                  {uploadLoading ? 'Hashing & Ingesting...' : 'Ingest & Compute Hash'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* HASH VERIFICATION MODAL */}
      {verifyingEvidence && (
        <HashVerificationModal
          evidence={verifyingEvidence}
          onClose={() => setVerifyingEvidence(null)}
          onVerified={() => loadEvidence()}
        />
      )}
    </div>
  );
}
