import React, { useState, useEffect } from 'react';
import { Users, Shield, Award, Mail, Building, RefreshCw, CheckCircle, UserCheck } from 'lucide-react';
import { api } from '../services/api';

export default function UserManagementPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await api.users.list();
      setUsers(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            <Users size={22} className="text-purple-400" />
            Security Personnel &amp; Investigator Directory
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Role-Based Access Control (RBAC), authorized forensic examiners, and badge credentials
          </p>
        </div>

        <button
          onClick={loadUsers}
          className="p-2 rounded-xl bg-cyber-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
        >
          <RefreshCw size={16} />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-500">
            <RefreshCw size={24} className="mx-auto mb-2 animate-spin text-purple-400" />
            <span>Loading personnel directory...</span>
          </div>
        ) : (
          users.map((u) => (
            <div key={u.id} className="cyber-card p-5 border border-slate-800 hover:border-purple-500/40 relative">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-cyber-cyan font-bold font-mono text-sm">
                  {u.username.slice(0, 2).toUpperCase()}
                </div>
                <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                  u.role === 'admin' 
                    ? 'bg-purple-950 text-purple-300 border border-purple-800' 
                    : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                }`}>
                  {u.role}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-100">{u.full_name}</h3>
              <p className="text-xs font-mono text-slate-400 mb-3">@{u.username}</p>

              <div className="space-y-1.5 text-xs text-slate-400 font-mono border-t border-slate-800/80 pt-3">
                <div className="flex items-center gap-2 truncate">
                  <Mail size={14} className="text-slate-500" />
                  <span className="truncate">{u.email}</span>
                </div>
                <div className="flex items-center gap-2 truncate">
                  <Building size={14} className="text-slate-500" />
                  <span className="truncate">{u.department || 'SOC Operations'}</span>
                </div>
                <div className="flex items-center gap-2 truncate">
                  <Award size={14} className="text-slate-500" />
                  <span className="text-cyber-cyan">{u.badge_number || 'ACTIVE-DUTY'}</span>
                </div>
              </div>

              <div className="mt-4 pt-2.5 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  Active Status
                </span>
                <span>Enlisted: {new Date(u.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
