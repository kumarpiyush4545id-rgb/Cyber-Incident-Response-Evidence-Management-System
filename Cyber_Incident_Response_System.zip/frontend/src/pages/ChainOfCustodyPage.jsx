import React, { useState, useEffect } from 'react';
import { History, ArrowRightLeft, Shield, RefreshCw, X, AlertCircle } from 'lucide-react';
import CustodyTimeline from '../components/CustodyTimeline';
import { api } from '../services/api';

export default function ChainOfCustodyPage() {
  const [records, setRecords] = useState([]);
  const [evidenceList, setEvidenceList] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedIncidentId, setSelectedIncidentId] = useState('');
  const [selectedEvidenceId, setSelectedEvidenceId] = useState('');

  // Transfer Modal
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferEvidenceId, setTransferEvidenceId] = useState('');
  const [newCustodian, setNewCustodian] = useState('');
  const [transferRemarks, setTransferRemarks] = useState('');
  const [transferLoading, setTransferLoading] = useState(false);
  const [transferError, setTransferError] = useState('');

  const loadCustody = async () => {
    setLoading(true);
    try {
      const data = await api.custody.list({
        incidentId: selectedIncidentId ? parseInt(selectedIncidentId) : null,
        evidenceId: selectedEvidenceId ? parseInt(selectedEvidenceId) : null,
      });
      setRecords(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadMetadata = async () => {
    try {
      const [evData, incData] = await Promise.all([
        api.evidence.list(),
        api.incidents.list()
      ]);
      setEvidenceList(evData);
      setIncidents(incData);
      if (evData.length && !transferEvidenceId) {
        setTransferEvidenceId(evData[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadCustody();
  }, [selectedIncidentId, selectedEvidenceId]);

  useEffect(() => {
    loadMetadata();
  }, []);

  const handleTransferSubmit = async (e) => {
    e.preventDefault();
    if (!transferEvidenceId || !newCustodian || !transferRemarks) {
      setTransferError('All transfer fields are required.');
      return;
    }

    setTransferLoading(true);
    setTransferError('');

    try {
      await api.custody.transfer({
        evidence_id: parseInt(transferEvidenceId),
        new_custodian: newCustodian,
        remarks: transferRemarks
      });
      setIsTransferModalOpen(false);
      setNewCustodian('');
      setTransferRemarks('');
      loadCustody();
    } catch (err) {
      setTransferError(err.message || 'Transfer failed.');
    } finally {
      setTransferLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            <History size={22} className="text-purple-400" />
            Immutable Chain of Custody Audit Trail
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Chronological forensic tracking of evidence possession, integrity verifications, transfers, and laboratory access
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadCustody}
            className="p-2 rounded-xl bg-cyber-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
          >
            <RefreshCw size={16} />
          </button>
          <button
            onClick={() => setIsTransferModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition shadow-md shadow-purple-500/20 flex items-center gap-1.5"
          >
            <ArrowRightLeft size={16} />
            <span>Record Custody Handover</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="cyber-card p-4 flex flex-col sm:flex-row items-center gap-3 justify-between">
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedIncidentId}
            onChange={(e) => setSelectedIncidentId(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 text-xs outline-none focus:border-cyber-cyan font-mono"
          >
            <option value="">All Incident Cases</option>
            {incidents.map(inc => (
              <option key={inc.id} value={inc.id}>{inc.case_id} - {inc.title}</option>
            ))}
          </select>

          <select
            value={selectedEvidenceId}
            onChange={(e) => setSelectedEvidenceId(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-cyber-950 border border-slate-800 text-slate-200 text-xs outline-none focus:border-cyber-cyan font-mono"
          >
            <option value="">All Evidence Items</option>
            {evidenceList.map(ev => (
              <option key={ev.id} value={ev.id}>{ev.evidence_id} - {ev.original_filename}</option>
            ))}
          </select>
        </div>

        <div className="text-xs font-mono text-slate-400">
          Total Recorded Events: <strong className="text-purple-400">{records.length}</strong>
        </div>
      </div>

      {/* Append-Only Notice Banner */}
      <div className="p-3 rounded-xl bg-slate-900/80 border border-purple-500/30 flex items-center gap-3 text-xs text-slate-300">
        <Shield size={18} className="text-purple-400 flex-shrink-0" />
        <div>
          <strong className="text-slate-100 font-mono">APPEND-ONLY INTEGRITY POLICY:</strong> Chain of Custody records cannot be edited or deleted by any system user. Every transfer, integrity verification, and export is permanently time-stamped for forensic admissibility.
        </div>
      </div>

      {/* Chronological Timeline */}
      <div className="cyber-card p-6">
        <h3 className="text-sm font-bold text-slate-200 mb-6 font-mono flex items-center gap-2">
          <span>&bull;</span> Chronological Forensic Event Sequence
        </h3>
        {loading ? (
          <div className="py-12 text-center text-slate-500">
            <RefreshCw size={24} className="mx-auto mb-2 animate-spin text-purple-400" />
            <span>Loading chronological custody records...</span>
          </div>
        ) : (
          <CustodyTimeline records={records} />
        )}
      </div>

      {/* CUSTODY TRANSFER MODAL */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="cyber-card w-full max-w-lg bg-cyber-900 border-slate-700 p-6 rounded-2xl shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <ArrowRightLeft size={18} className="text-purple-400" />
                Formal Evidence Custody Handover / Transfer
              </h3>
              <button onClick={() => setIsTransferModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            {transferError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle size={16} className="text-rose-400 flex-shrink-0" />
                <span>{transferError}</span>
              </div>
            )}

            <form onSubmit={handleTransferSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Digital Evidence Item *
                </label>
                <select
                  required
                  value={transferEvidenceId}
                  onChange={(e) => setTransferEvidenceId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-200 outline-none font-mono"
                >
                  {evidenceList.map(ev => (
                    <option key={ev.id} value={ev.id}>
                      {ev.evidence_id} - {ev.original_filename} (Case #{ev.incident_id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  New Receiving Custodian / Laboratory *
                </label>
                <input
                  type="text"
                  required
                  value={newCustodian}
                  onChange={(e) => setNewCustodian(e.target.value)}
                  placeholder="e.g. State Cyber Forensics Lab (Examiner Dr. Vance)"
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1 font-mono">
                  Transfer Purpose &amp; Remarks *
                </label>
                <textarea
                  required
                  rows="3"
                  value={transferRemarks}
                  onChange={(e) => setTransferRemarks(e.target.value)}
                  placeholder="State the formal evidentiary reason for custody transfer (e.g. Memory volatility extraction, offline malware sandbox analysis, court exhibit submission)..."
                  className="w-full px-3 py-2 rounded-xl bg-cyber-950 border border-slate-800 focus:border-cyber-cyan text-slate-100 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={transferLoading}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold shadow-md shadow-purple-500/20 disabled:opacity-50"
                >
                  {transferLoading ? 'Recording Handover...' : 'Sign &amp; Record Transfer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
