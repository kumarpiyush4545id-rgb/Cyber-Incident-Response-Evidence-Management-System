import React, { useState } from 'react';
import { Settings, Shield, Database, Lock, Key, Server, Terminal, FileCode } from 'lucide-react';

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div className="pb-2 border-b border-slate-800">
        <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
          <Settings size={22} className="text-cyber-cyan" />
          Security Architecture &amp; System Configuration
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Cryptographic enforcement policies, database persistence parameters, and compliance controls
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Security & Cryptography Policies */}
        <div className="cyber-card p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2 font-mono">
            <Lock size={18} className="text-cyber-cyan" />
            Cryptographic Integrity Controls
          </h3>

          <div className="space-y-3 text-xs font-mono">
            <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800">
              <div className="flex items-center justify-between text-slate-300 font-bold mb-1">
                <span>Evidence Hash Algorithm</span>
                <span className="text-cyber-cyan">SHA-256 (256-bit Digest)</span>
              </div>
              <p className="text-slate-500 text-[11px] font-sans">
                Stream-chunked hashlib implementation with zero memory spikes for large digital forensics artifacts.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800">
              <div className="flex items-center justify-between text-slate-300 font-bold mb-1">
                <span>Chain of Custody Protocol</span>
                <span className="text-purple-400">Append-Only / Immutable</span>
              </div>
              <p className="text-slate-500 text-[11px] font-sans">
                REST APIs strictly reject PUT or DELETE operations on historical custody records to ensure court compliance.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800">
              <div className="flex items-center justify-between text-slate-300 font-bold mb-1">
                <span>Session &amp; Token Encryption</span>
                <span className="text-emerald-400">HMAC-SHA256 (JWT)</span>
              </div>
              <p className="text-slate-500 text-[11px] font-sans">
                Role-based claim verification with automatic session timeout and cryptographically signed headers.
              </p>
            </div>
          </div>
        </div>

        {/* Database & Storage Architecture */}
        <div className="cyber-card p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2 font-mono">
            <Database size={18} className="text-purple-400" />
            Persistence &amp; Storage Architecture
          </h3>

          <div className="space-y-3 text-xs font-mono">
            <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800">
              <div className="flex items-center justify-between text-slate-300 font-bold mb-1">
                <span>Relational Database</span>
                <span className="text-cyan-400">PostgreSQL (SQLAlchemy Engine)</span>
              </div>
              <p className="text-slate-500 text-[11px] font-sans">
                Foreign key constraints with cascading evidence protection and indexed search fields.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800">
              <div className="flex items-center justify-between text-slate-300 font-bold mb-1">
                <span>Evidence Vault Storage</span>
                <span className="text-amber-400">Safe Isolated Path (/uploads)</span>
              </div>
              <p className="text-slate-500 text-[11px] font-sans">
                UUID prefix sanitization to prevent directory traversal and overwrite attacks.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-cyber-950 border border-slate-800">
              <div className="flex items-center justify-between text-slate-300 font-bold mb-1">
                <span>PDF Report Generator</span>
                <span className="text-rose-400">ReportLab Forensics Engine</span>
              </div>
              <p className="text-slate-500 text-[11px] font-sans">
                Automated multi-page forensic dossiers with hash tables, timeline matrices, and signature blocks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
