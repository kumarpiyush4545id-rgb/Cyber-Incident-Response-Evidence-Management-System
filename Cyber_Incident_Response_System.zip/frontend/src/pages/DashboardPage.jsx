import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  FileLock2,
  Activity,
  AlertTriangle,
  CheckCircle,
  FileSearch,
  Plus,
  ArrowRight,
  TrendingUp,
  PieChart as PieIcon,
  RefreshCw,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar
} from 'recharts';
import StatCard from '../components/StatCard';
import SeverityBadge from '../components/SeverityBadge';
import StatusBadge from '../components/StatusBadge';
import { api } from '../services/api';

const SEVERITY_COLORS = {
  Critical: '#F43F5E',
  High: '#F59E0B',
  Medium: '#EAB308',
  Low: '#3B82F6',
};

const CATEGORY_COLORS = ['#06B6D4', '#3B82F6', '#8B5CF6', '#EC4899', '#10B981', '#F59E0B'];

export default function DashboardPage({ setActiveTab, onSelectIncident }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadStats = async () => {
    setLoading(true);
    try {
      const data = await api.dashboard.getStats();
      setStats(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  if (loading && !stats) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3">
          <RefreshCw size={28} className="animate-spin text-cyber-cyan" />
          <p className="text-xs font-mono text-slate-400">Loading SOC telemetry...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center gap-2">
            SOC Operations Center &bull; Telemetry Overview
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time cyber incident triage, digital evidence cryptographic verification &amp; forensic metrics
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadStats}
            className="p-2 rounded-xl bg-cyber-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
            title="Refresh Metrics"
          >
            <RefreshCw size={16} />
          </button>
          <button
            onClick={() => setActiveTab('incidents')}
            className="px-3.5 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 font-semibold text-xs transition shadow-md shadow-cyan-500/20 flex items-center gap-1.5"
          >
            <Plus size={16} />
            <span>Record Incident Case</span>
          </button>
        </div>
      </div>

      {/* Top 6 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard
          title="Total Cases"
          value={stats?.total_incidents || 0}
          icon={ShieldAlert}
          color="cyan"
          badge="Live"
          subtext="Cumulative logged cases"
        />
        <StatCard
          title="Active Triage"
          value={(stats?.open_incidents || 0) + (stats?.under_investigation_incidents || 0)}
          icon={Activity}
          color="blue"
          badge={`${stats?.open_incidents || 0} Open`}
          subtext="Under active examination"
        />
        <StatCard
          title="Critical Alerts"
          value={stats?.critical_incidents || 0}
          icon={AlertTriangle}
          color="rose"
          badge="High Priority"
          subtext="Requires immediate containment"
        />
        <StatCard
          title="Evidence Files"
          value={stats?.total_evidence_files || 0}
          icon={FileLock2}
          color="purple"
          subtext="Vault stored artifacts"
        />
        <StatCard
          title="Hash Verified"
          value={stats?.verified_evidence_files || 0}
          icon={CheckCircle}
          color="emerald"
          badge={`${stats?.modified_evidence_files || 0} Tampered`}
          subtext="Cryptographically matched"
        />
        <StatCard
          title="Analyzed Events"
          value={stats?.total_log_events_analyzed?.toLocaleString() || '0'}
          icon={FileSearch}
          color="cyan"
          subtext="Processed log entries"
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 7-Day Trend Chart */}
        <div className="lg:col-span-2 cyber-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <TrendingUp size={16} className="text-cyber-cyan" />
                Incident Ingestion &amp; Evidence Collection Velocity
              </h3>
              <p className="text-xs text-slate-500">7-day rolling forensic activity window</p>
            </div>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
              UTC Timeline
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats?.timeline_trends || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="incGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#06B6D4" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="evGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                <XAxis dataKey="date" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0B0F19', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                  labelStyle={{ color: '#E2E8F0', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="incidents" name="Incidents Logged" stroke="#06B6D4" strokeWidth={2} fill="url(#incGrad)" />
                <Area type="monotone" dataKey="evidence" name="Evidence Ingested" stroke="#8B5CF6" strokeWidth={2} fill="url(#evGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Severity Distribution Donut */}
        <div className="cyber-card p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                  <PieIcon size={16} className="text-purple-400" />
                  Incident Severity Ratio
                </h3>
                <p className="text-xs text-slate-500">Triage prioritization distribution</p>
              </div>
            </div>

            <div className="h-48 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats?.severity_distribution || []}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="count"
                  >
                    {(stats?.severity_distribution || []).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={SEVERITY_COLORS[entry.severity] || '#64748B'} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0B0F19', borderColor: '#334155', borderRadius: '0.5rem', fontSize: '11px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-800">
            {(stats?.severity_distribution || []).map((item) => (
              <div key={item.severity} className="flex items-center justify-between text-xs px-2 py-1 rounded bg-slate-900/60 border border-slate-800">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: SEVERITY_COLORS[item.severity] }} />
                  {item.severity}
                </span>
                <span className="font-mono font-bold text-slate-200">{item.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Grid: Recent Incidents & Recent Custody Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Cases (2 cols) */}
        <div className="lg:col-span-2 cyber-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-200">Recent Incident Cases</h3>
              <p className="text-xs text-slate-500">Latest security events requiring forensic follow-up</p>
            </div>
            <button
              onClick={() => setActiveTab('incidents')}
              className="text-xs text-cyber-cyan hover:underline flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight size={14} />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3 font-mono">Case ID</th>
                  <th className="py-2.5 px-3">Title &amp; Target</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Severity</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Lead Examiner</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {(stats?.recent_incidents || []).map((inc) => (
                  <tr
                    key={inc.id}
                    onClick={() => {
                      if (onSelectIncident) onSelectIncident(inc.id);
                      setActiveTab('incidents');
                    }}
                    className="hover:bg-slate-800/40 cursor-pointer transition"
                  >
                    <td className="py-3 px-3 font-mono font-bold text-cyber-cyan">{inc.case_id}</td>
                    <td className="py-3 px-3 max-w-[200px]">
                      <div className="font-semibold text-slate-200 truncate">{inc.title}</div>
                      <div className="text-[11px] text-slate-500 font-mono truncate">{inc.affected_system}</div>
                    </td>
                    <td className="py-3 px-3 text-slate-300">{inc.category}</td>
                    <td className="py-3 px-3">
                      <SeverityBadge severity={inc.severity} />
                    </td>
                    <td className="py-3 px-3">
                      <StatusBadge status={inc.status} />
                    </td>
                    <td className="py-3 px-3 text-slate-400 truncate">{inc.investigator}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Custody Stream (1 col) */}
        <div className="cyber-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-200">Recent Custody Stream</h3>
              <p className="text-xs text-slate-500">Audit trail of evidence operations</p>
            </div>
            <button
              onClick={() => setActiveTab('custody')}
              className="text-xs text-cyber-cyan hover:underline flex items-center gap-1"
            >
              <span>Timeline</span>
              <ArrowRight size={14} />
            </button>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
            {(stats?.recent_activities || []).map((act, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-300">{act.title}</span>
                  <time className="text-[10px] text-slate-500 font-mono">
                    {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </time>
                </div>
                <p className="text-slate-400 text-[11px] leading-tight mb-1.5">{act.description}</p>
                <div className="text-[10px] text-slate-500 font-mono">
                  Operator: <strong className="text-cyber-cyan">{act.performer}</strong>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
