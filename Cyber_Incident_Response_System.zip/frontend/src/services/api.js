const API_BASE = '/api';

export const getStoredToken = () => localStorage.getItem('cirems_token');
export const setStoredToken = (token) => localStorage.setItem('cirems_token', token);
export const removeStoredToken = () => localStorage.removeItem('cirems_token');

export const getStoredUser = () => {
  const user = localStorage.getItem('cirems_user');
  return user ? JSON.parse(user) : null;
};
export const setStoredUser = (user) => localStorage.setItem('cirems_user', JSON.stringify(user));
export const removeStoredUser = () => localStorage.removeItem('cirems_user');

async function request(endpoint, options = {}) {
  const token = getStoredToken();
  const headers = {
    ...(options.headers || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // If body is not FormData, default to application/json
  if (options.body && !(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  if (response.status === 401) {
    removeStoredToken();
    removeStoredUser();
    window.dispatchEvent(new Event('auth-expired'));
  }

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ detail: 'Request failed.' }));
    throw new Error(errorData.detail || `Server error (${response.status})`);
  }

  return response.json();
}

export const api = {
  // Authentication
  auth: {
    login: async (credentials) => {
      const data = await request('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      });
      setStoredToken(data.access_token);
      setStoredUser(data.user);
      return data;
    },
    register: async (userData) => {
      const data = await request('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
      });
      setStoredToken(data.access_token);
      setStoredUser(data.user);
      return data;
    },
    getProfile: () => request('/auth/me'),
    logout: async () => {
      try {
        await request('/auth/logout', { method: 'POST' });
      } finally {
        removeStoredToken();
        removeStoredUser();
      }
    },
  },

  // Security Dashboard
  dashboard: {
    getStats: () => request('/dashboard/stats'),
  },

  // Incidents Case Management
  incidents: {
    list: (params = {}) => {
      const query = new URLSearchParams();
      if (params.severity && params.severity !== 'All') query.append('severity', params.severity);
      if (params.status && params.status !== 'All') query.append('status', params.status);
      if (params.category && params.category !== 'All') query.append('category', params.category);
      if (params.search) query.append('search', params.search);
      const qStr = query.toString();
      return request(`/incidents${qStr ? `?${qStr}` : ''}`);
    },
    getById: (id) => request(`/incidents/${id}`),
    create: (data) => request('/incidents', { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/incidents/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id) => request(`/incidents/${id}`, { method: 'DELETE' }),
  },

  // Attack Details
  attackDetails: {
    list: (incidentId) => request(`/attack-details${incidentId ? `?incident_id=${incidentId}` : ''}`),
    create: (data) => request('/attack-details', { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/attack-details/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  },

  // Digital Evidence Vault & Cryptographic Verification
  evidence: {
    list: (params = {}) => {
      const query = new URLSearchParams();
      if (params.incidentId) query.append('incident_id', params.incidentId);
      if (params.integrity_status && params.integrity_status !== 'All') query.append('integrity_status', params.integrity_status);
      if (params.search) query.append('search', params.search);
      const qStr = query.toString();
      return request(`/evidence${qStr ? `?${qStr}` : ''}`);
    },
    getById: (id) => request(`/evidence/${id}`),
    upload: (formData) => request('/evidence/upload', { method: 'POST', body: formData }),
    verifyHash: (id) => request(`/evidence/${id}/verify-hash`, { method: 'POST' }),
    simulateTamper: (id) => request(`/evidence/${id}/simulate-tamper`, { method: 'POST' }),
    downloadUrl: (id) => `${API_BASE}/evidence/${id}/download`,
  },

  // Chain of Custody
  custody: {
    list: (params = {}) => {
      const query = new URLSearchParams();
      if (params.incidentId) query.append('incident_id', params.incidentId);
      if (params.evidenceId) query.append('evidence_id', params.evidenceId);
      const qStr = query.toString();
      return request(`/chain-of-custody${qStr ? `?${qStr}` : ''}`);
    },
    transfer: (data) => request('/chain-of-custody/transfer', { method: 'POST', body: JSON.stringify(data) }),
  },

  // Security Log Analysis
  logs: {
    uploadAndAnalyze: (formData) => request('/logs/upload-and-analyze', { method: 'POST', body: formData }),
    listAnalyses: (incidentId) => request(`/logs/analyses${incidentId ? `?incident_id=${incidentId}` : ''}`),
    getAnalysisById: (id) => request(`/logs/analyses/${id}`),
  },

  // AI Threat Analysis
  threat: {
    analyze: (data) => request('/threat-intelligence/analyze', { method: 'POST', body: JSON.stringify(data) }),
    getByIncident: (incidentId) => request(`/threat-intelligence/incidents/${incidentId}`),
  },

  // Investigation Reports
  reports: {
    list: () => request('/reports'),
    generate: (incidentId, data = {}) => request(`/reports/generate/${incidentId}`, { method: 'POST', body: JSON.stringify(data) }),
    downloadUrl: (id) => `${API_BASE}/reports/${id}/download`,
  },

  // User Directory
  users: {
    list: () => request('/users'),
  },

  // Security Alerts
  alerts: {
    list: (params = {}) => {
      const query = new URLSearchParams();
      if (params.resolved !== undefined) query.append('resolved', params.resolved);
      if (params.severity && params.severity !== 'All') query.append('severity', params.severity);
      const qStr = query.toString();
      return request(`/alerts${qStr ? `?${qStr}` : ''}`);
    },
    resolve: (id) => request(`/alerts/${id}/resolve`, { method: 'PUT', body: JSON.stringify({ is_resolved: true }) }),
  },
};
