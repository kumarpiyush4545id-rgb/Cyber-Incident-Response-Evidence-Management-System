import React, { useState } from 'react';
import { Bell, ShieldAlert, LogOut, User as UserIcon, Plus, CheckCircle2 } from 'lucide-react';

export default function Navbar({ user, onLogout, alerts = [], onResolveAlert, onNewIncidentClick }) {
  const [showAlertsDropdown, setShowAlertsDropdown] = useState(false);

  const unresolvedAlerts = alerts.filter(a => !a.is_resolved);

  return (
    <header className="h-16 bg-cyber-900 border-b border-slate-800 px-6 flex items-center justify-between z-20">
      {/* Left SOC Title / Context */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span className="text-cyber-cyan font-bold">SYSTEM STATUS:</span>
          <span className="text-emerald-400 flex items-center gap-1.5 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            LIVE DEFENSE MONITORING
          </span>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-4">
        {/* Quick New Incident */}
        {onNewIncidentClick && (
          <button
            onClick={onNewIncidentClick}
            className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 transition font-sans shadow-md shadow-cyan-500/20"
          >
            <Plus size={16} />
            <span>New Incident</span>
          </button>
        )}

        {/* Security Alerts Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowAlertsDropdown(!showAlertsDropdown)}
            className="relative p-2 rounded-xl text-slate-300 hover:text-slate-100 hover:bg-slate-800 transition border border-slate-800"
            title="Active Security Alerts"
          >
            <Bell size={18} />
            {unresolvedAlerts.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white font-mono text-[10px] font-bold flex items-center justify-center animate-pulse">
                {unresolvedAlerts.length}
              </span>
            )}
          </button>

          {showAlertsDropdown && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-cyber-900 border border-slate-700 rounded-2xl shadow-2xl p-4 z-50 animate-fadeIn">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <ShieldAlert size={16} className="text-rose-400" />
                  Security Alerts ({unresolvedAlerts.length})
                </span>
                <span className="text-[10px] font-mono text-slate-500">Live Ingestion</span>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/80 my-2">
                {unresolvedAlerts.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500">
                    No active threat or tampering alerts.
                  </div>
                ) : (
                  unresolvedAlerts.map(alert => (
                    <div key={alert.id} className="py-3 flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold uppercase">
                            {alert.severity}
                          </span>
                          <h4 className="text-xs font-semibold text-slate-200">{alert.title}</h4>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1 leading-snug">{alert.description}</p>
                      </div>
                      <button
                        onClick={() => onResolveAlert && onResolveAlert(alert.id)}
                        className="text-slate-500 hover:text-emerald-400 p-1 transition"
                        title="Mark Resolved"
                      >
                        <CheckCircle2 size={16} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Badge */}
        <div className="flex items-center gap-3 pl-3 border-l border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-cyber-800 border border-slate-700 flex items-center justify-center text-cyber-cyan">
            <UserIcon size={16} />
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs font-semibold text-slate-200 leading-tight">
              {user?.full_name || user?.username || 'Investigator'}
            </div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className={`text-[10px] font-mono uppercase font-bold px-1.5 py-0.2 rounded ${
                user?.role === 'admin' ? 'bg-purple-950 text-purple-300 border border-purple-800' : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
              }`}>
                {user?.role || 'Investigator'}
              </span>
              <span className="text-[10px] text-slate-500 truncate max-w-[100px]">
                {user?.badge_number || user?.department || 'SOC DFIR'}
              </span>
            </div>
          </div>

          {/* Logout Button */}
          <button
            onClick={onLogout}
            className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800/80 transition"
            title="Log Out"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </header>
  );
}
