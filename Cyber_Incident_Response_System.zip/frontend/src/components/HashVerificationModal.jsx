import React, { useState } from 'react';
import { ShieldCheck, ShieldAlert, RefreshCw, X, AlertTriangle, Bug, Copy, Check } from 'lucide-react';
import { api } from '../services/api';

export default function HashVerificationModal({ evidence, onClose, onVerified }) {
  const [loading, setLoading] = useState(false);
  const [tampering, setTampering] = useState(false);
  const [copiedHash, setCopiedHash] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  if (!evidence) return null;

  const handleCopy = (text, type) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(type);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const handleVerify = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.evidence.verifyHash(evidence.id);
      setResult(data);
      if (onVerified) onVerified(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSimulateTamper = async () => {
    if (!confirm('This will simulate unauthorized tampering by modifying the file on disk to test the cryptographic detection engine. Proceed?')) {
      return;
    }
    setTampering(true);
    setError(null);
    try {
      const data = await api.evidence.simulateTamper(evidence.id);
      setResult(data);
      if (onVerified) onVerified(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setTampering(false);
    }
  };

  const currentStatus = result ? result.integrity_status : evidence.integrity_status;
  const isVerified = currentStatus === 'VERIFIED';
  const originalHash = evidence.original_sha256;
  const currentHash = result ? result.current_sha256 : (evidence.current_sha256 || originalHash);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="cyber-card w-full max-w-2xl bg-cyber-900 border-slate-700 p-6 rounded-2xl shadow-2xl relative">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl ${isVerified ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
              {isVerified ? <ShieldCheck size={24} /> : <ShieldAlert size={24} />}
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                SHA-256 Cryptographic Integrity Verification
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Evidence ID: <span className="text-cyber-cyan">{evidence.evidence_id}</span> ({evidence.original_filename})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Verification Status Banner */}
        <div className="my-5">
          <div className={`p-4 rounded-xl border flex items-center justify-between ${
            isVerified 
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200' 
              : 'bg-rose-950/40 border-rose-500/60 text-rose-200 glow-red'
          }`}>
            <div className="flex items-center gap-3">
              {isVerified ? (
                <ShieldCheck size={32} className="text-emerald-400 flex-shrink-0" />
              ) : (
                <AlertTriangle size={32} className="text-rose-400 flex-shrink-0 animate-bounce" />
              )}
              <div>
                <div className="text-sm font-bold tracking-wide flex items-center gap-2">
                  <span>INTEGRITY STATUS:</span>
                  <span className={`px-2 py-0.5 rounded text-xs font-mono font-black uppercase ${
                    isVerified ? 'bg-emerald-500 text-emerald-950' : 'bg-rose-500 text-rose-950'
                  }`}>
                    {currentStatus}
                  </span>
                </div>
                <p className="text-xs opacity-90 mt-1">
                  {result?.message || (
                    isVerified 
                      ? 'The physical file SHA-256 hash matches the evidentiary baseline computed upon ingestion.' 
                      : 'CRITICAL ALERT: File hash mismatch detected! Evidence has been altered or corrupted.'
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Hash Comparison Table */}
        <div className="space-y-4 font-mono text-xs">
          {/* Baseline Hash */}
          <div className="p-3 bg-cyber-950 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-1.5 font-sans">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyber-cyan" />
                Original Baseline SHA-256 (Permanent Evidentiary Anchor)
              </span>
              <button
                onClick={() => handleCopy(originalHash, 'orig')}
                className="text-slate-400 hover:text-cyber-cyan flex items-center gap-1 transition"
              >
                {copiedHash === 'orig' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copiedHash === 'orig' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <div className="break-all p-2 rounded bg-slate-900/80 text-cyber-cyan font-mono tracking-wide selection:bg-cyan-500">
              {originalHash}
            </div>
          </div>

          {/* Current Recalculated Hash */}
          <div className="p-3 bg-cyber-950 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-1.5 font-sans">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isVerified ? 'bg-emerald-400' : 'bg-rose-400 animate-pulse'}`} />
                Current Disk SHA-256 (Recalculated from Storage)
              </span>
              <button
                onClick={() => handleCopy(currentHash, 'curr')}
                className="text-slate-400 hover:text-cyber-cyan flex items-center gap-1 transition"
              >
                {copiedHash === 'curr' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copiedHash === 'curr' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <div className={`break-all p-2 rounded font-mono tracking-wide ${
              isVerified ? 'bg-slate-900/80 text-emerald-400' : 'bg-rose-950/40 text-rose-300 border border-rose-500/40'
            }`}>
              {currentHash}
            </div>
          </div>
        </div>

        {/* Forensic Advisory Note */}
        <div className="mt-4 p-3 bg-slate-900/60 rounded-lg border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
          <strong className="text-slate-300">Forensic Rule Compliance:</strong> The original SHA-256 baseline hash is immutable and is permanently preserved in the PostgreSQL database. Recalculation streams the physical bytes from disk and checks against the baseline without ever overwriting the initial anchor.
        </div>

        {error && (
          <div className="mt-3 p-2.5 rounded bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs font-mono">
            Error: {error}
          </div>
        )}

        {/* Action Controls */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={handleSimulateTamper}
            disabled={tampering || loading}
            title="Demonstration feature for juries and examiners to test live alert generation"
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 flex items-center gap-2 transition disabled:opacity-50"
          >
            <Bug size={15} />
            <span>{tampering ? 'Injecting Tamper...' : 'Simulate Evidence Tampering (Jury Demo)'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
            >
              Close
            </button>
            <button
              onClick={handleVerify}
              disabled={loading || tampering}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-cyber-cyan hover:bg-cyan-400 text-cyber-950 flex items-center gap-2 transition disabled:opacity-50 font-sans shadow-lg shadow-cyan-500/20"
            >
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
              <span>{loading ? 'Computing SHA-256...' : 'Recalculate Integrity'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
