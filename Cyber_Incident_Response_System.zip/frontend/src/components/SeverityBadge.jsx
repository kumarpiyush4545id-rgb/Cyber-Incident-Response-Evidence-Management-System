import React from 'react';

export default function SeverityBadge({ severity }) {
  const sev = (severity || 'Low').toLowerCase();

  const styles = {
    critical: 'bg-rose-950/80 text-rose-300 border-rose-500/50 shadow-rose-950/50',
    high: 'bg-amber-950/80 text-amber-300 border-amber-500/50 shadow-amber-950/50',
    medium: 'bg-yellow-950/80 text-yellow-300 border-yellow-500/50 shadow-yellow-950/50',
    low: 'bg-blue-950/80 text-blue-300 border-blue-500/50 shadow-blue-950/50',
  };

  const dots = {
    critical: 'bg-rose-500 animate-pulse',
    high: 'bg-amber-500',
    medium: 'bg-yellow-500',
    low: 'bg-blue-400',
  };

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold tracking-wider uppercase border shadow-sm ${styles[sev] || styles.low}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dots[sev] || dots.low}`} />
      {severity}
    </span>
  );
}
