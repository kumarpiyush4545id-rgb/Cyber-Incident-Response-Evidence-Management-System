import React from 'react';

export default function StatusBadge({ status }) {
  const stat = (status || 'Open').toLowerCase();

  const styles = {
    open: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    'under investigation': 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    resolved: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    closed: 'bg-slate-500/10 text-slate-400 border-slate-500/30',
    verified: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 glow-cyan',
    modified: 'bg-rose-500/20 text-rose-300 border-rose-500/60 glow-red animate-pulse',
    unverified: 'bg-yellow-500/10 text-yellow-300 border-yellow-500/30',
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-mono font-medium border ${styles[stat] || styles.open}`}>
      {status}
    </span>
  );
}
