import React from 'react';

export default function StatCard({ title, value, subtext, icon: Icon, color = 'cyan', badge }) {
  const colorMap = {
    cyan: {
      text: 'text-cyber-cyan',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/20',
      hoverBorder: 'hover:border-cyan-500/50',
    },
    rose: {
      text: 'text-rose-400',
      bg: 'bg-rose-500/10',
      border: 'border-rose-500/20',
      hoverBorder: 'hover:border-rose-500/50',
    },
    emerald: {
      text: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/20',
      hoverBorder: 'hover:border-emerald-500/50',
    },
    blue: {
      text: 'text-blue-400',
      bg: 'bg-blue-500/10',
      border: 'border-blue-500/20',
      hoverBorder: 'hover:border-blue-500/50',
    },
    purple: {
      text: 'text-purple-400',
      bg: 'bg-purple-500/10',
      border: 'border-purple-500/20',
      hoverBorder: 'hover:border-purple-500/50',
    },
  };

  const scheme = colorMap[color] || colorMap.cyan;

  return (
    <div className={`cyber-card p-5 border ${scheme.border} ${scheme.hoverBorder} relative overflow-hidden group`}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium uppercase tracking-wider text-slate-400">
          {title}
        </span>
        {Icon && (
          <div className={`p-2 rounded-lg ${scheme.bg} ${scheme.text} group-hover:scale-110 transition-transform`}>
            <Icon size={20} />
          </div>
        )}
      </div>

      <div className="flex items-baseline justify-between">
        <span className="text-3xl font-bold font-mono text-slate-50 tracking-tight">
          {value}
        </span>
        {badge && (
          <span className="text-xs px-2 py-0.5 rounded font-mono bg-slate-800 text-slate-300 border border-slate-700">
            {badge}
          </span>
        )}
      </div>

      {subtext && (
        <p className="mt-2 text-xs text-slate-400 flex items-center gap-1.5">
          {subtext}
        </p>
      )}

      {/* Subtle corner accent line */}
      <div className={`absolute bottom-0 left-0 right-0 h-0.5 ${scheme.bg}`} />
    </div>
  );
}
