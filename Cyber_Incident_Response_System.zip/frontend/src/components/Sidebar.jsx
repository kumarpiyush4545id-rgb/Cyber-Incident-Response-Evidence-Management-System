import React from 'react';
import {
  LayoutDashboard,
  ShieldAlert,
  Crosshair,
  FileLock2,
  History,
  FileSearch,
  Cpu,
  FileText,
  Users,
  Settings,
  Shield,
  Activity
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab, unresolvedAlertsCount = 0 }) {
  const navItems = [
    { id: 'dashboard', label: 'SOC Dashboard', icon: LayoutDashboard },
    { id: 'incidents', label: 'Incident Cases', icon: ShieldAlert },
    { id: 'attack-details', label: 'Attack Details', icon: Crosshair },
    { id: 'evidence', label: 'Evidence Vault', icon: FileLock2 },
    { id: 'custody', label: 'Chain of Custody', icon: History },
    { id: 'logs', label: 'Log Analysis', icon: FileSearch },
    { id: 'threat', label: 'Threat Intelligence', icon: Cpu, badge: 'AI' },
    { id: 'reports', label: 'Investigation Reports', icon: FileText },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'settings', label: 'Settings & Audit', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-cyber-900 border-r border-slate-800 flex flex-col flex-shrink-0 z-30 select-none">
      {/* Brand & SOC Identification */}
      <div className="p-5 border-b border-slate-800 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20 glow-cyan flex-shrink-0">
          <Shield size={22} className="stroke-[2.5]" />
        </div>
        <div>
          <h1 className="text-sm font-bold font-mono tracking-wider text-slate-100 flex items-center gap-1.5">
            CIREMS <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyber-cyan border border-cyan-800 font-sans font-semibold">SOC</span>
          </h1>
          <p className="text-[11px] text-slate-400 truncate">Forensic Response &amp; Chain</p>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500 font-mono">
          Security Operations
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                isActive
                  ? 'bg-cyber-cyan/15 text-cyber-cyan border border-cyber-cyan/40 shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon size={18} className={isActive ? 'text-cyber-cyan' : 'text-slate-400'} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 border border-purple-800 font-bold">
                  {item.badge}
                </span>
              )}
              {item.id === 'incidents' && unresolvedAlertsCount > 0 && (
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-bold animate-pulse">
                  {unresolvedAlertsCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* System Status Footer */}
      <div className="p-4 border-t border-slate-800/80 bg-cyber-950/60">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="text-slate-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            SOC Telemetry
          </span>
          <span className="font-mono text-[11px] text-emerald-400 font-bold">ONLINE</span>
        </div>
        <p className="text-[10px] text-slate-500 font-mono">Defense Core v1.0 &bull; SHA-256 Engine</p>
      </div>
    </aside>
  );
}
