import React from 'react';
import { ShieldCheck, FileUp, Download, RefreshCw, ArrowRightLeft, FileQuestion, AlertTriangle } from 'lucide-react';

export default function CustodyTimeline({ records = [] }) {
  if (!records.length) {
    return (
      <div className="text-center py-12 text-slate-500 border border-dashed border-slate-800 rounded-xl">
        <FileQuestion size={40} className="mx-auto mb-3 opacity-40 text-cyber-cyan" />
        <p className="text-sm font-medium">No custody events recorded yet.</p>
        <p className="text-xs text-slate-600 mt-1">Actions performed on digital evidence will automatically generate immutable custody records.</p>
      </div>
    );
  }

  const getActionIcon = (action = '') => {
    const act = action.toLowerCase();
    if (act.includes('tamper') || act.includes('failed')) return <AlertTriangle size={16} className="text-rose-400" />;
    if (act.includes('verified')) return <ShieldCheck size={16} className="text-emerald-400" />;
    if (act.includes('upload')) return <FileUp size={16} className="text-cyber-cyan" />;
    if (act.includes('download')) return <Download size={16} className="text-blue-400" />;
    if (act.includes('transfer') || act.includes('handover')) return <ArrowRightLeft size={16} className="text-purple-400" />;
    return <RefreshCw size={16} className="text-slate-400" />;
  };

  return (
    <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
      {records.map((item, index) => {
        const isTamper = item.action.toLowerCase().includes('tamper');
        return (
          <div key={item.id || index} className="relative group">
            {/* Timeline node dot */}
            <div className={`absolute -left-6 top-1 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
              isTamper 
                ? 'bg-rose-950 border-rose-500 ring-4 ring-rose-500/20' 
                : 'bg-cyber-900 border-cyber-cyan/60 group-hover:border-cyber-cyan group-hover:scale-110'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isTamper ? 'bg-rose-400' : 'bg-cyber-cyan'}`} />
            </div>

            {/* Timeline content box */}
            <div className={`cyber-card p-4 rounded-xl border transition-all ${
              isTamper ? 'border-rose-500/50 bg-rose-950/20' : 'border-slate-800/80 hover:border-slate-700'
            }`}>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  {getActionIcon(item.action)}
                  <span className={`text-sm font-semibold tracking-wide ${isTamper ? 'text-rose-300' : 'text-slate-200'}`}>
                    {item.action}
                  </span>
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-400">
                    {item.record_id}
                  </span>
                </div>
                <time className="text-xs font-mono text-slate-400">
                  {new Date(item.timestamp).toLocaleString()}
                </time>
              </div>

              {/* Custodian route */}
              {(item.previous_custodian || item.new_custodian) && (
                <div className="flex items-center gap-2 text-xs text-slate-400 mb-2 font-mono">
                  <span className="text-slate-500">Custodian Route:</span>
                  <span className="text-slate-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    {item.previous_custodian || 'Origin'}
                  </span>
                  <span className="text-cyber-cyan">&rarr;</span>
                  <span className="text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50 font-medium">
                    {item.new_custodian || 'CIREMS Vault'}
                  </span>
                </div>
              )}

              {/* Remarks */}
              {item.remarks && (
                <p className={`text-xs mt-1 leading-relaxed ${isTamper ? 'text-rose-200 font-mono' : 'text-slate-400'}`}>
                  {item.remarks}
                </p>
              )}

              {/* Performed by */}
              <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500">
                <span>Recorded By: <strong className="text-slate-300">{item.performer_name || 'System Forensic Engine'}</strong></span>
                <span>Evidence ID: <strong className="text-cyber-cyan font-mono">#{item.evidence_id}</strong></span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
